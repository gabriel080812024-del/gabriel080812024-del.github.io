"""Inventario de mercancías con costo promedio ponderado, conectado a la contabilidad.

Cada operación hace sus asientos de partida doble:
  compra        Debe Mercancías            / Haber Caja, Proveedor (factura por pagar) o Saldos de apertura
  costo extra   Debe Mercancías            / Haber Caja o Proveedor   (flete, nacionalización: suben el costo)
  venta         Debe Caja o Cliente        / Haber Venta de productos  (lo que cobras)
                Debe Costo merc. vendida   / Haber Mercancías          (lo que te costó lo vendido)
  merma         Debe Pérdidas y mermas     / Haber Mercancías
  sobrante      Debe Mercancías            / Haber Otros ingresos
Todo el valor del inventario se lleva en la moneda base (USD normalmente).
"""
from datetime import datetime

import contab as C
from contab import ErrorContable, r2

TIPOS = {"inicial": "Existencia inicial", "compra": "Compra", "costo_extra": "Costo extra (flete, aduana…)",
         "venta": "Venta", "merma": "Merma / pérdida", "sobrante": "Sobrante"}
UNIDADES = ["saco", "caja", "kg", "libra", "tonelada", "paquete", "unidad", "litro", "contenedor"]
ORIGENES_INV = ("compra_inventario", "costo_venta", "ajuste_inventario")


def unidades(p, cantidad):
    """'saco' -> 'sacos' cuando son varios."""
    u = p["unidad"]
    return u if abs(cantidad - 1) < 1e-9 or u.endswith("s") else (u + "es" if u[-1] in "lrnd" else u + "s")


def productos(conn, solo_activos=False):
    q = "SELECT * FROM productos" + (" WHERE activo = 1" if solo_activos else "") + " ORDER BY nombre"
    out = []
    ex = existencias(conn)
    for p in conn.execute(q):
        p = dict(p)
        cant, valor = ex.get(p["id"], (0.0, 0.0))
        p.update(cantidad=r2(cant), valor=r2(valor), promedio=(valor / cant) if cant > 0.0001 else 0.0,
                 bajo=bool(p["minimo"] and cant < p["minimo"]))
        out.append(p)
    return out


def producto(conn, pid):
    p = conn.execute("SELECT * FROM productos WHERE id = ?", (pid,)).fetchone()
    if not p:
        raise ErrorContable("Ese producto no existe.")
    return dict(p)


def existencias(conn, producto_id=None, hasta=None):
    q = "SELECT producto_id, SUM(cantidad) q, SUM(valor) v FROM mov_inventario WHERE 1=1"
    p = []
    if producto_id:
        q += " AND producto_id = ?"
        p.append(producto_id)
    if hasta:
        q += " AND fecha <= ?"
        p.append(hasta)
    return {f["producto_id"]: (f["q"] or 0.0, f["v"] or 0.0) for f in conn.execute(q + " GROUP BY producto_id", p)}


def _existencia(conn, pid):
    return existencias(conn, pid).get(pid, (0.0, 0.0))


def disponible_en(conn, pid, fecha, sin_mov=None):
    """Cuánto se puede sacar del producto con esa fecha sin que ningún día (ese o después) quede en negativo.
    Devuelve (disponible, había_ese_día). sin_mov: un movimiento que no se cuenta (al eliminarlo)."""
    corrido, minimo_desde, ese_dia = 0.0, None, 0.0
    for m in conn.execute("SELECT id, fecha, cantidad FROM mov_inventario WHERE producto_id = ? ORDER BY fecha, id", (pid,)):
        if m["id"] == sin_mov:
            continue
        corrido += m["cantidad"]
        if m["fecha"] <= fecha:
            ese_dia = corrido
        else:
            minimo_desde = corrido if minimo_desde is None else min(minimo_desde, corrido)
    disponible = ese_dia if minimo_desde is None else min(ese_dia, minimo_desde)
    return max(0.0, disponible), max(0.0, ese_dia)


def _comprobar_salida(conn, p, fecha, cantidad, que="vender"):
    disp, ese_dia = disponible_en(conn, p["id"], fecha)
    if cantidad <= disp + 0.0001:
        return
    f = datetime.strptime(fecha, "%Y-%m-%d").strftime("%d/%m/%Y")
    if cantidad > ese_dia + 0.0001:
        raise ErrorContable(f"El {f} solo había {ese_dia:g} {unidades(p, ese_dia)} de {p['nombre']}; no puedes {que} {cantidad:g}. "
                            "¿Es correcta la fecha? (Si la mercancía llegó después, anota la compra con su fecha antes.)")
    raise ErrorContable(f"Si sacas {cantidad:g} {unidades(p, cantidad)} de {p['nombre']} el {f}, más adelante quedarías en negativo "
                        f"(ya hay ventas o mermas después). Como máximo puedes {que} {disp:g}.")


def _guardar_mov(conn, fecha, pid, tipo, cantidad, valor, asiento_id, venta=0.0, lote=None, nota=None,
                 asiento_venta_id=None, contenedor_id=None):
    conn.execute("INSERT INTO mov_inventario (fecha, producto_id, tipo, cantidad, valor, venta, lote, nota, asiento_id,"
                 " asiento_venta_id, creado, contenedor_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                 (fecha, pid, tipo, cantidad, r2(valor), r2(venta), (lote or "").strip() or None,
                  (nota or "").strip() or None, asiento_id, asiento_venta_id,
                  datetime.now().isoformat(timespec="seconds"), contenedor_id))


def contenedor_por_nombre(conn, nombre, fecha=None, crear=True):
    """El contenedor con ese nombre (sin importar mayúsculas); si no existe, se crea."""
    nombre = " ".join((nombre or "").split())[:80]
    if not nombre:
        return None
    fila = conn.execute("SELECT id FROM contenedores WHERE LOWER(nombre) = LOWER(?)", (nombre,)).fetchone()
    if fila:
        return fila[0]
    if not crear:
        return None
    return conn.execute("INSERT INTO contenedores (nombre, fecha, creado) VALUES (?, ?, ?)",
                        (nombre, fecha, datetime.now().isoformat(timespec="seconds"))).lastrowid


def contenedores(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM contenedores ORDER BY COALESCE(fecha, creado) DESC, id DESC")]


def _base_de_linea(conn, asiento_id, cuenta_id):
    return r2(conn.execute("SELECT COALESCE(SUM(debe - haber), 0) FROM lineas WHERE asiento_id = ? AND cuenta_id = ?",
                           (asiento_id, cuenta_id)).fetchone()[0])


def _cantidad(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        raise ErrorContable("Escribe una cantidad válida.")
    if v != v or v <= 0 or v >= 1e9:  # v != v descarta "NaN"
        raise ErrorContable("La cantidad tiene que ser un número mayor que cero.")
    return v


def _contrapartida_pago(conn, pago, caja_id, moneda):
    """Devuelve (cuenta_id, moneda) de donde sale el dinero: una caja o 'antes de usar el programa'."""
    if pago == "apertura":
        return C.cuenta_por_rol(conn, "apertura")["id"], moneda
    caja = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0", (caja_id,)).fetchone()
    if not caja:
        raise ErrorContable("Elige la caja o banco.")
    return caja["id"], caja["moneda"] or C.moneda_base(conn)


def registrar_entrada(conn, tipo, fecha, pid, cantidad, importe, moneda, tasa, pago, caja_id=None, tercero_id=None,
                      numero=None, vencimiento=None, lote=None, nota=None):
    """tipo 'compra' (o 'inicial') con cantidad, o 'costo_extra' (flete, nacionalización) sin cantidad.
    pago: 'caja' (ya pagado), 'credito' (factura por pagar al proveedor) o 'apertura' (de antes de usar el programa)."""
    p = producto(conn, pid)
    if importe is None or importe <= 0:
        raise ErrorContable("Escribe el importe (lo que costó).")
    inv = C.cuenta_por_rol(conn, "inventario")["id"]
    if tipo == "costo_extra":
        cantidad = 0.0
        cant_actual, _ = _existencia(conn, pid)
        if cant_actual <= 0.0001:
            raise ErrorContable(f"No hay {p['nombre']} en existencia: anota primero la compra y después sus costos extra.")
        concepto = f"Costo extra de {p['nombre']}" + (f": {nota}" if nota else "")
    else:
        cantidad = _cantidad(cantidad)
        concepto = f"{'Existencia inicial' if pago == 'apertura' else 'Compra'} de {cantidad:g} {unidades(p, cantidad)} de {p['nombre']}"
        if lote:
            concepto += f" ({lote})"
    if pago == "credito":
        if not tercero_id:
            raise ErrorContable("Indica el proveedor al que le debes.")
        if moneda not in C.MONEDAS:
            raise ErrorContable("Elige la moneda.")
        did = C.registrar_documento(conn, "pagar", tercero_id, fecha, vencimiento, numero, concepto, inv, moneda,
                                    importe, tasa)
        aid = conn.execute("SELECT asiento_id FROM documentos WHERE id = ?", (did,)).fetchone()[0]
    else:
        contra, mon = _contrapartida_pago(conn, pago, caja_id, moneda)
        aid = C.crear_asiento(conn, fecha, concepto, [
            {"cuenta_id": inv, "importe": importe, "moneda": mon, "tercero_id": tercero_id},
            {"cuenta_id": contra, "importe": -importe, "moneda": mon, "tercero_id": tercero_id},
        ], "compra_inventario", numero, tasa=tasa)
    valor = _base_de_linea(conn, aid, inv)
    tipo_mov = "costo_extra" if tipo == "costo_extra" else ("inicial" if pago == "apertura" else "compra")
    cont = contenedor_por_nombre(conn, lote, fecha)
    _guardar_mov(conn, fecha, pid, tipo_mov, cantidad, valor, aid, lote=lote, nota=nota, contenedor_id=cont)
    return aid


def registrar_venta(conn, fecha, pid, cantidad, precio, moneda, tasa, cobro, caja_id=None, tercero_id=None,
                    numero=None, vencimiento=None, cuenta_venta=None, nota=None, contenedor_id=None):
    """Vende mercancía: anota lo que cobras (o la factura por cobrar) y el costo de lo vendido."""
    p = producto(conn, pid)
    cantidad = _cantidad(cantidad)
    if precio is None or precio <= 0:
        raise ErrorContable("Escribe el precio total de la venta.")
    cant_actual, valor_actual = _existencia(conn, pid)
    if cantidad > cant_actual + 0.0001:
        raise ErrorContable(f"Solo quedan {cant_actual:g} {unidades(p, cant_actual)} de {p['nombre']}; no puedes vender {cantidad:g}.")
    _comprobar_salida(conn, p, fecha, cantidad, "vender")
    cuenta_venta = cuenta_venta or conn.execute(
        "SELECT id FROM cuentas WHERE codigo = '4.1.01'").fetchone()[0]
    concepto = f"Venta de {cantidad:g} {unidades(p, cantidad)} de {p['nombre']}" + (f" ({nota})" if nota else "")
    if cobro == "credito":
        if not tercero_id:
            raise ErrorContable("Indica el cliente que te va a pagar.")
        did = C.registrar_documento(conn, "cobrar", tercero_id, fecha, vencimiento, numero, concepto, cuenta_venta,
                                    moneda, precio, tasa)
        aid_venta = conn.execute("SELECT asiento_id FROM documentos WHERE id = ?", (did,)).fetchone()[0]
    else:
        contra, mon = _contrapartida_pago(conn, "caja", caja_id, moneda)
        aid_venta = C.crear_asiento(conn, fecha, concepto, [
            {"cuenta_id": contra, "importe": precio, "moneda": mon, "tercero_id": tercero_id},
            {"cuenta_id": cuenta_venta, "importe": -precio, "moneda": mon, "tercero_id": tercero_id},
        ], "ingreso", numero, tasa=tasa)
    venta_base = -_base_de_linea(conn, aid_venta, cuenta_venta)
    costo = r2(valor_actual) if abs(cantidad - cant_actual) < 0.0001 else r2(valor_actual / cant_actual * cantidad)
    base = C.moneda_base(conn)
    aid = C.crear_asiento(conn, fecha, f"Costo de lo vendido: {cantidad:g} {unidades(p, cantidad)} de {p['nombre']}", [
        {"cuenta_id": C.cuenta_por_rol(conn, "costo_mercancia")["id"], "importe": costo, "moneda": base, "base": costo},
        {"cuenta_id": C.cuenta_por_rol(conn, "inventario")["id"], "importe": -costo, "moneda": base, "base": -costo},
    ], "costo_venta", tasa=tasa)
    _guardar_mov(conn, fecha, pid, "venta", -cantidad, -costo, aid, venta=venta_base, nota=nota, contenedor_id=contenedor_id,
                 asiento_venta_id=aid_venta)
    return aid_venta


def registrar_ajuste(conn, fecha, pid, cantidad, tipo, nota, tasa=None, valor_unit=None, contenedor_id=None):
    """tipo 'merma' (falta mercancía: se rompió, se perdió, la robaron) o 'sobrante' (apareció más de lo anotado)."""
    p = producto(conn, pid)
    cantidad = _cantidad(cantidad)
    cant_actual, valor_actual = _existencia(conn, pid)
    base = C.moneda_base(conn)
    inv = C.cuenta_por_rol(conn, "inventario")["id"]
    if tipo == "merma":
        if cantidad > cant_actual + 0.0001:
            raise ErrorContable(f"Solo hay {cant_actual:g} {unidades(p, cant_actual)}; la merma no puede ser mayor.")
        _comprobar_salida(conn, p, fecha, cantidad, "dar de baja")
        valor = r2(valor_actual) if abs(cantidad - cant_actual) < 0.0001 else r2(valor_actual / cant_actual * cantidad)
        lineas = [{"cuenta_id": C.cuenta_por_rol(conn, "mermas")["id"], "importe": valor, "moneda": base, "base": valor},
                  {"cuenta_id": inv, "importe": -valor, "moneda": base, "base": -valor}]
        concepto = f"Merma: {cantidad:g} {unidades(p, cantidad)} de {p['nombre']}"
        signo = -1
    else:
        unit = valor_unit if valor_unit else ((valor_actual / cant_actual) if cant_actual > 0.0001 else None)
        if not unit:
            raise ErrorContable("No se sabe cuánto vale cada unidad: escribe el valor por unidad.")
        valor = r2(unit * cantidad)
        lineas = [{"cuenta_id": inv, "importe": valor, "moneda": base, "base": valor},
                  {"cuenta_id": C.cuenta_por_rol(conn, "otros_ingresos")["id"], "importe": -valor, "moneda": base,
                   "base": -valor}]
        concepto = f"Sobrante: {cantidad:g} {unidades(p, cantidad)} de {p['nombre']}"
        signo = 1
    if nota:
        concepto += f" ({nota})"
    if valor <= 0:
        raise ErrorContable("Ese producto no tiene valor en inventario para ajustar.")
    aid = C.crear_asiento(conn, fecha, concepto, lineas, "ajuste_inventario", tasa=tasa)
    _guardar_mov(conn, fecha, pid, tipo, signo * cantidad, signo * valor, aid, nota=nota, contenedor_id=contenedor_id)
    return aid


def kardex(conn, pid, desde=None, hasta=None):
    """Movimientos del producto con existencia, valor y costo promedio acumulados."""
    filas = []
    q, v = 0.0, 0.0
    for m in conn.execute("SELECT m.*, a.numero FROM mov_inventario m LEFT JOIN asientos a ON a.id = m.asiento_id"
                          " WHERE m.producto_id = ? ORDER BY m.fecha, m.id", (pid,)):
        q += m["cantidad"]
        v += m["valor"]
        if desde and m["fecha"] < desde:
            continue
        if hasta and m["fecha"] > hasta:
            break
        f = dict(m)
        f.update(saldo_cant=r2(q), saldo_valor=r2(v), promedio=(v / q) if q > 0.0001 else 0.0,
                 tipo_txt=TIPOS.get(m["tipo"], m["tipo"]),
                 ganancia=r2(m["venta"] + m["valor"]) if m["tipo"] == "venta" else None)
        filas.append(f)
    return filas


def analisis_contenedores(conn):
    """Rentabilidad de cada contenedor (análisis, no cambia la contabilidad).
    - Costo real por unidad de cada contenedor = su compra + sus costos extra (flete, aduana…) ÷ unidades.
      Un costo extra sin contenedor se le asigna al último contenedor de ese producto que llegó antes.
    - Las ventas y mermas salen del contenedor elegido o, si no se eligió, del más antiguo con existencia (FIFO)."""
    conts = {c["id"]: c for c in contenedores(conn)}
    clientes = {r[0]: r[1] for r in conn.execute(
        "SELECT l.asiento_id, MIN(t.nombre) FROM lineas l JOIN terceros t ON t.id = l.tercero_id"
        " WHERE l.asiento_id IN (SELECT asiento_venta_id FROM mov_inventario WHERE tipo = 'venta') GROUP BY l.asiento_id")}
    lotes, fifo, ultima_entrada = {}, {}, {}

    def lote(cid, m):
        k = (cid or 0, m["producto_id"])
        if k not in lotes:
            lotes[k] = {"contenedor_id": cid or 0, "pid": m["producto_id"], "producto": m["producto"], "unidad": m["unidad"],
                        "entrada": 0.0, "costo_compra": 0.0, "costo_extra": 0.0, "vendido": 0.0, "ingresos": 0.0,
                        "merma": 0.0, "costos": [], "ventas": [], "llegada": m["fecha"]}
        return k

    for m in conn.execute("SELECT m.*, p.nombre producto, p.unidad FROM mov_inventario m JOIN productos p ON p.id = m.producto_id"
                          " ORDER BY m.fecha, m.id"):
        pid, t, q = m["producto_id"], m["tipo"], m["cantidad"]
        if t in ("compra", "inicial", "sobrante"):
            k = lote(m["contenedor_id"], m)
            L = lotes[k]
            L["entrada"] += q
            L["costo_compra"] += m["valor"]
            L["llegada"] = min(L["llegada"], m["fecha"])
            L["costos"].append({"fecha": m["fecha"], "tipo": {"compra": "Compra", "inicial": "Existencia inicial", "sobrante": "Sobrante"}[t],
                                "nota": m["nota"] or "", "valor": m["valor"], "cantidad": q})
            fifo.setdefault(pid, []).append([k, m["fecha"], q])
            ultima_entrada[pid] = k
        elif t == "costo_extra":
            k = lote(m["contenedor_id"], m) if m["contenedor_id"] else ultima_entrada.get(pid) or lote(None, m)
            lotes[k]["costo_extra"] += m["valor"]
            lotes[k]["costos"].append({"fecha": m["fecha"], "tipo": "Costo extra", "nota": m["nota"] or "", "valor": m["valor"],
                                       "cantidad": 0, "auto": not m["contenedor_id"]})
        elif t in ("venta", "merma"):
            falta, total = -q, -q
            cola = fifo.get(pid, [])
            orden = [e for e in cola if m["contenedor_id"] and e[0][0] == m["contenedor_id"]]
            orden += [e for e in cola if e not in orden and e[1] <= m["fecha"]] + [e for e in cola if e not in orden and e[1] > m["fecha"]]
            for e in orden:
                if falta <= 1e-9:
                    break
                toma = min(e[2], falta)
                if toma <= 1e-9:
                    continue
                e[2] -= toma
                falta -= toma
                L = lotes[e[0]]
                if t == "venta":
                    ing = m["venta"] * toma / total if total else 0.0
                    L["vendido"] += toma
                    L["ingresos"] += ing
                    L["ventas"].append({"fecha": m["fecha"], "cliente": clientes.get(m["asiento_venta_id"], ""), "cantidad": toma,
                                        "ingreso": ing, "asiento": m["asiento_venta_id"]})
                else:
                    L["merma"] += toma

    for L in lotes.values():
        L["costo_total"] = r2(L["costo_compra"] + L["costo_extra"])
        L["costo_unit"] = L["costo_total"] / L["entrada"] if L["entrada"] > 1e-9 else 0.0
        L["costo_vendido"] = r2(L["vendido"] * L["costo_unit"])
        L["perdida_merma"] = r2(L["merma"] * L["costo_unit"])
        L["quedan"] = max(0.0, L["entrada"] - L["vendido"] - L["merma"])
        L["valor_quedan"] = r2(L["quedan"] * L["costo_unit"])
        L["ingresos"] = r2(L["ingresos"])
        L["ganancia"] = r2(L["ingresos"] - L["costo_vendido"] - L["perdida_merma"])
        L["margen"] = round(L["ganancia"] / L["ingresos"] * 100, 1) if L["ingresos"] > 0.004 else None
        L["precio_prom"] = L["ingresos"] / L["vendido"] if L["vendido"] > 1e-9 else None
        L["pct_salido"] = round((L["vendido"] + L["merma"]) / L["entrada"] * 100) if L["entrada"] > 1e-9 else 0
        L["proyeccion"] = r2(L["ganancia"] + L["quedan"] * (L["precio_prom"] - L["costo_unit"])) if L["precio_prom"] else None

    salida = []
    for cid in list(conts) + [0]:
        ps = sorted([L for L in lotes.values() if L["contenedor_id"] == cid], key=lambda x: x["producto"])
        if cid and not ps:
            ps = []
        if not cid and not ps:
            continue
        c = dict(conts.get(cid) or {"id": 0, "nombre": "Sin contenedor", "fecha": None, "nota": "Compras sin contenedor asignado"})
        tot = {k: r2(sum(L[k] for L in ps)) for k in ("costo_total", "ingresos", "costo_vendido", "perdida_merma", "ganancia", "valor_quedan")}
        tot["margen"] = round(tot["ganancia"] / tot["ingresos"] * 100, 1) if tot["ingresos"] > 0.004 else None
        proy = [L["proyeccion"] for L in ps if L["proyeccion"] is not None]
        tot["proyeccion"] = r2(sum(proy) + sum(L["ganancia"] for L in ps if L["proyeccion"] is None)) if proy else None
        entradas = sum(L["entrada"] for L in ps)
        tot["pct_salido"] = round(sum(L["vendido"] + L["merma"] for L in ps) / entradas * 100) if entradas > 1e-9 else 0
        ventas = sorted([v for L in ps for v in L["ventas"]], key=lambda v: v["fecha"])
        c["llegada"] = c.get("fecha") or min((L["llegada"] for L in ps), default=None)
        c["primera_venta"] = ventas[0]["fecha"] if ventas else None
        c["ultima_venta"] = ventas[-1]["fecha"] if ventas else None
        c["estado"] = ("Sin mercancía todavía" if not ps else "Vendido" if all(L["quedan"] < 1e-6 for L in ps)
                       else "En venta" if ventas else "Sin vender")
        c.update(productos=ps, totales=tot)
        salida.append(c)
    return salida


def ganancia_por_producto(conn, desde=None, hasta=None):
    q = ("SELECT p.id, p.nombre, p.unidad, -SUM(m.cantidad) cant, SUM(m.venta) venta, -SUM(m.valor) costo"
         " FROM mov_inventario m JOIN productos p ON p.id = m.producto_id WHERE m.tipo = 'venta'")
    par = []
    if desde:
        q += " AND m.fecha >= ?"
        par.append(desde)
    if hasta:
        q += " AND m.fecha <= ?"
        par.append(hasta)
    out = []
    for f in conn.execute(q + " GROUP BY p.id ORDER BY venta DESC", par):
        f = dict(f)
        f["ganancia"] = r2(f["venta"] - f["costo"])
        f["margen"] = (f["ganancia"] / f["venta"]) if f["venta"] > 0.004 else None
        out.append(f)
    return out


def valor_contable(conn):
    """Saldo de la cuenta Mercancías en la contabilidad (para comprobar que coincide con el inventario)."""
    inv = C.cuenta_por_rol(conn, "inventario")["id"]
    return r2(conn.execute("SELECT COALESCE(SUM(l.debe - l.haber), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                           " WHERE a.anulado = 0 AND l.cuenta_id = ?", (inv,)).fetchone()[0])


def movs_de_asiento(conn, aid):
    return conn.execute("SELECT * FROM mov_inventario WHERE asiento_id = ? OR asiento_venta_id = ?", (aid, aid)).fetchall()


def eliminar_movs_de_asiento(conn, aid):
    """Se llama al eliminar un asiento: borra lo del inventario que depende de él (y el costo de lo vendido)."""
    for m in conn.execute("SELECT * FROM mov_inventario WHERE asiento_venta_id = ?", (aid,)).fetchall():
        if m["asiento_id"]:
            conn.execute("DELETE FROM lineas WHERE asiento_id = ?", (m["asiento_id"],))
            conn.execute("DELETE FROM asientos WHERE id = ?", (m["asiento_id"],))
        conn.execute("DELETE FROM mov_inventario WHERE id = ?", (m["id"],))
    for m in conn.execute("SELECT * FROM mov_inventario WHERE asiento_id = ?", (aid,)).fetchall():
        if m["tipo"] == "venta":
            raise ErrorContable("Este es el costo de una venta: elimina la venta y se borra todo junto.")
        cant, valor = _existencia(conn, m["producto_id"])
        if cant - m["cantidad"] < -0.0001 or (m["cantidad"] > 0 and _negativo_sin(conn, m)):
            p = producto(conn, m["producto_id"])
            raise ErrorContable(f"Si eliminas esta entrada, {p['nombre']} quedaría en negativo (ya se vendió). "
                                "Elimina primero las ventas de después.")
        conn.execute("DELETE FROM mov_inventario WHERE id = ?", (m["id"],))


def _negativo_sin(conn, mov):
    """True si al quitar esa entrada algún día quedaría con existencias negativas."""
    corrido = 0.0
    for m in conn.execute("SELECT id, cantidad FROM mov_inventario WHERE producto_id = ? ORDER BY fecha, id", (mov["producto_id"],)):
        if m["id"] == mov["id"]:
            continue
        corrido += m["cantidad"]
        if corrido < -0.0001:
            return True
    return False


# ---------------------------------------------------------------- caja

def resumen_cajas(conn, dias=60):
    """Una tarjeta por caja/banco: saldo, lo que entró y salió este mes, y la curva de saldo de los últimos días."""
    from datetime import date, timedelta
    hoy = date.today()
    ini_mes = hoy.replace(day=1).isoformat()
    desde = (hoy - timedelta(days=dias)).isoformat()
    base = C.moneda_base(conn)
    out = []
    for c in C.cuentas(conn, solo_activas=True):
        if not c["es_efectivo"] or c["es_grupo"]:
            continue
        mon = c["moneda"] or base
        col = "l.importe_orig" if c["moneda"] else "(l.debe - l.haber)"
        filas = conn.execute(f"SELECT a.fecha, SUM({col}) v, SUM(l.debe - l.haber) b FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                             f" WHERE a.anulado = 0 AND l.cuenta_id = ? GROUP BY a.fecha ORDER BY a.fecha", (c["id"],)).fetchall()
        saldo = sum(f["v"] for f in filas)
        base_v = sum(f["b"] for f in filas)
        entra = conn.execute(f"SELECT COALESCE(SUM(CASE WHEN {col} > 0 THEN {col} END), 0) FROM lineas l JOIN asientos a"
                             f" ON a.id = l.asiento_id WHERE a.anulado = 0 AND l.cuenta_id = ? AND a.fecha >= ?",
                             (c["id"], ini_mes)).fetchone()[0]
        sale = -conn.execute(f"SELECT COALESCE(SUM(CASE WHEN {col} < 0 THEN {col} END), 0) FROM lineas l JOIN asientos a"
                             f" ON a.id = l.asiento_id WHERE a.anulado = 0 AND l.cuenta_id = ? AND a.fecha >= ?",
                             (c["id"], ini_mes)).fetchone()[0]
        # curva diaria
        puntos, acum = [], sum(f["v"] for f in filas if f["fecha"] < desde)
        por_fecha = {f["fecha"]: f["v"] for f in filas}
        d = hoy - timedelta(days=dias)
        while d <= hoy:
            acum += por_fecha.get(d.isoformat(), 0)
            puntos.append(acum)
            d += timedelta(days=1)
        out.append({"id": c["id"], "nombre": c["nombre"], "moneda": mon, "saldo": r2(saldo), "base": r2(base_v),
                    "entra": r2(entra), "sale": r2(sale), "curva": _curva(puntos), "movs": len(filas)})
    return out


def _curva(puntos, ancho=220, alto=46):
    if not puntos:
        return ""
    lo, hi = min(puntos + [0]), max(puntos + [0])
    rango = (hi - lo) or 1
    n = max(len(puntos) - 1, 1)
    return " ".join(f"{i * ancho / n:.1f},{alto - (p - lo) / rango * alto:.1f}" for i, p in enumerate(puntos))


def libro_caja(conn, caja_id, desde, hasta):
    c = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1", (caja_id,)).fetchone()
    if not c:
        raise ErrorContable("Esa caja no existe.")
    col = "l.importe_orig" if c["moneda"] else "(l.debe - l.haber)"
    inicial = conn.execute(f"SELECT COALESCE(SUM({col}), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                           f" WHERE a.anulado = 0 AND l.cuenta_id = ? AND a.fecha < ?", (caja_id, desde)).fetchone()[0]
    saldo = inicial
    filas = []
    for l in conn.execute(f"SELECT l.*, {col} v, a.fecha, a.numero, a.concepto, a.origen, a.id aid, t.nombre tercero"
                          f" FROM lineas l JOIN asientos a ON a.id = l.asiento_id LEFT JOIN terceros t ON t.id = l.tercero_id"
                          f" WHERE a.anulado = 0 AND l.cuenta_id = ? AND a.fecha >= ? AND a.fecha <= ?"
                          f" ORDER BY a.fecha, a.numero, l.id", (caja_id, desde, hasta)):
        saldo += l["v"]
        contra = conn.execute("SELECT GROUP_CONCAT(cu.nombre, ', ') FROM lineas x JOIN cuentas cu ON cu.id = x.cuenta_id"
                              " WHERE x.asiento_id = ? AND x.cuenta_id != ?", (l["aid"], caja_id)).fetchone()[0]
        filas.append({"fecha": l["fecha"], "numero": l["numero"], "aid": l["aid"], "concepto": l["concepto"],
                      "tercero": l["tercero"], "contra": contra, "origen": C.ORIGENES.get(l["origen"], l["origen"]),
                      "entra": r2(l["v"]) if l["v"] > 0 else None, "sale": r2(-l["v"]) if l["v"] < 0 else None,
                      "saldo": r2(saldo)})
    return dict(c), r2(inicial), filas, r2(saldo)


def saldo_caja(conn, caja_id, hasta=None):
    c = conn.execute("SELECT * FROM cuentas WHERE id = ?", (caja_id,)).fetchone()
    col = "l.importe_orig" if c["moneda"] else "(l.debe - l.haber)"
    q = f"SELECT COALESCE(SUM({col}), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id WHERE a.anulado = 0 AND l.cuenta_id = ?"
    p = [caja_id]
    if hasta:
        q += " AND a.fecha <= ?"
        p.append(hasta)
    return r2(conn.execute(q, p).fetchone()[0])


def registrar_arqueo(conn, fecha, caja_id, contado, tasa, nota=None):
    """Cuentas el dinero de verdad; si no coincide con el programa, se anota el sobrante o faltante."""
    c = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1", (caja_id,)).fetchone()
    if not c:
        raise ErrorContable("Esa caja no existe.")
    if contado is None or contado < 0:
        raise ErrorContable("Escribe cuánto dinero contaste.")
    libro = saldo_caja(conn, caja_id, fecha)
    dif = r2(contado - libro)
    if abs(dif) < 0.005:
        return None, 0.0
    mon = c["moneda"] or C.moneda_base(conn)
    if dif > 0:
        contra, concepto = C.cuenta_por_rol(conn, "otros_ingresos")["id"], f"Arqueo de {c['nombre']}: sobrante"
    else:
        contra, concepto = C.cuenta_por_rol(conn, "mermas")["id"], f"Arqueo de {c['nombre']}: faltante"
    if nota:
        concepto += f" ({nota})"
    aid = C.crear_asiento(conn, fecha, concepto, [
        {"cuenta_id": caja_id, "importe": dif, "moneda": mon},
        {"cuenta_id": contra, "importe": -dif, "moneda": mon},
    ], "arqueo", tasa=tasa)
    return aid, dif
