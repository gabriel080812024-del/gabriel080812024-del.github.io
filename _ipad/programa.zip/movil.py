"""Exportar una "foto" de los datos para verla en el teléfono (app visor, solo lectura, sin internet).

El archivo va cifrado con AES-256-GCM. La llave se saca de una contraseña elegida para el móvil con
PBKDF2-SHA256 (600 000 vueltas): el mismo método que el iPhone sabe hacer sin instalar nada (WebCrypto).
"""
import base64
import json
import os
from datetime import date, datetime, timedelta

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

import contab as C
import db
import inventario as INV

VUELTAS = 600_000


def _informe(inf):
    def v(x):
        if isinstance(x, tuple):
            return [x[0], x[1]]
        return x
    return {"titulo": inf.titulo, "subtitulo": inf.subtitulo, "columnas": inf.columnas, "formatos": inf.formatos,
            "nota": inf.nota,
            "filas": [{"e": f["etiqueta"], "v": [v(x) for x in f["valores"]], "s": f["estilo"], "n": f["nivel"],
                       "f": f.get("fmt"), "c": f.get("codigo") if inf.titulo.startswith("Indicadores") else None}
                      for f in inf.filas]}


def _estado_cuenta(conn, tid, lado):
    ec = C.estado_cuenta(conn, tid, lado)
    return {"cargos": [{"fecha": x["fecha"], "texto": x["texto"], "moneda": x["moneda"], "importe": x["importe"],
                        "vencida": bool(x["doc"] and x["doc"]["vencida"]),
                        "pagada": bool(x["doc"] and x["doc"]["estado"] == "Pagada"),
                        "vence": x["doc"]["vencimiento"] if x["doc"] else None} for x in ec["cargos"]],
            "pagos": [{"fecha": x["fecha"], "texto": x["nota"] or x["texto"], "moneda": x["moneda"], "importe": x["importe"]}
                      for x in ec["pagos"]],
            "tot": ec["tot"]}


def foto(conn, usuario=""):
    hoy = date.today()
    base = C.moneda_base(conn)
    r = C.resumen_panel(conn)
    datos = {
        "version": 1, "creado": datetime.now().isoformat(timespec="seconds"), "por": usuario,
        "empresa": C.nombre_empresa(conn), "base": base, "tasa": C.tasa_del_dia(conn),
        "resumen": {k: r[k] for k in ("mes", "ingresos", "gastos", "resultado", "anio", "efectivo")},
        "grafico": r["grafico"],
        "top_gastos": [{"nombre": g["nombre"], "v": g["v"]} for g in r["top_gastos"]],
        "vencidas": [{"tipo": d["tipo"], "tercero": d["tercero"], "concepto": d["concepto"], "vence": d["vencimiento"],
                      "pendiente": d["pendiente"], "moneda": d["moneda"]} for d in r["vencidas_c"] + r["vencidas_p"]],
    }
    # cajas y su libro (últimos 3 meses)
    desde = (hoy.replace(day=1) - timedelta(days=62)).replace(day=1).isoformat()
    cajas = []
    for k in INV.resumen_cajas(conn):
        _, inicial, filas, final = INV.libro_caja(conn, k["id"], desde, hoy.isoformat())
        cajas.append({"id": k["id"], "nombre": k["nombre"], "moneda": k["moneda"], "saldo": k["saldo"], "base": k["base"],
                      "entra": k["entra"], "sale": k["sale"], "inicial": inicial, "desde": desde,
                      "movs": [{"fecha": f["fecha"], "concepto": f["concepto"], "tercero": f["tercero"], "entra": f["entra"],
                                "sale": f["sale"], "saldo": f["saldo"]} for f in reversed(filas)]})
    datos["cajas"] = cajas
    # me deben / debo, con el estado de cuenta de cada persona
    for lado in ("cobrar", "pagar"):
        filas, tot = C.resumen_lado(conn, lado)
        tramos = {t["id"]: t for t in C.saldos_terceros(conn, lado)}
        antig = [0.0] * 6  # por vencer, 1-30, 31-60, 61-90, +90, sin factura (en moneda base)
        for t in tramos.values():
            for i, v in enumerate(t["tramos"] + [t["sin_factura"]]):
                antig[i] += v
        datos[lado] = {"total": tot, "antiguedad": [C.r2(x) for x in antig],
                       "personas": [dict(f, estado=_estado_cuenta(conn, f["id"], lado),
                                         tramos=(tramos[f["id"]]["tramos"] + [tramos[f["id"]]["sin_factura"]]) if f["id"] in tramos else None)
                                    for f in filas]}
    # inventario
    prods = []
    for p in INV.productos(conn, solo_activos=True):
        k = INV.kardex(conn, p["id"])
        k.reverse()
        prods.append({"id": p["id"], "nombre": p["nombre"], "unidad": p["unidad"], "cantidad": p["cantidad"],
                      "valor": p["valor"], "promedio": p["promedio"], "bajo": p["bajo"], "minimo": p["minimo"],
                      "kardex": [{"fecha": m["fecha"], "tipo": m["tipo_txt"], "nota": " · ".join(x for x in (m["lote"], m["nota"]) if x),
                                  "cantidad": m["cantidad"], "quedan": m["saldo_cant"], "valor": m["valor"],
                                  "venta": m["venta"] if m["tipo"] == "venta" else None, "ganancia": m["ganancia"]}
                                 for m in k[:80]]})
    datos["inventario"] = {"productos": prods, "total": C.r2(sum(p["valor"] for p in prods)),
                           "ganancias": INV.ganancia_por_producto(conn, f"{hoy.year}-01-01", hoy.isoformat())}
    # estados financieros (como en la Mac)
    estados = {}
    for periodo, n in (("anual", 5), ("trimestral", 8), ("mensual", 12)):
        cols = C.columnas_terminal(conn, periodo, n)
        per = C.per_terminal(cols)
        res, d = C.informe_resultados_terminal(conn, cols, detalle=True)
        bal = C.informe_balance(conn, per)[0]
        bal.columnas = [x[2] for x in cols]
        bal.titulo = "Balance general"
        estados[periodo] = {"resultados": _informe(res), "balance": _informe(bal), "flujo": _informe(C.informe_flujo(conn, per)),
                            "indicadores": _informe(C.indicadores_terminal(conn, cols)),
                            "gastos": _informe(C.informe_por_tipo(conn, per, "gasto", con_total=False)),
                            "neto": d["neto"], "columnas": [x[2] for x in cols]}
    datos["estados"] = estados
    # balance resumido (para la portada)
    ult = estados["mensual"]["balance"]["filas"]
    def tot(nombre):
        f = next((x for x in ult if x["e"] == nombre), None)
        return f["v"][-1] if f and f["v"] else 0
    datos["balance"] = {"activo": tot("TOTAL ACTIVO"), "pasivo": tot("TOTAL PASIVO"), "patrimonio": tot("TOTAL PATRIMONIO")}
    # últimos movimientos
    movs = []
    for a in conn.execute("SELECT * FROM asientos WHERE anulado = 0 ORDER BY fecha DESC, numero DESC LIMIT 200"):
        lineas = conn.execute("SELECT cu.nombre cuenta, t.nombre tercero, l.debe, l.haber, l.moneda, l.importe_orig"
                              " FROM lineas l JOIN cuentas cu ON cu.id = l.cuenta_id LEFT JOIN terceros t ON t.id = l.tercero_id"
                              " WHERE l.asiento_id = ? ORDER BY l.debe = 0, l.id", (a["id"],)).fetchall()
        movs.append({"numero": a["numero"], "fecha": a["fecha"], "concepto": a["concepto"],
                     "tipo": C.ORIGENES.get(a["origen"], a["origen"]), "por": a["usuario"],
                     "lineas": [dict(l) for l in lineas]})
    datos["movimientos"] = movs
    return datos


def cifrar_foto(datos, clave):
    sal, iv = os.urandom(16), os.urandom(12)
    llave = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=sal, iterations=VUELTAS).derive(clave.encode())
    crudo = json.dumps(datos, ensure_ascii=False, separators=(",", ":")).encode()
    ct = AESGCM(llave).encrypt(iv, crudo, b"mi-contabilidad-visor-v1")
    b = lambda x: base64.b64encode(x).decode()
    return json.dumps({"tipo": "mi-contabilidad-visor", "v": 1, "kdf": "PBKDF2-SHA256", "vueltas": VUELTAS,
                       "sal": b(sal), "iv": b(iv), "datos": b(ct)}).encode()


def descifrar_foto(blob, clave):
    """Para las pruebas (el iPhone hace lo mismo con WebCrypto)."""
    d = json.loads(blob)
    sal, iv, ct = (base64.b64decode(d[k]) for k in ("sal", "iv", "datos"))
    llave = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=sal, iterations=d["vueltas"]).derive(clave.encode())
    return json.loads(AESGCM(llave).decrypt(iv, ct, b"mi-contabilidad-visor-v1"))
