"""Flujo de caja de las próximas semanas: ¿alcanza el dinero para lo que viene?

Parte del dinero que hay hoy en todas las cajas y bancos y suma/resta, semana a semana:
  + cobros de facturas que te deben (por su vencimiento)      - pagos de facturas que debes (por su vencimiento)
  + ventas al contado estimadas (promedio de 8 semanas)       - gastos fijos estimados (promedio de 3 meses)
  +/- lo que ya está anotado con fecha futura en las cajas     +/- lo atrasado (vencido), en la primera semana
Todo en la moneda base (los CUP a la tasa de hoy)."""
from datetime import date, timedelta

import contab as C
from db import get_config, set_config

AJUSTES = {"flujo_semanas": "8", "flujo_ventas": "1", "flujo_atrasados": "1", "flujo_gastos_mes": "", "flujo_minimo": "0"}


def ajustes(conn):
    a = {k: get_config(conn, k, v) for k, v in AJUSTES.items()}
    return {"semanas": int(a["flujo_semanas"]) if a["flujo_semanas"] in ("4", "8", "12") else 8,
            "ventas": a["flujo_ventas"] == "1", "atrasados": a["flujo_atrasados"] == "1",
            "gastos_mes": float(a["flujo_gastos_mes"]) if a["flujo_gastos_mes"] not in ("", None) else None,
            "minimo": float(a["flujo_minimo"] or 0)}


def guardar_ajustes(conn, semanas, ventas, atrasados, gastos_mes, minimo):
    set_config(conn, "flujo_semanas", str(semanas if semanas in (4, 8, 12) else 8))
    set_config(conn, "flujo_ventas", "1" if ventas else "0")
    set_config(conn, "flujo_atrasados", "1" if atrasados else "0")
    set_config(conn, "flujo_gastos_mes", "" if gastos_mes is None else str(round(gastos_mes, 2)))
    set_config(conn, "flujo_minimo", str(round(minimo or 0, 2)))


def _efectivo_hoy(conn, hoy):
    ids = [r[0] for r in conn.execute("SELECT id FROM cuentas WHERE es_efectivo = 1 AND es_grupo = 0")]
    m = C.movimientos(conn, None, hoy)
    return C.r2(sum(m.get(i, (0, 0, 0))[0] - m.get(i, (0, 0, 0))[1] for i in ids))


def gastos_fijos_estimados(conn, hoy):
    """Promedio mensual de gastos pagados en el momento (alquiler, salarios, corriente…) de los 3 últimos meses completos."""
    primero = hoy.replace(day=1)
    desde = (primero - timedelta(days=1)).replace(day=1)
    for _ in range(2):
        desde = (desde - timedelta(days=1)).replace(day=1)
    v = conn.execute(
        "SELECT COALESCE(SUM(l.debe - l.haber), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " JOIN cuentas cu ON cu.id = l.cuenta_id WHERE a.anulado = 0 AND a.origen = 'gasto' AND cu.tipo = 'gasto'"
        " AND cu.seccion IN ('operacion', 'impuesto') AND a.fecha >= ? AND a.fecha < ?",
        (desde.isoformat(), primero.isoformat())).fetchone()[0]
    return C.r2(v / 3)


def ventas_contado_semanales(conn, lunes):
    """Promedio semanal de lo que entró a las cajas por ventas e ingresos cobrados en el momento (8 semanas)."""
    v = conn.execute(
        "SELECT COALESCE(SUM(l.debe - l.haber), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " JOIN cuentas cu ON cu.id = l.cuenta_id WHERE a.anulado = 0 AND a.origen = 'ingreso' AND cu.es_efectivo = 1"
        " AND a.fecha >= ? AND a.fecha < ?", ((lunes - timedelta(days=56)).isoformat(), lunes.isoformat())).fetchone()[0]
    return C.r2(v / 8)


def proyeccion(conn, semanas=None, ventas=None, atrasados=None, gastos_mes=None, minimo=None, hoy=None):
    a = ajustes(conn)
    semanas = semanas or a["semanas"]
    ventas = a["ventas"] if ventas is None else ventas
    atrasados = a["atrasados"] if atrasados is None else atrasados
    minimo = a["minimo"] if minimo is None else minimo
    hoy = hoy or date.today()
    lunes = hoy - timedelta(days=hoy.weekday())
    base = C.moneda_base(conn)
    tasa = C.tasa_del_dia(conn) or 0
    a_base = lambda v, m: C.r2(C.convertir(v, m, base, tasa)) if (m == base or tasa) else 0.0
    estimado = gastos_fijos_estimados(conn, hoy)
    manual = gastos_mes if gastos_mes is not None else a["gastos_mes"]  # None = usar lo estimado
    gmes = estimado if manual is None else manual
    venta_sem = ventas_contado_semanales(conn, lunes)
    cols = []
    for i in range(semanas):
        ini = lunes + timedelta(days=7 * i)
        cols.append({"desde": ini, "hasta": ini + timedelta(days=6), "cobros": 0.0, "pagos": 0.0, "cobros_atrasados": 0.0,
                     "pagos_atrasados": 0.0, "futuro": 0.0, "ventas": 0.0, "gastos": 0.0, "detalle": []})
    fin = cols[-1]["hasta"]
    sin_fecha = {"cobrar": [], "pagar": []}
    despues = {"cobrar": 0.0, "pagar": 0.0}
    for lado in ("cobrar", "pagar"):
        for d in C.documentos(conn, lado, solo_pendientes=True):
            if d["pendiente"] <= 0.004:
                continue
            v = a_base(d["pendiente"], d["moneda"])
            item = {"lado": lado, "tercero": d["tercero"], "numero": d["numero"] or d["id"], "id": d["id"], "vence": d["vencimiento"],
                    "importe": d["pendiente"], "moneda": d["moneda"], "base": v}
            if not d["vencimiento"]:
                sin_fecha[lado].append(item)
                continue
            vence = date.fromisoformat(d["vencimiento"])
            if vence < lunes:
                if atrasados:
                    cols[0]["cobros_atrasados" if lado == "cobrar" else "pagos_atrasados"] += v
                    cols[0]["detalle"].append(dict(item, atrasado=True))
                continue
            if vence > fin:
                despues[lado] += v
                continue
            k = cols[(vence - lunes).days // 7]
            k["cobros" if lado == "cobrar" else "pagos"] += v
            k["detalle"].append(dict(item, atrasado=False))
    # lo ya anotado en las cajas con fecha futura (después de hoy)
    for r in conn.execute("SELECT a.fecha, SUM(l.debe - l.haber) v FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                          " JOIN cuentas cu ON cu.id = l.cuenta_id WHERE a.anulado = 0 AND cu.es_efectivo = 1 AND a.fecha > ?"
                          " AND a.fecha <= ? GROUP BY a.fecha", (hoy.isoformat(), fin.isoformat())):
        cols[(date.fromisoformat(r["fecha"]) - lunes).days // 7]["futuro"] += r["v"]
    semana_gasto = C.r2(gmes * 12 / 52)
    saldo = _efectivo_hoy(conn, hoy.isoformat())
    hoy_saldo = saldo
    for i, k in enumerate(cols):
        dias = 7 if i else 7 - hoy.weekday()  # la semana en curso solo cuenta los días que quedan (hoy incluido)
        k["ventas"] = C.r2(venta_sem * dias / 7) if ventas else 0.0
        k["gastos"] = C.r2(semana_gasto * dias / 7)
        k["inicio"] = C.r2(saldo)
        k["entra"] = C.r2(k["cobros"] + k["cobros_atrasados"] + k["ventas"] + max(k["futuro"], 0))
        k["sale"] = C.r2(k["pagos"] + k["pagos_atrasados"] + k["gastos"] + max(-k["futuro"], 0))
        for x in ("cobros", "pagos", "cobros_atrasados", "pagos_atrasados", "futuro"):
            k[x] = C.r2(k[x])
        saldo = saldo + k["entra"] - k["sale"]
        k["final"] = C.r2(saldo)
        k["alerta"] = k["final"] < minimo - 0.004
        k["detalle"].sort(key=lambda x: (x["vence"] or "", x["lado"]))
    peor = min(cols, key=lambda k: k["final"])
    return {"hoy": hoy, "base": base, "tasa": tasa, "efectivo": hoy_saldo, "semanas": cols, "peor": peor, "minimo": minimo,
            "gastos_mes": C.r2(gmes), "gastos_estimado": estimado, "gastos_fijos_manual": manual is not None,
            "venta_semana": venta_sem, "ventas": ventas, "atrasados": atrasados, "sin_fecha": sin_fecha,
            "despues": {k: C.r2(v) for k, v in despues.items()}, "n": semanas}


def primera_alerta(conn):
    """La primera semana en que el dinero bajaría del mínimo (para 'Para revisar'), o None."""
    p = proyeccion(conn)
    return next((k for k in p["semanas"] if k["alerta"]), None), p
