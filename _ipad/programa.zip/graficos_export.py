"""Exportar el gráfico de partidas de los estados financieros: imagen (PNG), PDF (gráfico + tabla) y Excel
(tabla + gráfico de Excel de verdad, que se puede editar). Funciona igual en la Mac y en el iPad, sin internet."""
import base64
import io
import json
import re
from datetime import datetime

from fpdf import FPDF

from documentos_pdf import GRIS, LINEA, TEXTO, VERDE, t


class ErrorGrafico(Exception):
    pass


def leer(datos_json, imagen=None):
    try:
        d = json.loads(datos_json or "")
    except ValueError:
        raise ErrorGrafico("No llegaron los datos del gráfico.")
    if not isinstance(d, dict) or not isinstance(d.get("filas"), list) or not d["filas"] or len(d["filas"]) > 6:
        raise ErrorGrafico("Elige entre 1 y 6 filas para el gráfico.")
    cols = [str(c)[:30] for c in (d.get("columnas") or [])][:40]
    filas = []
    for f in d["filas"]:
        v = f.get("v") or []
        vals = [(float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) and abs(x) < 1e13 else None) for x in v][:len(cols)]
        vals += [None] * (len(cols) - len(vals))
        color = f.get("color") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(f.get("color") or "")) else "#0f766e"
        filas.append({"etiqueta": str(f.get("etiqueta") or "")[:80], "f": str(f.get("f") or "n")[:5], "v": vals, "color": color})
    png = None
    if imagen:
        m = re.match(r"data:image/png;base64,(.+)$", imagen, re.S)
        if not m or len(imagen) > 12_000_000:
            raise ErrorGrafico("La imagen del gráfico no es válida.")
        png = base64.b64decode(m.group(1))
        if not png.startswith(b"\x89PNG"):
            raise ErrorGrafico("La imagen del gráfico no es válida.")
    return {"titulo": str(d.get("titulo") or "Gráfico")[:90], "subtitulo": str(d.get("subtitulo") or "")[:160],
            "columnas": cols, "filas": filas, "tipo": "lineas" if d.get("tipo") == "lineas" else "barras",
            "modo": "crec" if d.get("modo") == "crec" else "valores"}, png


def nombre_archivo(d, ext):
    base = re.sub(r"[^\w\- ]+", " ", d["titulo"].replace("&", ""), flags=re.UNICODE)
    base = re.sub(r"[\s_]+", "_", base).strip("_")[:60] or "grafico"
    return f"{base}.{ext}"


def _fmt(v, f):
    if v is None:
        return "-"
    if f in ("%", "p"):
        return f"{v:,.1f} %"
    if f == "r":
        return f"{v:,.2f}"
    if f == "d":
        return f"{v:,.0f} días"
    s = f"{abs(v):,.2f}"
    return f"({s})" if v < 0 else s


def pdf(d, png, empresa):
    """Hoja apaisada: título, el gráfico tal como se ve y la tabla con los números."""
    doc = FPDF(orientation="L", unit="mm", format="A4")
    doc.set_auto_page_break(True, 14)
    doc.set_margins(14, 12, 14)
    doc.add_page()
    doc.set_text_color(*VERDE)
    doc.set_font("Helvetica", "B", 9)
    doc.cell(0, 5, t(empresa.upper()), new_x="LMARGIN", new_y="NEXT")
    doc.set_text_color(*TEXTO)
    doc.set_font("Helvetica", "B", 16)
    doc.multi_cell(0, 7.5, t(d["titulo"]), new_x="LMARGIN", new_y="NEXT")
    doc.set_font("Helvetica", "", 9.5)
    doc.set_text_color(*GRIS)
    doc.cell(0, 5, t(d["subtitulo"] + " · " + datetime.now().strftime("%d/%m/%Y")), new_x="LMARGIN", new_y="NEXT")
    doc.ln(2)
    if png:
        ancho = doc.w - doc.l_margin - doc.r_margin
        doc.image(io.BytesIO(png), x=doc.l_margin, w=ancho)
        doc.ln(3)
    # tabla: una fila por partida, una columna por período (si son muchas, se parte en bloques)
    cols = d["columnas"]
    util = doc.w - doc.l_margin - doc.r_margin
    w_et = 62
    por_bloque = max(1, min(len(cols), int((util - w_et) // 24)))
    for ini in range(0, len(cols), por_bloque):
        parte = cols[ini:ini + por_bloque]
        wc = (util - w_et) / len(parte)
        if doc.get_y() > doc.h - 40:
            doc.add_page()
        doc.set_font("Helvetica", "B", 8.5)
        doc.set_fill_color(*VERDE)
        doc.set_text_color(255, 255, 255)
        doc.cell(w_et, 7, t("Partida"), fill=True)
        for c in parte:
            doc.cell(wc, 7, t(c), fill=True, align="R")
        doc.ln()
        doc.set_font("Helvetica", "", 8.5)
        for i, f in enumerate(d["filas"]):
            doc.set_fill_color(*((243, 248, 246) if i % 2 else (255, 255, 255)))
            r, g, b = (int(f["color"][k:k + 2], 16) for k in (1, 3, 5))
            y = doc.get_y()
            doc.set_text_color(*TEXTO)
            doc.cell(w_et, 7, "", fill=True)
            doc.set_fill_color(r, g, b)
            doc.rect(doc.l_margin + 1.5, y + 2, 3, 3, style="F")
            doc.set_xy(doc.l_margin + 6, y)
            doc.cell(w_et - 6, 7, t(f["etiqueta"])[:44])
            doc.set_fill_color(*((243, 248, 246) if i % 2 else (255, 255, 255)))
            for v in f["v"][ini:ini + por_bloque]:
                doc.set_text_color(*((198, 40, 40) if v is not None and v < 0 else TEXTO))
                doc.cell(wc, 7, t(_fmt(v, f["f"])), fill=True, align="R")
            doc.ln()
        doc.set_draw_color(*LINEA)
        doc.line(doc.l_margin, doc.get_y(), doc.w - doc.r_margin, doc.get_y())
        doc.ln(4)
    doc.set_text_color(*GRIS)
    doc.set_font("Helvetica", "", 8)
    doc.cell(0, 5, t("Hecho con Mi Contabilidad"), new_x="LMARGIN", new_y="NEXT")
    return bytes(doc.output())


def excel(d, empresa):
    """Libro con la tabla y un gráfico de Excel de verdad (se puede cambiar de tipo, colores, etc. en Excel o Numbers)."""
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, LineChart, Reference
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Gráfico"
    ws["A1"] = empresa
    ws["A1"].font = Font(bold=True, color="0B5D56", size=10)
    ws["A2"] = d["titulo"]
    ws["A2"].font = Font(bold=True, size=14)
    ws["A3"] = d["subtitulo"]
    ws["A3"].font = Font(color="5B766F", size=10)
    cab = 5
    ws.cell(cab, 1, "Período").font = Font(bold=True, color="FFFFFF")
    ws.cell(cab, 1).fill = PatternFill("solid", fgColor="0B5D56")
    for j, f in enumerate(d["filas"], start=2):
        c = ws.cell(cab, j, f["etiqueta"])
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0B5D56")
        c.alignment = Alignment(wrap_text=True, horizontal="center")
        ws.column_dimensions[c.column_letter].width = max(14, min(32, len(f["etiqueta"]) + 2))
    ws.column_dimensions["A"].width = 16
    for i, col in enumerate(d["columnas"], start=cab + 1):
        ws.cell(i, 1, col)
        for j, f in enumerate(d["filas"], start=2):
            v = f["v"][i - cab - 1]
            celda = ws.cell(i, j, (v / 100 if f["f"] in ("%", "p") else v) if v is not None else None)
            celda.number_format = "0.0%" if f["f"] in ("%", "p") else ("0.00" if f["f"] == "r" else "#,##0.00;[Red](#,##0.00)")
    fin = cab + len(d["columnas"])
    ch = LineChart() if d["tipo"] == "lineas" else BarChart()
    ch.title = d["titulo"]
    ch.height, ch.width = 9, 22
    ch.y_axis.title = "Crecimiento %" if d["modo"] == "crec" else ""
    ch.add_data(Reference(ws, min_col=2, max_col=1 + len(d["filas"]), min_row=cab, max_row=fin), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=cab + 1, max_row=fin))
    for s, f in zip(ch.series, d["filas"]):
        color = f["color"][1:].upper()
        if d["tipo"] == "lineas":
            s.graphicalProperties.line.solidFill = color
            s.graphicalProperties.line.width = 28000
            s.smooth = False
        else:
            s.graphicalProperties.solidFill = color
            s.graphicalProperties.line.solidFill = color
    ws.add_chart(ch, f"A{fin + 3}")
    salida = io.BytesIO()
    wb.save(salida)
    return salida.getvalue()
