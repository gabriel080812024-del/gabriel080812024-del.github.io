"""Comprueba si una copia portátil se abre con tu usuario y contraseña (o código de recuperación).
No cambia nada y no guarda nada. La contraseña se escribe sin que se vea.

Uso:  .venv/bin/python probar_copia.py [archivo.db.cifrado]
"""
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import boveda  # noqa: E402

if len(sys.argv) > 1:
    archivo = Path(sys.argv[1])
else:
    copias = sorted((Path.home() / "Downloads").glob("contabilidad_*descargada.db.cifrado"))
    if not copias:
        sys.exit("No encuentro copias en Descargas.")
    archivo = copias[-1]
print("Copia:", archivo.name)
llaves, _ = boveda.desempaquetar(archivo.read_bytes())
print("Usuarios que acepta esta copia:", ", ".join((llaves or {}).get("usuarios", {}).keys()))
usuario = input("Usuario: ").strip().lower()
secreto = getpass.getpass("Contraseña o código de recuperación (no se ve al escribir): ")
print("Probando… (tarda unos segundos)")
try:
    boveda.abrir_copia_portatil(archivo.read_bytes(), usuario, secreto)
    print("\n✅ SÍ ABRE: la contraseña es correcta para esta copia.")
except boveda.ErrorBoveda as e:
    print("\n❌ NO ABRE:", e)
