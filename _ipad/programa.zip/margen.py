"""Margen al vender: cuánto se gana en cada venta de mercancía (precio menos lo que costó esa mercancía),
por producto, por cliente y por mes. Solo lee: no crea asientos. Cifras en moneda base."""
from datetime import date, timedelta

import contab as C
import db
from contab import r2

PERIODOS = {"mes": "Este mes", "3m": "Últimos 3 meses", "anio": "Este año", "todo": "Desde el principio"}


def objetivo(conn):
    """Margen que Gabriel quiere ganar como mínimo (en %, sobre el precio de venta)."""
    try:
        return float(db.get_config(conn, "margen_objetivo") or 15)
    except ValueError:
        return 15.0


def rango(periodo, desde=None, hasta=None):
    t = date.today()
    if desde and hasta:
        return desde, hasta, f"Del {desde[8:10]}/{desde[5:7]}/{desde[:4]} al {hasta[8:10]}/{hasta[5:7]}/{hasta[:4]}"
    if periodo == "3m":
        m0 = (t.replace(day=1) - timedelta(days=62)).replace(day=1)
        return m0.isoformat(), t.isoformat(), PERIODOS["3m"]
    if periodo == "anio":
        return f"{t.year}-01-01", t.isoformat(), PERIODOS["anio"]
    if periodo == "todo":
        return "1900-01-01", t.isoformat(), PERIODOS["todo"]
    return t.replace(day=1).isoformat(), t.isoformat(), PERIODOS["mes"]


def ventas(conn, desde, hasta):
    """Cada venta de mercancía con su cliente, precio, costo, ganancia y margen."""
    q = ("SELECT m.id, m.fecha, m.cantidad, m.venta, m.valor, m.asiento_venta_id aid, p.id pid, p.nombre producto, p.unidad,"
         " (SELECT t.nombre FROM lineas l JOIN terceros t ON t.id = l.tercero_id WHERE l.asiento_id = m.asiento_venta_id"
         "  AND l.tercero_id IS NOT NULL LIMIT 1) cliente,"
         " (SELECT a.numero FROM asientos a WHERE a.id = m.asiento_venta_id) numero"
         " FROM mov_inventario m JOIN productos p ON p.id = m.producto_id"
         " WHERE m.tipo = 'venta' AND m.fecha BETWEEN ? AND ? ORDER BY m.fecha, m.id")
    obj = objetivo(conn) / 100
    out = []
    for f in conn.execute(q, (desde, hasta)):
        venta, costo, cant = r2(f["venta"]), r2(-f["valor"]), -f["cantidad"]
        gan = r2(venta - costo)
        mg = gan / venta if venta > 0.004 else None
        out.append({"id": f["id"], "fecha": f["fecha"], "aid": f["aid"], "numero": f["numero"], "pid": f["pid"], "producto": f["producto"],
                    "unidad": f["unidad"], "cantidad": cant, "cliente": f["cliente"] or "Sin cliente", "venta": venta, "costo": costo,
                    "ganancia": gan, "margen": mg, "precio_u": r2(venta / cant) if cant else 0, "costo_u": r2(costo / cant) if cant else 0,
                    "estado": "perdida" if gan < -0.004 else ("bajo" if mg is not None and mg < obj else "bien")})
    return out


def _agrupar(lista, clave, nombre):
    g = {}
    for v in lista:
        k = v[clave]
        x = g.setdefault(k, {"clave": k, "nombre": v[nombre], "n": 0, "cantidad": 0.0, "venta": 0.0, "costo": 0.0, "perdidas": 0, "unidad": v.get("unidad")})
        x["n"] += 1
        x["cantidad"] += v["cantidad"]
        x["venta"] += v["venta"]
        x["costo"] += v["costo"]
        x["perdidas"] += v["estado"] == "perdida"
    out = []
    for x in g.values():
        x["venta"], x["costo"] = r2(x["venta"]), r2(x["costo"])
        x["ganancia"] = r2(x["venta"] - x["costo"])
        x["margen"] = x["ganancia"] / x["venta"] if x["venta"] > 0.004 else None
        out.append(x)
    return sorted(out, key=lambda x: -x["ganancia"])


def resumen(conn, desde, hasta):
    vs = ventas(conn, desde, hasta)
    tot = {"venta": r2(sum(v["venta"] for v in vs)), "costo": r2(sum(v["costo"] for v in vs))}
    tot["ganancia"] = r2(tot["venta"] - tot["costo"])
    tot["margen"] = tot["ganancia"] / tot["venta"] if tot["venta"] > 0.004 else None
    for v in vs:
        v["mes"] = v["fecha"][:7]
    meses = sorted(_agrupar(vs, "mes", "mes"), key=lambda x: x["clave"])
    for m in meses:
        m["nombre"] = f"{C.MESES[int(m['clave'][5:7]) - 1]} {m['clave'][:4]}"
    return {"ventas": vs, "tot": tot, "productos": _agrupar(vs, "pid", "producto"), "clientes": _agrupar(vs, "cliente", "cliente"),
            "meses": meses, "perdidas": [v for v in vs if v["estado"] == "perdida"], "bajas": [v for v in vs if v["estado"] == "bajo"],
            "objetivo": objetivo(conn)}


def aviso(conn):
    """(nivel, texto) si en los últimos 30 días hubo ventas por debajo de lo que costó la mercancía."""
    t = date.today()
    vs = [v for v in ventas(conn, (t - timedelta(days=30)).isoformat(), t.isoformat()) if v["estado"] == "perdida"]
    if not vs:
        return None
    perdido = -sum(v["ganancia"] for v in vs)
    prods = sorted({v["producto"] for v in vs})
    return ("alta", f"{len(vs)} venta{'s' if len(vs) > 1 else ''} por debajo del costo en los últimos 30 días "
                    f"({', '.join(prods[:3])}{'…' if len(prods) > 3 else ''}): se perdieron {perdido:,.2f} {C.moneda_base(conn)}.")
