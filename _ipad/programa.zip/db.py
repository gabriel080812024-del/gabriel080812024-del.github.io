"""Base de datos (SQLite) de Mi Contabilidad.

Los datos viven en ~/Library/Application Support/MiContabilidad/contabilidad.db
(se puede cambiar con la variable MC_DATOS). Las copias de seguridad van a
~/Documents/Mi Contabilidad - Copias de seguridad.
"""
import os
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path


def carpeta_datos():
    if os.environ.get("MC_DATOS"):
        return Path(os.environ["MC_DATOS"])
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "MiContabilidad"
    return Path.home() / ".mi-contabilidad"


def carpeta_copias():
    if os.environ.get("MC_COPIAS"):
        return Path(os.environ["MC_COPIAS"])
    return Path.home() / "Documents" / "Mi Contabilidad - Copias de seguridad"


IPAD = os.environ.get("MC_IPAD") == "1"   # versión del iPad (programa dentro del navegador, sin internet)


def ruta_db():
    if os.environ.get("MC_DB_PLANO"):  # iPad: la copia descifrada vive solo en memoria, nunca en el disco
        return Path(os.environ["MC_DB_PLANO"])
    return carpeta_datos() / "contabilidad.db"


class BovedaCerrada(RuntimeError):
    """Los datos están cifrados y nadie ha entrado todavía."""


def conectar():
    import boveda
    if boveda.activa() and not boveda.abierta():
        raise BovedaCerrada("Los datos están cifrados: hay que entrar con usuario y contraseña.")
    carpeta_datos().mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(ruta_db())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


ESQUEMA = """
CREATE TABLE IF NOT EXISTS config (
    clave TEXT PRIMARY KEY,
    valor TEXT
);

CREATE TABLE IF NOT EXISTS cuentas (
    id INTEGER PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    tipo TEXT NOT NULL,              -- activo, pasivo, patrimonio, ingreso, gasto
    seccion TEXT NOT NULL,           -- corriente/no_corriente/patrimonio/operacion/costo/otros/impuesto
    padre_id INTEGER REFERENCES cuentas(id),
    es_grupo INTEGER NOT NULL DEFAULT 0,
    moneda TEXT,                     -- CUP o USD si la cuenta guarda dinero en esa moneda
    es_efectivo INTEGER NOT NULL DEFAULT 0,
    por_tercero INTEGER NOT NULL DEFAULT 0,
    flujo TEXT NOT NULL DEFAULT 'operacion',  -- operacion, inversion, financiacion
    rol TEXT UNIQUE,                 -- cuentas que usa el sistema
    activa INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS terceros (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL,
    tipo TEXT NOT NULL DEFAULT 'Proveedor',
    documento TEXT,
    telefono TEXT,
    email TEXT,
    direccion TEXT,
    notas TEXT,
    activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS tasas (
    fecha TEXT PRIMARY KEY,
    cup_por_usd REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS documentos (
    id INTEGER PRIMARY KEY,
    tipo TEXT NOT NULL,              -- cobrar o pagar
    tercero_id INTEGER NOT NULL REFERENCES terceros(id),
    numero TEXT,
    fecha TEXT NOT NULL,
    vencimiento TEXT,
    concepto TEXT NOT NULL,
    cuenta_id INTEGER NOT NULL REFERENCES cuentas(id),
    moneda TEXT NOT NULL,
    importe REAL NOT NULL,
    tasa REAL NOT NULL,
    asiento_id INTEGER,
    anulado INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS asientos (
    id INTEGER PRIMARY KEY,
    numero INTEGER NOT NULL,
    fecha TEXT NOT NULL,
    concepto TEXT NOT NULL,
    referencia TEXT,
    origen TEXT NOT NULL DEFAULT 'manual',
    documento_id INTEGER REFERENCES documentos(id),
    tasa REAL,
    anulado INTEGER NOT NULL DEFAULT 0,
    motivo_anulacion TEXT,
    creado TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS lineas (
    id INTEGER PRIMARY KEY,
    asiento_id INTEGER NOT NULL REFERENCES asientos(id) ON DELETE CASCADE,
    cuenta_id INTEGER NOT NULL REFERENCES cuentas(id),
    tercero_id INTEGER REFERENCES terceros(id),
    documento_id INTEGER REFERENCES documentos(id),
    debe REAL NOT NULL DEFAULT 0,    -- en moneda base
    haber REAL NOT NULL DEFAULT 0,   -- en moneda base
    moneda TEXT NOT NULL,            -- moneda original del movimiento
    importe_orig REAL NOT NULL DEFAULT 0,  -- con signo: + debe, - haber
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS eliminados (
    id INTEGER PRIMARY KEY,
    fecha TEXT NOT NULL,
    numero INTEGER,
    datos TEXT NOT NULL              -- copia del movimiento borrado (JSON)
);

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY,
    usuario TEXT NOT NULL UNIQUE,            -- en minúsculas
    nombre TEXT NOT NULL,
    clave TEXT NOT NULL,                     -- contraseña cifrada (nunca en claro)
    recuperacion TEXT,                       -- código de recuperación cifrado
    es_admin INTEGER NOT NULL DEFAULT 0,
    activo INTEGER NOT NULL DEFAULT 1,
    creado TEXT NOT NULL,
    ultimo_acceso TEXT
);

CREATE TABLE IF NOT EXISTS bitacora (
    id INTEGER PRIMARY KEY,
    fecha TEXT NOT NULL,
    usuario TEXT,
    evento TEXT NOT NULL,
    detalle TEXT
);

CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY,
    nombre TEXT NOT NULL UNIQUE,
    unidad TEXT NOT NULL DEFAULT 'unidad',   -- saco, caja, kg, unidad...
    categoria TEXT,
    minimo REAL NOT NULL DEFAULT 0,          -- avisar si queda menos de esto
    notas TEXT,
    activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS mov_inventario (
    id INTEGER PRIMARY KEY,
    fecha TEXT NOT NULL,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    tipo TEXT NOT NULL,                      -- compra, inicial, costo_extra, venta, merma, sobrante
    cantidad REAL NOT NULL,                  -- + entra, - sale
    valor REAL NOT NULL,                     -- costo en moneda base, con signo
    venta REAL NOT NULL DEFAULT 0,           -- precio de venta en moneda base (solo ventas)
    lote TEXT,                               -- contenedor / lote (opcional)
    nota TEXT,
    asiento_id INTEGER,                      -- asiento del inventario (compra, costo de lo vendido, merma)
    asiento_venta_id INTEGER,                -- asiento de la venta (ingreso o factura) si es una venta
    creado TEXT
);
CREATE INDEX IF NOT EXISTS ix_movinv_producto ON mov_inventario(producto_id);

CREATE INDEX IF NOT EXISTS ix_lineas_asiento ON lineas(asiento_id);
CREATE INDEX IF NOT EXISTS ix_lineas_cuenta ON lineas(cuenta_id);
CREATE INDEX IF NOT EXISTS ix_lineas_tercero ON lineas(tercero_id);
CREATE INDEX IF NOT EXISTS ix_lineas_documento ON lineas(documento_id);
CREATE INDEX IF NOT EXISTS ix_asientos_fecha ON asientos(fecha);
"""

# (codigo, nombre, tipo, seccion, es_grupo, moneda, efectivo, por_tercero, flujo, rol)
PLAN = [
    ("1.1", "Efectivo y equivalentes", "activo", "corriente", 1, None, 1, 0, "operacion", None),
    ("1.1.01", "Caja CUP", "activo", "corriente", 0, "CUP", 1, 0, "operacion", None),
    ("1.1.02", "Caja USD", "activo", "corriente", 0, "USD", 1, 0, "operacion", None),
    ("1.1.03", "Banco CUP", "activo", "corriente", 0, "CUP", 1, 0, "operacion", None),
    ("1.1.04", "Banco USD / Tarjeta Clásica", "activo", "corriente", 0, "USD", 1, 0, "operacion", None),
    ("1.1.05", "Cuenta en el exterior / Zelle", "activo", "corriente", 0, "USD", 1, 0, "operacion", None),
    ("1.2", "Cuentas por cobrar", "activo", "corriente", 1, None, 0, 1, "operacion", None),
    ("1.2.01", "Clientes por cobrar CUP", "activo", "corriente", 0, "CUP", 0, 1, "operacion", "cxc_CUP"),
    ("1.2.02", "Clientes por cobrar USD", "activo", "corriente", 0, "USD", 0, 1, "operacion", "cxc_USD"),
    ("1.2.03", "Préstamos a terceros por cobrar", "activo", "corriente", 0, "USD", 0, 1, "inversion", None),
    ("1.2.04", "Anticipos a proveedores", "activo", "corriente", 0, None, 0, 1, "operacion", None),
    ("1.3", "Inventarios", "activo", "corriente", 1, None, 0, 0, "operacion", None),
    ("1.3.01", "Mercancías", "activo", "corriente", 0, None, 0, 0, "operacion", None),
    ("1.4", "Otros activos corrientes", "activo", "corriente", 1, None, 0, 0, "operacion", None),
    ("1.4.01", "Gastos pagados por adelantado", "activo", "corriente", 0, None, 0, 0, "operacion", None),
    ("1.5", "Propiedad, planta y equipo", "activo", "no_corriente", 1, None, 0, 0, "inversion", None),
    ("1.5.01", "Vehículos", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("1.5.02", "Equipos y computadoras", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("1.5.03", "Mobiliario", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("1.5.04", "Inmuebles y locales", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("1.5.09", "Depreciación acumulada (resta)", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("1.6", "Inversiones", "activo", "no_corriente", 1, None, 0, 0, "inversion", None),
    ("1.6.01", "Inversiones en otros negocios", "activo", "no_corriente", 0, None, 0, 1, "inversion", None),
    ("1.6.02", "Inversiones financieras (acciones, fondos)", "activo", "no_corriente", 0, None, 0, 0, "inversion", None),
    ("2.1", "Cuentas por pagar", "pasivo", "corriente", 1, None, 0, 1, "operacion", None),
    ("2.1.01", "Proveedores por pagar CUP", "pasivo", "corriente", 0, "CUP", 0, 1, "operacion", "cxp_CUP"),
    ("2.1.02", "Proveedores por pagar USD", "pasivo", "corriente", 0, "USD", 0, 1, "operacion", "cxp_USD"),
    ("2.1.03", "Acreedores varios", "pasivo", "corriente", 0, None, 0, 1, "operacion", None),
    ("2.1.04", "Anticipos de clientes", "pasivo", "corriente", 0, None, 0, 1, "operacion", None),
    ("2.2", "Obligaciones laborales y fiscales", "pasivo", "corriente", 1, None, 0, 0, "operacion", None),
    ("2.2.01", "Salarios por pagar", "pasivo", "corriente", 0, None, 0, 1, "operacion", None),
    ("2.2.02", "Impuestos por pagar (ONAT)", "pasivo", "corriente", 0, "CUP", 0, 0, "operacion", None),
    ("2.3", "Préstamos a corto plazo", "pasivo", "corriente", 1, None, 0, 1, "financiacion", None),
    ("2.3.01", "Préstamos recibidos (menos de 1 año)", "pasivo", "corriente", 0, "USD", 0, 1, "financiacion", None),
    ("2.4", "Préstamos a largo plazo", "pasivo", "no_corriente", 1, None, 0, 1, "financiacion", None),
    ("2.4.01", "Préstamos recibidos (más de 1 año)", "pasivo", "no_corriente", 0, "USD", 0, 1, "financiacion", None),
    ("3.1", "Capital", "patrimonio", "patrimonio", 1, None, 0, 0, "financiacion", None),
    ("3.1.01", "Capital aportado por el dueño", "patrimonio", "patrimonio", 0, None, 0, 0, "financiacion", "capital"),
    ("3.1.02", "Retiros del dueño (resta)", "patrimonio", "patrimonio", 0, None, 0, 0, "financiacion", None),
    ("3.1.03", "Saldos de apertura (antes de usar el programa)", "patrimonio", "patrimonio", 0, None, 0, 0, "financiacion", "apertura"),
    ("3.2", "Resultados", "patrimonio", "patrimonio", 1, None, 0, 0, "financiacion", None),
    ("3.2.01", "Resultados acumulados", "patrimonio", "patrimonio", 0, None, 0, 0, "financiacion", "resultados_acum"),
    ("4.1", "Ingresos de operación", "ingreso", "operacion", 1, None, 0, 0, "operacion", None),
    ("4.1.01", "Venta de productos", "ingreso", "operacion", 0, None, 0, 0, "operacion", None),
    ("4.1.02", "Prestación de servicios", "ingreso", "operacion", 0, None, 0, 0, "operacion", None),
    ("4.1.03", "Comisiones ganadas", "ingreso", "operacion", 0, None, 0, 0, "operacion", None),
    ("4.1.04", "Alquileres cobrados", "ingreso", "operacion", 0, None, 0, 0, "operacion", None),
    ("4.2", "Otros ingresos", "ingreso", "otros", 1, None, 0, 0, "operacion", None),
    ("4.2.01", "Intereses ganados", "ingreso", "otros", 0, None, 0, 0, "operacion", None),
    ("4.2.02", "Ganancias en inversiones", "ingreso", "otros", 0, None, 0, 0, "inversion", None),
    ("4.2.03", "Diferencia de cambio (CUP/USD)", "ingreso", "otros", 0, None, 0, 0, "operacion", "dif_cambio"),
    ("4.2.04", "Ganancia en compra de Zelle", "ingreso", "otros", 0, None, 0, 0, "operacion", "zelle_ganancia"),
    ("4.2.09", "Otros ingresos", "ingreso", "otros", 0, None, 0, 0, "operacion", None),
    ("5.1", "Costo de ventas", "gasto", "costo", 1, None, 0, 0, "operacion", None),
    ("5.1.01", "Costo de la mercancía vendida", "gasto", "costo", 0, None, 0, 0, "operacion", None),
    ("5.1.02", "Costo de los servicios prestados", "gasto", "costo", 0, None, 0, 0, "operacion", None),
    ("6.1", "Gastos de personal", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.1.01", "Salarios", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.1.02", "Bonos e incentivos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.1.03", "Seguridad social", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.1.04", "Alimentación del personal", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.2", "Local y servicios", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.2.01", "Alquiler", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.2.02", "Electricidad", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.2.03", "Agua", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.2.04", "Internet y teléfono", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.2.05", "Planta eléctrica / combustible del local", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.3", "Transporte", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.3.01", "Combustible", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.3.02", "Mantenimiento de vehículos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.3.03", "Fletes y mensajería", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4", "Gastos de administración", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.4.01", "Material de oficina", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4.02", "Honorarios profesionales (contadora, abogado)", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4.03", "Comisiones bancarias y de transferencia", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4.04", "Licencias, trámites y permisos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4.05", "Impuestos y tributos del negocio (ventas, servicios)", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.4.06", "Software y suscripciones", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.5", "Ventas y marketing", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.5.01", "Publicidad", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.5.02", "Atención a clientes y regalos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.6", "Mantenimiento y reparaciones", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.6.01", "Reparaciones del local", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.6.02", "Reparación de equipos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.7", "Depreciación", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.7.01", "Depreciación de activos", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("6.9", "Otros gastos de operación", "gasto", "operacion", 1, None, 0, 0, "operacion", None),
    ("6.9.01", "Gastos varios", "gasto", "operacion", 0, None, 0, 0, "operacion", None),
    ("7.1", "Gastos financieros y otros", "gasto", "otros", 1, None, 0, 0, "operacion", None),
    ("7.1.01", "Intereses pagados", "gasto", "otros", 0, None, 0, 0, "operacion", None),
    ("7.1.02", "Pérdidas en inversiones", "gasto", "otros", 0, None, 0, 0, "inversion", None),
    ("7.1.03", "Pérdidas, robos y mermas", "gasto", "otros", 0, None, 0, 0, "operacion", None),
    ("7.1.04", "Costo de comprar Zelle (comisión del cambio)", "gasto", "otros", 0, None, 0, 0, "operacion", "zelle_perdida"),
    ("7.1.09", "Otros gastos no operativos", "gasto", "otros", 0, None, 0, 0, "operacion", None),
    ("8.1", "Impuesto sobre las utilidades", "gasto", "impuesto", 1, None, 0, 0, "operacion", None),
    ("8.1.01", "Impuesto sobre utilidades / ingresos personales", "gasto", "impuesto", 0, None, 0, 0, "operacion", None),
]


def iniciar():
    conn = conectar()
    conn.executescript(ESQUEMA)
    if conn.execute("SELECT COUNT(*) FROM cuentas").fetchone()[0] == 0:
        ids = {}
        for (codigo, nombre, tipo, seccion, grupo, moneda, efectivo, por_t, flujo, rol) in PLAN:
            padre = ids.get(codigo.rsplit(".", 1)[0]) if codigo.count(".") >= 2 else None
            cur = conn.execute(
                "INSERT INTO cuentas (codigo, nombre, tipo, seccion, padre_id, es_grupo, moneda,"
                " es_efectivo, por_tercero, flujo, rol) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (codigo, nombre, tipo, seccion, padre, grupo, moneda, efectivo, por_t, flujo, rol),
            )
            ids[codigo] = cur.lastrowid
    # quién anotó cada movimiento
    columnas = {r[1] for r in conn.execute("PRAGMA table_info(asientos)")}
    if "usuario" not in columnas:
        conn.execute("ALTER TABLE asientos ADD COLUMN usuario TEXT")
    # cuentas que usa el inventario
    for codigo, rol in (("1.3.01", "inventario"), ("5.1.01", "costo_mercancia"), ("7.1.03", "mermas"),
                        ("4.2.09", "otros_ingresos")):
        if not conn.execute("SELECT 1 FROM cuentas WHERE rol = ?", (rol,)).fetchone():
            conn.execute("UPDATE cuentas SET rol = ? WHERE codigo = ? AND rol IS NULL AND es_grupo = 0", (rol, codigo))
    # cuentas para la compra de Zelle (ganancia o costo del cambio)
    for codigo, nombre, tipo, padre_cod, rol in (
            ("4.2.04", "Ganancia en compra de Zelle", "ingreso", "4.2", "zelle_ganancia"),
            ("7.1.04", "Costo de comprar Zelle (comisión del cambio)", "gasto", "7.1", "zelle_perdida")):
        if conn.execute("SELECT 1 FROM cuentas WHERE rol = ?", (rol,)).fetchone():
            continue
        padre = conn.execute("SELECT id FROM cuentas WHERE codigo = ?", (padre_cod,)).fetchone()
        cod = codigo
        while conn.execute("SELECT 1 FROM cuentas WHERE codigo = ?", (cod,)).fetchone():
            cod = cod.rsplit(".", 1)[0] + "." + str(int(cod.rsplit(".", 1)[1]) + 1).zfill(2)
        conn.execute("INSERT INTO cuentas (codigo, nombre, tipo, seccion, padre_id, es_grupo, flujo, rol)"
                     " VALUES (?, ?, ?, 'otros', ?, 0, 'operacion', ?)", (cod, nombre, tipo, padre["id"] if padre else None, rol))
    if not conn.execute("SELECT 1 FROM cuentas WHERE rol = 'apertura'").fetchone():
        grupo = conn.execute("SELECT id FROM cuentas WHERE codigo = '3.1'").fetchone()
        codigo = "3.1.03" if not conn.execute("SELECT 1 FROM cuentas WHERE codigo = '3.1.03'").fetchone() else "3.1.90"
        conn.execute("INSERT INTO cuentas (codigo, nombre, tipo, seccion, padre_id, es_grupo, flujo, rol)"
                     " VALUES (?, 'Saldos de apertura (antes de usar el programa)', 'patrimonio', 'patrimonio', ?, 0,"
                     " 'financiacion', 'apertura')", (codigo, grupo["id"] if grupo else None))
    conn.commit()
    conn.close()


def clave_secreta():
    """Clave para firmar la sesión. Se crea al azar la primera vez y se guarda solo en esta computadora."""
    import secrets
    carpeta_datos().mkdir(parents=True, exist_ok=True)
    ruta = carpeta_datos() / "clave_sesion.txt"
    if not ruta.exists() or len(ruta.read_text().strip()) < 32:
        ruta.write_text(secrets.token_hex(32))
        os.chmod(ruta, 0o600)
    return ruta.read_text().strip()


def get_config(conn, clave, defecto=None):
    fila = conn.execute("SELECT valor FROM config WHERE clave = ?", (clave,)).fetchone()
    return fila["valor"] if fila and fila["valor"] is not None else defecto


def set_config(conn, clave, valor):
    conn.execute(
        "INSERT INTO config (clave, valor) VALUES (?, ?) "
        "ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor",
        (clave, valor),
    )


def lista_copias():
    carpeta = carpeta_copias()
    if not carpeta.exists():
        return []
    return sorted(list(carpeta.glob("contabilidad_*.db")) + list(carpeta.glob("contabilidad_*.db.cifrado")),
                  key=lambda p: p.name.replace(".cifrado", ""))


def hacer_copia(motivo="automatica", conservar=40):
    """Copia segura de la base (aunque esté abierta) a la carpeta de copias. Si hay cifrado, la copia va cifrada."""
    import boveda
    if not ruta_db().exists():
        return None
    destino_dir = carpeta_copias()
    destino_dir.mkdir(parents=True, exist_ok=True)
    nombre = f"contabilidad_{datetime.now():%Y-%m-%d_%H%M%S}_{motivo}.db"
    destino = destino_dir / nombre
    origen = sqlite3.connect(ruta_db())
    copia = sqlite3.connect(destino)
    with copia:
        origen.backup(copia)
    origen.close()
    copia.close()
    if boveda.activa() and boveda.abierta():
        destino = boveda.cifrar_archivo_copia(destino)
    copias = lista_copias()
    for vieja in copias[:-conservar]:
        boveda.borrar_seguro(vieja)
    return destino


def copia_diaria():
    """Una copia automática por día como máximo."""
    destino_dir = carpeta_copias()
    hoy = datetime.now().strftime("%Y-%m-%d")
    if destino_dir.exists() and any(p for p in destino_dir.glob(f"contabilidad_{hoy}_*") if "diaria" in p.name):
        return None
    return hacer_copia("diaria")


def restaurar(ruta_copia):
    import boveda
    hacer_copia("antes_de_restaurar")
    if str(ruta_copia).endswith(".cifrado"):
        datos = boveda.descifrar_copia(ruta_copia)
        tmp = ruta_db().with_name("restaurando.tmp")
        tmp.write_bytes(datos)
        os.chmod(tmp, 0o600)
        os.replace(tmp, ruta_db())
    else:
        shutil.copy2(ruta_copia, ruta_db())
    if boveda.abierta():
        boveda.guardar()
