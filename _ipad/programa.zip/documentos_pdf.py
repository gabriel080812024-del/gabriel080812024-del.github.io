"""Documentos en PDF para mandar al cliente (WhatsApp, AirDrop, imprimir): factura, recibo de pago,
comprobante de venta y estado de cuenta. Se crean igual en la Mac y en el iPad, sin internet (fpdf2)."""
from datetime import datetime

from fpdf import FPDF

import contab as C
import db

VERDE = (11, 93, 86)
NARANJA = (232, 137, 12)
GRIS = (91, 118, 111)
TEXTO = (22, 48, 43)
CLARO = (238, 245, 243)
LINEA = (207, 220, 216)
ESTADOS = {"Pagada": (21, 128, 61), "Parcial": (180, 83, 9), "Pendiente": (198, 40, 40), "Anulada": (120, 120, 120)}

_CAMBIOS = {"–": "-", "—": "-", "“": '"', "”": '"', "‘": "'", "’": "'", "…": "...", "•": "-", "→": "->", "✓": "",
            " ": " ", "€": "EUR", "≈": "~"}


def t(texto):
    """Las letras de los PDF básicos son latin-1 (tienen á é í ó ú ñ ¿ ¡): lo demás se cambia o se quita."""
    s = "".join(_CAMBIOS.get(ch, ch) for ch in str(texto or ""))
    return s.encode("latin-1", "ignore").decode("latin-1")


def dinero(v, moneda=""):
    return f"{v:,.2f}" + (f" {moneda}" if moneda else "")


def fecha(f):
    try:
        return datetime.strptime(f, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return f or ""


class Documento(FPDF):
    def __init__(self, conn, titulo, numero=None, fecha_doc=None):
        super().__init__(format="A4", unit="mm")
        self.conn, self.titulo, self.numero, self.fecha_doc = conn, titulo, numero, fecha_doc
        self.set_margins(15, 15, 15)
        self.set_auto_page_break(True, margin=22)
        self.alias_nb_pages()
        self.empresa = {k: db.get_config(conn, k, "") for k in ("empresa", "nit", "direccion", "telefono", "responsable", "pie_documentos")}
        self.set_title(t(f"{titulo} {numero or ''}"))
        self.set_author(t(self.empresa["empresa"]))
        self.add_page()

    # ---------------------------------------------------------------- encabezado y pie
    def logo(self, x, y, lado=16):
        self.set_fill_color(*NARANJA)
        self.rect(x, y, lado, lado, style="F", round_corners=True, corner_radius=3.5)
        self.set_draw_color(255, 255, 255)
        self.set_line_width(lado * 0.09)
        a, b = x + lado * 0.28, x + lado * 0.72
        arr, med, aba = y + lado * 0.24, y + lado * 0.5, y + lado * 0.76
        self.line(b, arr, a, arr)
        self.line(a, arr, x + lado * 0.52, med)
        self.line(x + lado * 0.52, med, a, aba)
        self.line(a, aba, b, aba)
        self.set_line_width(0.2)

    def header(self):
        self.logo(15, 14)
        self.set_xy(35, 14)
        self.set_text_color(*VERDE)
        self.set_font("helvetica", "B", 16)
        self.cell(95, 8, t(self.empresa["empresa"] or "Mi negocio"))
        datos = " · ".join(x for x in (("NIT " + self.empresa["nit"]) if self.empresa["nit"] else "", self.empresa["direccion"],
                                       ("Tel. " + self.empresa["telefono"]) if self.empresa["telefono"] else "") if x)
        self.set_xy(35, 22)
        self.set_text_color(*GRIS)
        self.set_font("helvetica", "", 8.5)
        self.multi_cell(88, 4, t(datos), new_x="LMARGIN", new_y="NEXT")
        # título a la derecha
        self.set_xy(120, 13)
        self.set_text_color(*VERDE)
        self.set_font("helvetica", "B", 17)
        self.cell(75, 8, t(self.titulo.upper()), align="R")
        self.set_font("helvetica", "", 9.5)
        self.set_text_color(*TEXTO)
        linea_y = 21
        if self.numero:
            self.set_xy(120, linea_y)
            self.cell(75, 5, t(f"N.º {self.numero}"), align="R")
            linea_y += 5
        if self.fecha_doc:
            self.set_xy(120, linea_y)
            self.cell(75, 5, t(f"Fecha: {fecha(self.fecha_doc)}"), align="R")
        self.set_draw_color(*LINEA)
        self.line(15, 34, 195, 34)
        self.set_xy(15, 38)

    def footer(self):
        self.set_y(-17)
        self.set_draw_color(*LINEA)
        self.line(15, self.get_y(), 195, self.get_y())
        self.set_font("helvetica", "", 8)
        self.set_text_color(*GRIS)
        pie = self.empresa.get("pie_documentos") or ""
        if pie:
            self.cell(0, 5, t(pie), align="C", new_x="LMARGIN", new_y="NEXT")
        self.cell(120, 5, t(f"Generado con Mi Contabilidad el {datetime.now():%d/%m/%Y %H:%M}"))
        self.cell(0, 5, t(f"Página {self.page_no()} de {{nb}}"), align="R")

    # ---------------------------------------------------------------- piezas
    def bloque_persona(self, etiqueta, tercero_id, estado=None):
        p = self.conn.execute("SELECT * FROM terceros WHERE id = ?", (tercero_id,)).fetchone() if tercero_id else None
        y0 = self.get_y()
        self.set_fill_color(*CLARO)
        self.rect(15, y0, 180, 24, style="F", round_corners=True, corner_radius=2.5)
        self.set_xy(20, y0 + 3)
        self.set_font("helvetica", "", 8)
        self.set_text_color(*GRIS)
        self.cell(100, 4, t(etiqueta.upper()), new_x="LMARGIN", new_y="NEXT")
        self.set_x(20)
        self.set_font("helvetica", "B", 13)
        self.set_text_color(*TEXTO)
        self.cell(110, 7, t(p["nombre"] if p else "-"), new_x="LMARGIN", new_y="NEXT")
        if p:
            extra = " · ".join(x for x in (("Carné/NIT " + p["documento"]) if p["documento"] else "",
                                           ("Tel. " + p["telefono"]) if p["telefono"] else "", p["direccion"] or "") if x)
            self.set_x(20)
            self.set_font("helvetica", "", 9)
            self.set_text_color(*GRIS)
            self.cell(120, 5, t(extra))
        if estado:
            color = ESTADOS.get(estado, GRIS)
            self.set_draw_color(*color)
            self.set_text_color(*color)
            self.set_line_width(0.6)
            self.set_font("helvetica", "B", 12)
            ancho = self.get_string_width(t(estado.upper())) + 10
            self.rect(190 - ancho, y0 + 7, ancho, 10, style="D", round_corners=True, corner_radius=2)
            self.set_xy(190 - ancho, y0 + 7)
            self.cell(ancho, 10, t(estado.upper()), align="C")
            self.set_line_width(0.2)
        self.set_xy(15, y0 + 29)

    def tabla(self, columnas, filas, anchos, alinear=None):
        alinear = alinear or ["L"] * len(columnas)
        self.set_font("helvetica", "B", 9)
        self.set_fill_color(*VERDE)
        self.set_text_color(255, 255, 255)
        for c, w, a in zip(columnas, anchos, alinear):
            self.cell(w, 8, t(c), fill=True, align=a)
        self.ln()
        self.set_font("helvetica", "", 9.5)
        self.set_text_color(*TEXTO)
        for i, fila in enumerate(filas):
            if self.will_page_break(7):
                self.add_page()
            self.set_fill_color(*(CLARO if i % 2 else (255, 255, 255)))
            for v, w, a in zip(fila, anchos, alinear):
                self.cell(w, 7, t(v), fill=True, align=a)
            self.ln()
        self.set_draw_color(*LINEA)
        self.line(15, self.get_y(), 15 + sum(anchos), self.get_y())
        self.ln(3)

    def totales(self, filas):
        """filas: [(etiqueta, valor, destacado)] alineadas a la derecha."""
        for etq, valor, fuerte in filas:
            if self.will_page_break(9):
                self.add_page()
            self.set_x(105)
            if fuerte:
                self.set_fill_color(*VERDE)
                self.set_text_color(255, 255, 255)
                self.set_font("helvetica", "B", 11)
                self.cell(50, 9, t(etq), fill=True)
                self.cell(40, 9, t(valor), fill=True, align="R")
            else:
                self.set_text_color(*TEXTO)
                self.set_font("helvetica", "", 10)
                self.cell(50, 7, t(etq))
                self.cell(40, 7, t(valor), align="R")
            self.ln()
        self.ln(2)

    def nota(self, texto):
        self.set_x(self.l_margin)
        self.set_font("helvetica", "", 9)
        self.set_text_color(*GRIS)
        self.multi_cell(0, 4.5, t(texto), new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def salida(self):
        return bytes(self.output())


# ---------------------------------------------------------------- los documentos

def factura(conn, did):
    d = next((x for x in C.documentos(conn, "cobrar") if x["id"] == did), None)
    if not d:
        raise C.ErrorContable("Esa factura no existe o está anulada.")
    pdf = Documento(conn, "Factura", d["numero"] or str(d["id"]), d["fecha"])
    pdf.bloque_persona("Cliente", d["tercero_id"], d["estado"])
    m = d["moneda"]
    items = conn.execute("SELECT mi.cantidad, p.nombre, p.unidad FROM mov_inventario mi JOIN productos p ON p.id = mi.producto_id"
                         " WHERE mi.tipo = 'venta' AND mi.asiento_venta_id = ?", (d["asiento_id"],)).fetchall()
    if items:
        filas = []
        for it in items:
            q = -it["cantidad"]
            filas.append([f"{it['nombre']} ({it['unidad']})", f"{q:g}", dinero(d["importe"] / q if q else 0), dinero(d["importe"])])
        pdf.tabla(["Descripción", "Cantidad", f"Precio ({m})", f"Importe ({m})"], filas, [90, 25, 32.5, 32.5], ["L", "R", "R", "R"])
    else:
        pdf.tabla(["Descripción", f"Importe ({m})"], [[d["concepto"], dinero(d["importe"])]], [147.5, 32.5], ["L", "R"])
    filas = [("Total", dinero(d["importe"], m), False)]
    if d["pagado"] > 0.004:
        filas.append(("Pagado", dinero(d["pagado"], m), False))
    filas.append(("Pendiente" if d["pendiente"] > 0.004 else "Total pagado", dinero(d["pendiente"] if d["pendiente"] > 0.004 else d["importe"], m), True))
    pdf.totales(filas)
    if d["vencimiento"] and d["pendiente"] > 0.004:
        pdf.nota(f"Fecha de vencimiento: {fecha(d['vencimiento'])}.")
    return pdf.salida(), f"Factura {d['numero'] or d['id']} - {d['tercero']}.pdf"


def _aplicado(conn, aid):
    return conn.execute(
        "SELECT l.*, cu.es_efectivo, cu.nombre cuenta, cu.rol, d.numero, d.id did, d.concepto dconcepto FROM lineas l"
        " JOIN cuentas cu ON cu.id = l.cuenta_id LEFT JOIN documentos d ON d.id = l.documento_id WHERE l.asiento_id = ? ORDER BY l.id",
        (aid,)).fetchall()


def recibo(conn, aid):
    a = conn.execute("SELECT * FROM asientos WHERE id = ? AND anulado = 0", (aid,)).fetchone()
    if not a or a["origen"] != "cobro":
        raise C.ErrorContable("Ese movimiento no es un cobro.")
    ls = _aplicado(conn, aid)
    caja = next((l for l in ls if l["es_efectivo"]), None)
    deudas = [l for l in ls if (l["rol"] or "").startswith("cxc_") or (not l["es_efectivo"] and l["haber"] > 0 and l["rol"] != "dif_cambio")]
    tid = next((l["tercero_id"] for l in ls if l["tercero_id"]), None)
    pdf = Documento(conn, "Recibo de pago", str(a["numero"]), a["fecha"])
    pdf.bloque_persona("Recibimos de", tid, None)
    recibido = abs(caja["importe_orig"]) if caja else 0
    mon = caja["moneda"] if caja else C.moneda_base(conn)
    y0 = pdf.get_y()
    pdf.set_fill_color(*VERDE)
    pdf.rect(15, y0, 180, 16, style="F", round_corners=True, corner_radius=2.5)
    pdf.set_xy(20, y0 + 3)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("helvetica", "", 9)
    pdf.cell(80, 4, t("LA CANTIDAD DE"))
    pdf.set_xy(20, y0 + 7)
    pdf.set_font("helvetica", "B", 15)
    pdf.cell(100, 7, t(dinero(recibido, mon)))
    if caja:
        pdf.set_xy(110, y0 + 5)
        pdf.set_font("helvetica", "", 9.5)
        pdf.cell(80, 6, t(f"en {caja['cuenta']}"), align="R")
    pdf.set_xy(15, y0 + 20)
    pdf.set_text_color(*TEXTO)
    otra = {l["moneda"] for l in deudas} - {mon}
    if otra and a["tasa"]:
        pdf.nota(f"Pago en {mon} de una deuda en {', '.join(sorted(otra))}, a la tasa de {a['tasa']:g} CUP por 1 USD.")
    pdf.ln(2)
    filas = []
    for l in deudas:
        que = (f"Factura {l['numero'] or l['did']}" + (f" · {l['dconcepto']}" if l["dconcepto"] else "")) if l["did"] else (l["descripcion"] or "A cuenta (sin factura)")
        filas.append([que, dinero(abs(l["importe_orig"]), l["moneda"])])
    if filas:
        pdf.tabla(["Aplicado a", "Importe"], filas, [140, 40], ["L", "R"])
    if tid:
        ec = C.estado_cuenta(conn, tid, "cobrar", hasta=a["fecha"])["tot"]
        tot = [(f"Le queda por pagar ({m})", dinero(ec[m]["pendiente"], m), False) for m in C.MONEDAS if abs(ec[m]["pendiente"]) > 0.004]
        if tot:
            pdf.totales(tot)
        else:
            pdf.totales([("Saldo", "Al día: no debe nada", True)])
    if a["referencia"]:
        pdf.nota(f"Referencia: {a['referencia']}")
    pdf.ln(14)
    pdf.set_draw_color(*GRIS)
    pdf.line(120, pdf.get_y(), 190, pdf.get_y())
    pdf.set_x(120)
    pdf.set_font("helvetica", "", 9)
    pdf.set_text_color(*GRIS)
    pdf.cell(70, 5, t(f"Recibido por {pdf.empresa['responsable'] or pdf.empresa['empresa']}"), align="C")
    nombre = conn.execute("SELECT nombre FROM terceros WHERE id = ?", (tid,)).fetchone() if tid else None
    return pdf.salida(), f"Recibo {a['numero']} - {nombre['nombre'] if nombre else 'pago'}.pdf"


def comprobante_venta(conn, aid):
    a = conn.execute("SELECT * FROM asientos WHERE id = ? AND anulado = 0", (aid,)).fetchone()
    if not a or a["origen"] != "ingreso":
        raise C.ErrorContable("Ese movimiento no es una venta cobrada.")
    ls = _aplicado(conn, aid)
    caja = next((l for l in ls if l["es_efectivo"]), None)
    tid = next((l["tercero_id"] for l in ls if l["tercero_id"]), None)
    pdf = Documento(conn, "Comprobante de venta", str(a["numero"]), a["fecha"])
    pdf.bloque_persona("Cliente", tid, "Pagada")
    m = caja["moneda"] if caja else C.moneda_base(conn)
    total = abs(caja["importe_orig"]) if caja else 0
    items = conn.execute("SELECT mi.cantidad, p.nombre, p.unidad FROM mov_inventario mi JOIN productos p ON p.id = mi.producto_id"
                         " WHERE mi.tipo = 'venta' AND mi.asiento_venta_id = ?", (aid,)).fetchall()
    if items:
        filas = [[f"{it['nombre']} ({it['unidad']})", f"{-it['cantidad']:g}", dinero(total / -it["cantidad"]), dinero(total)] for it in items]
        pdf.tabla(["Descripción", "Cantidad", f"Precio ({m})", f"Importe ({m})"], filas, [90, 25, 32.5, 32.5], ["L", "R", "R", "R"])
    else:
        pdf.tabla(["Descripción", f"Importe ({m})"], [[a["concepto"], dinero(total)]], [147.5, 32.5], ["L", "R"])
    pdf.totales([("Total pagado", dinero(total, m), True)])
    if caja:
        pdf.nota(f"Pagado en {caja['cuenta']}.")
    return pdf.salida(), f"Comprobante {a['numero']}.pdf"


def estado_cuenta(conn, tid, lado, desde=None, hasta=None):
    p = conn.execute("SELECT * FROM terceros WHERE id = ?", (tid,)).fetchone()
    if not p:
        raise C.ErrorContable("Esa persona no existe.")
    ec = C.estado_cuenta(conn, tid, lado, desde, hasta)
    pdf = Documento(conn, "Estado de cuenta", None, hasta or C.hoy())
    pdf.bloque_persona("Cliente" if lado == "cobrar" else "Proveedor", tid, None)
    if desde or hasta:
        pdf.nota(f"Período: {fecha(desde) if desde else 'desde el inicio'} - {fecha(hasta) if hasta else 'hoy'}")
    hubo = False
    for m in C.MONEDAS:
        tot = ec["tot"][m]
        cargos = [x for x in ec["cargos"] if x["moneda"] == m]
        pagos = [x for x in ec["pagos"] if x["moneda"] == m]
        if not cargos and not pagos and abs(tot["anterior"]) < 0.005:
            continue
        hubo = True
        if pdf.will_page_break(40):
            pdf.add_page()
        pdf.set_font("helvetica", "B", 12)
        pdf.set_text_color(*VERDE)
        pdf.cell(0, 8, t(f"En {m}"), new_x="LMARGIN", new_y="NEXT")
        filas = []
        if abs(tot["anterior"]) > 0.004:
            filas.append(["", "Saldo anterior", "", dinero(tot["anterior"])])
        for x in cargos:
            estado = (x["doc"]["estado"] if x.get("doc") else "") or ""
            filas.append([fecha(x["fecha"]), x["texto"], estado, dinero(x["importe"])])
        if filas:
            pdf.tabla(["Fecha", "Facturas y cargos", "Estado", "Importe"], filas, [24, 106, 22, 28], ["L", "L", "L", "R"])
        if pagos:
            pdf.tabla(["Fecha", "Pagos recibidos" if lado == "cobrar" else "Pagos hechos", "", "Importe"],
                      [[fecha(x["fecha"]), x["texto"] + (f" ({x['nota']})" if x.get("nota") else ""), "", dinero(x["importe"])] for x in pagos],
                      [24, 106, 22, 28], ["L", "L", "L", "R"])
        pdf.totales([("Total facturado", dinero(tot["total_cargos"], m), False), ("Total pagado", dinero(tot["pagos"], m), False),
                     ("Pendiente" if tot["pendiente"] >= -0.004 else "A su favor", dinero(abs(tot["pendiente"]), m), True)])
    if not hubo:
        pdf.nota("No hay movimientos.")
    return pdf.salida(), f"Estado de cuenta - {p['nombre']}.pdf"
