"""Metas del mes: meta de ventas, tope de gastos, meta de ganancia y topes por categoría de gasto.

- Ventas  = ingresos de operación (4.1: venta de productos, servicios, comisiones, alquileres cobrados).
- Gastos  = gastos de operación (6.x: personal, local, transporte, administración…). No incluye el costo de la
            mercancía vendida (va con las ventas) ni mermas, intereses o impuestos.
- Ganancia = todo lo ganado menos todo lo gastado (lo mismo que el Estado de resultados).

Cada meta vale "desde un mes en adelante" hasta que se cambie, o "solo ese mes"."""
import calendar
from datetime import date

import contab as C
from contab import ErrorContable, r2

PRINCIPALES = {"ventas": "Ventas del mes", "gastos": "Gastos del negocio", "ganancia": "Ganancia del mes"}


def _ym(d):
    return d.isoformat()[:7] if isinstance(d, date) else d[:7]


def _anterior(ym, n=1):
    y, m = int(ym[:4]), int(ym[5:7]) - n
    while m < 1:
        y, m = y - 1, m + 12
    while m > 12:
        y, m = y + 1, m - 12
    return f"{y:04d}-{m:02d}"


def nombre_mes(ym):
    return f"{C.MESES[int(ym[5:7]) - 1]} {ym[:4]}"


def cuentas_gasto(conn):
    return [dict(r) for r in conn.execute(
        "SELECT * FROM cuentas WHERE tipo = 'gasto' AND seccion = 'operacion' AND es_grupo = 0 AND activa = 1 ORDER BY codigo")]


def meta(conn, ym, clave):
    """La meta que vale en ese mes (None si no hay)."""
    r = conn.execute("SELECT importe FROM metas WHERE desde = ? AND clave = ? AND solo_mes = 1", (ym, clave)).fetchone()
    if r:
        return r[0]
    r = conn.execute("SELECT importe FROM metas WHERE desde <= ? AND clave = ? AND solo_mes = 0 ORDER BY desde DESC LIMIT 1",
                     (ym, clave)).fetchone()
    return r[0] if r else None


def guardar(conn, ym, valores, solo_mes=False):
    """valores: {clave: importe o None}. Solo cambia lo que es distinto de lo que ya valía."""
    for clave, imp in valores.items():
        if imp is not None and imp < 0:
            raise ErrorContable("Las metas no pueden ser negativas.")
        if clave not in PRINCIPALES and not (clave.startswith("cuenta:") and clave[7:].isdigit()):
            raise ErrorContable("Meta no válida.")
        imp = r2(imp) if imp else None
        if solo_mes:
            if (meta(conn, ym, clave) or None) == imp:
                continue
        else:  # desde este mes: se quita lo "solo este mes" que hubiera aquí
            conn.execute("DELETE FROM metas WHERE desde = ? AND clave = ? AND solo_mes = 1", (ym, clave))
            if (meta(conn, ym, clave) or None) == imp:
                continue
        conn.execute("INSERT OR REPLACE INTO metas (desde, clave, importe, solo_mes) VALUES (?, ?, ?, ?)",
                     (ym, clave, imp, 1 if solo_mes else 0))


def reales(conn, ym, hasta=None):
    """Ventas, gastos, ganancia y gasto por cuenta del mes (hasta 'hasta' si se da)."""
    desde = ym + "-01"
    fin = hasta or C.ultimo_dia(int(ym[:4]), int(ym[5:7]))
    mov = C.movimientos(conn, desde, fin)
    ventas = gastos = 0.0
    por_cuenta = {}
    for c in conn.execute("SELECT id, tipo, seccion FROM cuentas WHERE es_grupo = 0 AND tipo IN ('ingreso', 'gasto')"):
        d, h = mov.get(c["id"], (0, 0, 0))[:2]
        if c["tipo"] == "ingreso" and c["seccion"] == "operacion":
            ventas += h - d
        elif c["tipo"] == "gasto" and c["seccion"] == "operacion":
            gastos += d - h
            if abs(d - h) > 0.004:
                por_cuenta[c["id"]] = r2(d - h)
    return {"ventas": r2(ventas), "gastos": r2(gastos), "ganancia": C.resultado(conn, desde, fin), "por_cuenta": por_cuenta}


def avance(conn, ym, hoy=None):
    """Todo lo de la pantalla para un mes: cada meta con lo real, el % y, si es el mes en curso, a dónde llega a este ritmo."""
    hoy = hoy or date.today()
    y, m = int(ym[:4]), int(ym[5:7])
    dias = calendar.monthrange(y, m)[1]
    en_curso = ym == _ym(hoy)
    futuro = ym > _ym(hoy)
    dia = hoy.day if en_curso else (0 if futuro else dias)
    r = reales(conn, ym, hoy.isoformat() if en_curso else None)
    filas = []
    for clave, titulo in PRINCIPALES.items():
        filas.append(_fila(clave, titulo, r[clave], meta(conn, ym, clave), dia, dias, en_curso, clave == "gastos"))
    categorias = []
    nombres = {c["id"]: c for c in cuentas_gasto(conn)}
    con_tope = {int(k[7:]): v for k, v in
                ((x["clave"], meta(conn, ym, x["clave"])) for x in conn.execute("SELECT DISTINCT clave FROM metas WHERE clave LIKE 'cuenta:%'"))
                if v}
    for cid in sorted(set(con_tope) | set(r["por_cuenta"]), key=lambda i: -(r["por_cuenta"].get(i, 0))):
        if cid not in nombres:
            continue
        f = _fila(f"cuenta:{cid}", nombres[cid]["nombre"], r["por_cuenta"].get(cid, 0.0), con_tope.get(cid), dia, dias, en_curso, True)
        f["cuenta_id"] = cid
        categorias.append(f)
    return {"ym": ym, "nombre": nombre_mes(ym), "dia": dia, "dias": dias, "en_curso": en_curso, "futuro": futuro,
            "filas": filas, "categorias": categorias, "hay_metas": any(f["meta"] for f in filas + categorias)}


def _fila(clave, titulo, real, objetivo, dia, dias, en_curso, es_tope):
    f = {"clave": clave, "titulo": titulo, "real": r2(real), "meta": objetivo, "tope": es_tope,
         "pct": None, "proyeccion": None, "deberia": None, "estado": None}
    if en_curso and dia:
        f["proyeccion"] = r2(real / dia * dias)
    if objetivo:
        f["pct"] = round(real / objetivo * 100)
        f["deberia"] = r2(objetivo * dia / dias) if en_curso else None
        llega = f["proyeccion"] if f["proyeccion"] is not None else real
        if es_tope:
            f["estado"] = "pasado" if real > objetivo + 0.004 else "riesgo" if llega > objetivo + 0.004 else "bien"
        else:
            f["estado"] = "logrado" if real >= objetivo - 0.004 else "bien" if llega >= objetivo * 0.95 else "riesgo"
    return f


def historial(conn, ym, n=6):
    out = []
    for i in range(n - 1, -1, -1):
        mm = _anterior(ym, i)
        r = reales(conn, mm)
        out.append({"ym": mm, "corto": C.MESES_CORTOS[int(mm[5:7]) - 1], "en_curso": mm == _ym(date.today()), **{k: r[k] for k in PRINCIPALES},
                    **{"meta_" + k: meta(conn, mm, k) for k in PRINCIPALES}})
    return out


def avisos(conn, hoy=None):
    """Para 'Para revisar' en Inicio: (nivel, texto) del mes en curso."""
    hoy = hoy or date.today()
    a = avance(conn, _ym(hoy), hoy)
    out = []
    for f in a["filas"] + a["categorias"]:
        if not f["meta"]:
            continue
        if f["tope"] and f["estado"] == "pasado":
            out.append(("alta", f"{f['titulo']}: ya se pasó del tope del mes ({f['real']:,.2f} de {f['meta']:,.2f})."))
        elif f["tope"] and f["estado"] == "riesgo" and hoy.day >= 10:
            out.append(("media", f"{f['titulo']}: a este ritmo terminaría el mes en {f['proyeccion']:,.2f} (tope {f['meta']:,.2f})."))
        elif not f["tope"] and f["estado"] == "riesgo" and hoy.day >= 10:
            out.append(("media", f"{f['titulo']}: vas {f['real']:,.2f} de {f['meta']:,.2f}; a este ritmo llegarías a {f['proyeccion']:,.2f}."))
    return out
