"""Bóveda: cifrado de los datos con AES-256-GCM.

- Los datos viven cifrados en contabilidad.db.cifrado. Mientras el programa está abierto y alguien entró,
  se descifran a contabilidad.db (permiso solo del dueño); al cerrar o bloquear se vuelven a cifrar y se borra
  la copia descifrada.
- La llave de los datos (256 bits, al azar) se guarda en llaves.json "envuelta" (cifrada) una vez por usuario con
  su contraseña, y otra vez con su código de recuperación. La contraseña se convierte en llave con scrypt
  (n=2^17, r=8, p=1: ~0.4 s y 128 MB por intento, para que adivinar sea carísimo).
- Sin la contraseña o el código de recuperación de algún usuario, los datos no se pueden leer.
- La verificación en dos pasos (TOTP) también se guarda en llaves.json, cifrada con la llave de los datos.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import struct
import threading
import time
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

import db

MAGIA = b"MCV1"
MAGIA_COPIA = b"MCB2"   # copia portátil: lleva dentro las llaves envueltas (se abre en otra computadora)
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 17, 8, 1
_LLAVE = None            # llave de los datos en memoria (solo mientras está desbloqueada)
_CANDADO = threading.RLock()
ULTIMO_USO = [time.monotonic()]


class ErrorBoveda(Exception):
    pass


# ---------------------------------------------------------------- rutas y estado

def ruta_cifrada():
    return db.carpeta_datos() / "contabilidad.db.cifrado"


def ruta_llaves():
    return db.carpeta_datos() / "llaves.json"


def activa():
    """True si los datos ya están protegidos con cifrado."""
    return ruta_llaves().exists()


def abierta():
    return _LLAVE is not None


def estado():
    if not activa():
        return "sin_cifrar"
    return "abierta" if abierta() else "bloqueada"


def _b64(b):
    return base64.b64encode(b).decode()


def _d64(s):
    return base64.b64decode(s.encode())


def _leer_llaves():
    try:
        return json.loads(ruta_llaves().read_text())
    except FileNotFoundError:
        return {"version": 1, "usuarios": {}}


def _escribir_atomico(ruta, datos: bytes):
    tmp = ruta.with_name(ruta.name + ".tmp")
    with open(tmp, "wb") as f:
        f.write(datos)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, ruta)


def _guardar_llaves(d):
    _escribir_atomico(ruta_llaves(), json.dumps(d, indent=1).encode())


def borrar_seguro(ruta):
    """Sobrescribe con ceros antes de borrar (además, el disco ya está cifrado con FileVault)."""
    ruta = Path(ruta)
    try:
        tam = ruta.stat().st_size
        with open(ruta, "r+b") as f:
            f.write(b"\0" * tam)
            f.flush()
            os.fsync(f.fileno())
        ruta.unlink()
    except FileNotFoundError:
        pass


# ---------------------------------------------------------------- llaves

def _derivar(secreto: str, sal: bytes) -> bytes:
    return Scrypt(salt=sal, length=32, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P).derive(secreto.encode())


def _envolver(llave_datos: bytes, secreto: str, contexto: str):
    sal = os.urandom(16)
    nonce = os.urandom(12)
    ct = AESGCM(_derivar(secreto, sal)).encrypt(nonce, llave_datos, contexto.encode())
    return {"sal": _b64(sal), "llave": _b64(nonce + ct)}


def _desenvolver(slot, secreto: str, contexto: str):
    try:
        clave = _derivar(secreto, _d64(slot["sal"]))
        crudo = _d64(slot["llave"])
        return AESGCM(clave).decrypt(crudo[:12], crudo[12:], contexto.encode())
    except Exception:
        return None


def _cifrar(datos: bytes, aad: bytes = MAGIA) -> bytes:
    nonce = os.urandom(12)
    return MAGIA + nonce + AESGCM(_LLAVE).encrypt(nonce, datos, aad)


def _descifrar(blob: bytes, llave=None, aad: bytes = MAGIA) -> bytes:
    if blob[:4] != MAGIA:
        raise ErrorBoveda("Archivo cifrado no reconocido.")
    return AESGCM(llave or _LLAVE).decrypt(blob[4:16], blob[16:], aad)


def usuarios_con_llave():
    return set(_leer_llaves()["usuarios"])


def probar_clave(usuario, clave):
    """Devuelve la llave de los datos si la contraseña es correcta (no abre nada todavía)."""
    slot = _leer_llaves()["usuarios"].get(usuario)
    if not slot or "clave" not in slot:
        return None
    return _desenvolver(slot["clave"], clave, "clave:" + usuario)


def probar_codigo(usuario, codigo):
    slot = _leer_llaves()["usuarios"].get(usuario)
    if not slot or "recuperacion" not in slot:
        return None
    return _desenvolver(slot["recuperacion"], codigo, "rec:" + usuario)


def poner_llave(usuario, clave=None, codigo=None):
    """Guarda (o cambia) la contraseña y/o el código de recuperación de un usuario. Requiere la bóveda abierta."""
    with _CANDADO:
        if not abierta():
            raise ErrorBoveda("La bóveda está cerrada.")
        d = _leer_llaves()
        slot = d["usuarios"].setdefault(usuario, {})
        if clave is not None:
            slot["clave"] = _envolver(_LLAVE, clave, "clave:" + usuario)
        if codigo is not None:
            slot["recuperacion"] = _envolver(_LLAVE, codigo, "rec:" + usuario)
        _guardar_llaves(d)


def quitar_llave(usuario):
    with _CANDADO:
        d = _leer_llaves()
        d["usuarios"].pop(usuario, None)
        _guardar_llaves(d)


# ---------------------------------------------------------------- abrir / guardar / cerrar

def activar(usuario, clave, codigo):
    """Primera vez: crea la llave de los datos, cifra la base y las copias viejas."""
    global _LLAVE
    with _CANDADO:
        if activa():
            raise ErrorBoveda("El cifrado ya estaba activado.")
        _LLAVE = AESGCM.generate_key(256)
        d = {"version": 1, "creado": time.strftime("%Y-%m-%d %H:%M:%S"), "usuarios": {}}
        d["usuarios"][usuario] = {"clave": _envolver(_LLAVE, clave, "clave:" + usuario),
                                  "recuperacion": _envolver(_LLAVE, codigo, "rec:" + usuario)}
        guardar()                      # primero el archivo cifrado...
        _guardar_llaves(d)             # ...y después las llaves (si se corta aquí, todo sigue sin cifrar)
        cifrar_copias_viejas()


def abrir(llave):
    """Desbloquea con la llave ya comprobada: descifra la base al disco para trabajar."""
    global _LLAVE
    with _CANDADO:
        if abierta():
            return
        _LLAVE = llave
        plano = db.ruta_db()
        if plano.exists():
            # quedó de un cierre brusco (corte de corriente): es la versión más reciente; se vuelve a cifrar
            guardar()
        else:
            datos = _descifrar(ruta_cifrada().read_bytes())
            _escribir_atomico(plano, datos)
        ULTIMO_USO[0] = time.monotonic()
    try:
        actualizar_copias()
    except Exception as exc:
        print("No se pudieron actualizar las copias:", exc)


def guardar():
    """Cifra la base de trabajo y la guarda en contabilidad.db.cifrado."""
    with _CANDADO:
        if not abierta() or not db.ruta_db().exists():
            return
        tmp = db.carpeta_datos() / ".copia_para_cifrar.db"
        origen = sqlite3.connect(db.ruta_db())
        destino = sqlite3.connect(tmp)
        with destino:
            origen.backup(destino)
        origen.close()
        destino.close()
        try:
            _escribir_atomico(ruta_cifrada(), _cifrar(tmp.read_bytes()))
        finally:
            borrar_seguro(tmp)


def cerrar():
    """Guarda cifrado, borra la copia descifrada y olvida la llave."""
    global _LLAVE
    with _CANDADO:
        if not abierta():
            return
        guardar()
        for sufijo in ("", "-journal", "-wal", "-shm"):
            borrar_seguro(str(db.ruta_db()) + sufijo)
        _LLAVE = None


# ---------------------------------------------------------------- copias de seguridad cifradas

def empaquetar(datos_db: bytes) -> bytes:
    """Copia portátil = llaves envueltas (protegidas por las contraseñas/códigos) + base cifrada.
    Sin una contraseña o código de recuperación válidos sigue siendo ilegible."""
    llaves = ruta_llaves().read_bytes()
    return MAGIA_COPIA + len(llaves).to_bytes(4, "big") + llaves + _cifrar(datos_db)


def desempaquetar(blob: bytes):
    """Devuelve (llaves o None, parte cifrada)."""
    if blob[:4] == MAGIA_COPIA:
        n = int.from_bytes(blob[4:8], "big")
        return json.loads(blob[8:8 + n]), blob[8 + n:]
    if blob[:4] == MAGIA:
        return None, blob
    raise ErrorBoveda("Ese archivo no es una copia de Mi Contabilidad.")


def cifrar_archivo_copia(ruta_plana: Path) -> Path:
    destino = ruta_plana.with_name(ruta_plana.name + ".cifrado")
    _escribir_atomico(destino, empaquetar(ruta_plana.read_bytes()))
    borrar_seguro(ruta_plana)
    return destino


def cifrar_copias_viejas():
    carpeta = db.carpeta_copias()
    if carpeta.exists():
        for p in carpeta.glob("contabilidad_*.db"):
            cifrar_archivo_copia(p)
    actualizar_copias()


def actualizar_copias():
    """Las copias cifradas viejas (sin llaves dentro) pasan a ser portátiles."""
    carpeta = db.carpeta_copias()
    if not (carpeta.exists() and abierta()):
        return 0
    n = 0
    for p in carpeta.glob("contabilidad_*.db.cifrado"):
        blob = p.read_bytes()
        if blob[:4] == MAGIA:
            try:
                _escribir_atomico(p, empaquetar(_descifrar(blob)))
                n += 1
            except Exception:
                pass
    return n


def descifrar_copia(ruta: Path) -> bytes:
    _, cifrado = desempaquetar(Path(ruta).read_bytes())
    return _descifrar(cifrado)


def abrir_copia_portatil(blob: bytes, usuario: str, secreto: str):
    """Para una computadora nueva: abre la copia con una contraseña o código de recuperación que estaba
    vigente cuando se hizo. Devuelve (llave, llaves, datos de la base) o lanza ErrorBoveda."""
    llaves, cifrado = desempaquetar(blob)
    if not llaves:
        raise ErrorBoveda("Esta copia es de un formato viejo y solo se abre en la computadora donde se hizo.")
    slot = llaves.get("usuarios", {}).get((usuario or "").strip().lower())
    if not slot:
        raise ErrorBoveda("Usuario o contraseña incorrectos.")
    llave = None
    if "clave" in slot:
        llave = _desenvolver(slot["clave"], secreto, "clave:" + usuario)
    if not llave and "recuperacion" in slot:
        import re
        c = re.sub(r"[^A-Z0-9]", "", (secreto or "").upper())
        codigo = "-".join(c[i:i + 4] for i in range(0, len(c), 4))
        llave = _desenvolver(slot["recuperacion"], codigo, "rec:" + usuario)
    if not llave:
        raise ErrorBoveda("Usuario o contraseña incorrectos.")
    try:
        datos = _descifrar(cifrado, llave)
    except Exception:
        raise ErrorBoveda("La copia está dañada.")
    return llave, llaves, datos


def reemplazar_con_copia(blob: bytes, usuario: str, secreto: str):
    """Pone aquí los datos (y los usuarios) de una copia portátil de otro equipo, aunque aquí ya haya datos.
    Quien llame debe hacer antes una copia de lo que había. Al terminar queda cerrado: se entra con los de la copia."""
    global _LLAVE
    with _CANDADO:
        llave, llaves, datos = abrir_copia_portatil(blob, usuario, secreto)
        for sufijo in ("-journal", "-wal", "-shm"):
            borrar_seguro(str(db.ruta_db()) + sufijo)
        _escribir_atomico(db.ruta_db(), datos)
        _LLAVE = llave
        guardar()
        _guardar_llaves(llaves)
    cerrar()


def instalar_desde_copia(blob: bytes, usuario: str, secreto: str):
    """Pone en esta computadora los datos de una copia portátil (solo si aquí no hay datos todavía)."""
    global _LLAVE
    with _CANDADO:
        if activa():
            raise ErrorBoveda("Esta computadora ya tiene datos cifrados.")
        llave, llaves, datos = abrir_copia_portatil(blob, usuario, secreto)
        _LLAVE = llave
        _escribir_atomico(db.ruta_db(), datos)
        guardar()
        _guardar_llaves(llaves)
        ULTIMO_USO[0] = time.monotonic()


def volumenes_externos():
    """Memorias USB y discos externos conectados."""
    raiz = Path(os.environ.get("MC_VOLUMENES", "/Volumes"))
    out = []
    if raiz.exists():
        for v in sorted(raiz.iterdir()):
            try:
                if v.is_dir() and not v.is_symlink() and os.access(v, os.W_OK) and v.name not in ("Macintosh HD", "Recovery", "Preboot"):
                    out.append(v)
            except OSError:
                pass
    return out


# ---------------------------------------------------------------- verificación en dos pasos (TOTP, RFC 6238)

def _totp(secreto_b32, paso):
    k = base64.b32decode(secreto_b32 + "=" * (-len(secreto_b32) % 8))
    h = hmac.new(k, struct.pack(">Q", paso), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000:06d}"


def nuevo_secreto_totp():
    return base64.b32encode(os.urandom(20)).decode().rstrip("=")


def comprobar_totp(secreto, codigo, ultimo_paso=None):
    """Devuelve el paso usado si el código es válido (acepta 30 s antes/después) y no se usó ya; si no, None."""
    codigo = "".join(ch for ch in (codigo or "") if ch.isdigit())
    if len(codigo) != 6:
        return None
    ahora = int(time.time() // 30)
    for paso in (ahora, ahora - 1, ahora + 1):
        if hmac.compare_digest(_totp(secreto, paso), codigo) and (ultimo_paso is None or paso > ultimo_paso):
            return paso
    return None


def totp_de(usuario, llave=None):
    """Datos de doble verificación del usuario (descifrados), o None si no la tiene."""
    slot = _leer_llaves()["usuarios"].get(usuario, {})
    if "totp" not in slot:
        return None
    return json.loads(_descifrar(_d64(slot["totp"]), llave, ("totp:" + usuario).encode()))


def guardar_totp(usuario, datos, llave=None):
    global _LLAVE
    with _CANDADO:
        d = _leer_llaves()
        slot = d["usuarios"].setdefault(usuario, {})
        if datos is None:
            slot.pop("totp", None)
        else:
            l = llave or _LLAVE
            nonce = os.urandom(12)
            slot["totp"] = _b64(MAGIA + nonce + AESGCM(l).encrypt(nonce, json.dumps(datos).encode(),
                                                                   ("totp:" + usuario).encode()))
        _guardar_llaves(d)


def uri_totp(secreto, usuario, empresa):
    from urllib.parse import quote
    etiqueta = quote(f"Mi Contabilidad:{usuario}")
    return f"otpauth://totp/{etiqueta}?secret={secreto}&issuer={quote('Mi Contabilidad ' + empresa)}&digits=6&period=30"


def qr_svg(texto):
    import io
    import qrcode
    import qrcode.image.svg
    img = qrcode.make(texto, image_factory=qrcode.image.svg.SvgPathImage, box_size=8, border=2)
    out = io.BytesIO()
    img.save(out)
    return out.getvalue().decode()
