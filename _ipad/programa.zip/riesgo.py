"""Riesgo de la tasa: cuánto cambia el valor (en la moneda base) de lo que tienes y debes en la otra moneda
si la tasa de cambio sube o baja. Solo calcula: no crea asientos."""
import contab as C
import db
from contab import r2

PASO = 10   # "cada vez que la tasa sube 10 pesos…"


def _otra(base):
    return "CUP" if base == "USD" else "USD"


def tope_aviso(conn):
    """Pérdida (en moneda base) a partir de la cual sale un aviso en 'Para revisar' si la tasa sube un 10 %."""
    base = C.moneda_base(conn)
    v = db.get_config(conn, "riesgo_aviso")
    try:
        return float(v) if v not in (None, "") else (500.0 if base == "USD" else 250000.0)
    except ValueError:
        return 500.0 if base == "USD" else 250000.0


def calcular(conn, fecha=None):
    """Lo que hay en la otra moneda (activos menos pasivos), cuenta por cuenta y, en las de personas, quién pesa más."""
    base = C.moneda_base(conn)
    otra = _otra(base)
    fecha = fecha or C.hoy()
    tasa = C.tasa_del_dia(conn, fecha)
    out = {"base": base, "otra": otra, "fecha": fecha, "tasa": tasa, "filas": [], "neto": 0.0}
    if not tasa:
        return out
    movs = C.movimientos(conn, None, fecha)
    for c in C.cuentas(conn):
        if c["es_grupo"] or c["tipo"] not in ("activo", "pasivo"):
            continue
        if c["moneda"] == otra:
            o = r2(movs.get(c["id"], (0, 0, 0))[2])
        elif not c["moneda"] and c["por_tercero"] and not (c["codigo"] or "").startswith("1.6"):
            # cuentas de personas sin moneda fija (anticipos, acreedores, salarios): solo lo apuntado en la otra moneda
            o = r2(conn.execute("SELECT COALESCE(SUM(l.importe_orig), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                                " WHERE a.anulado = 0 AND l.cuenta_id = ? AND l.moneda = ? AND a.fecha <= ?", (c["id"], otra, fecha)).fetchone()[0])
        else:
            continue
        if abs(o) < 0.005:
            continue
        personas = []
        if c["por_tercero"]:
            q = ("SELECT t.nombre, SUM(l.importe_orig) o FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
                 " JOIN terceros t ON t.id = l.tercero_id WHERE a.anulado = 0 AND l.cuenta_id = ? AND l.moneda = ? AND a.fecha <= ?"
                 " GROUP BY t.id HAVING ABS(SUM(l.importe_orig)) >= 0.005 ORDER BY ABS(SUM(l.importe_orig)) DESC LIMIT 5")
            personas = [{"nombre": p["nombre"], "orig": r2(p["o"])} for p in conn.execute(q, (c["id"], otra, fecha))]
        etiqueta = {"activo": "lo que tienes o te deben", "pasivo": "lo que debes"}[c["tipo"]]
        out["filas"].append({"id": c["id"], "nombre": c["nombre"], "tipo": c["tipo"], "orig": o, "etiqueta": etiqueta, "personas": personas})
    out["filas"].sort(key=lambda f: -abs(f["orig"]))
    out["neto"] = r2(sum(f["orig"] for f in out["filas"]))
    out["hoy_vale"] = r2(valor(out["neto"], otra, base, tasa))
    out["por_paso"] = r2(efecto(out["neto"], otra, base, tasa, tasa + PASO))
    out["sube10"] = r2(efecto(out["neto"], otra, base, tasa, tasa * 1.10))
    out["escenarios"] = [{"tasa": t, "valor": r2(valor(out["neto"], otra, base, t)), "efecto": r2(efecto(out["neto"], otra, base, tasa, t))}
                         for t in sorted({_redondo(tasa * k) for k in (0.9, 1.05, 1.10, 1.25)} | {tasa})]
    out["mayor"] = out["filas"][0] if out["filas"] else None
    return out


def _redondo(t):
    return round(t / 5) * 5 if t >= 50 else round(t, 2)


def valor(orig, otra, base, tasa):
    return C.convertir(orig, otra, base, tasa)


def efecto(orig, otra, base, tasa_hoy, tasa_nueva):
    """Lo que se gana (+) o se pierde (−), en moneda base, si la tasa pasa de tasa_hoy a tasa_nueva."""
    return valor(orig, otra, base, tasa_nueva) - valor(orig, otra, base, tasa_hoy)


def aviso(conn):
    """(nivel, texto) si una subida del 10 % de la tasa haría perder más del tope; si no, None."""
    r = calcular(conn)
    if not r["tasa"] or not r["filas"]:
        return None
    perdida = -min(r["sube10"], efecto(r["neto"], r["otra"], r["base"], r["tasa"], r["tasa"] * 0.9))
    if perdida > tope_aviso(conn):
        sube = r["sube10"] < 0
        return ("media", f"Riesgo de la tasa: si la tasa {'sube' if sube else 'baja'} un 10 %, lo que tienes en {r['otra']} "
                         f"perdería {perdida:,.2f} {r['base']}.")
    return None
