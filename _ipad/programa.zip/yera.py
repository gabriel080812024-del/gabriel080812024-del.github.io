"""Cuadre con el Yera: abre el archivo cifrado de su app (Caja del Yera) y lo compara con la contabilidad.

Los datos del Yera se guardan aparte (tabla yera_mov) y NUNCA se mezclan con los asientos: son la contrapartida
independiente para revisar lo que anotó la contadora. Cada carga reemplaza la anterior (el archivo trae todo)."""
import base64
import gzip
import json
from datetime import date, datetime

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

import contab as C
from contab import ErrorContable, r2

DIAS = 3  # margen de días entre lo del Yera y lo anotado


def asegurar_tabla(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS yera_mov (
        id TEXT PRIMARY KEY, tipo TEXT NOT NULL, fecha TEXT NOT NULL, datos TEXT NOT NULL,
        comprobante BLOB, comprobante_tipo TEXT, importado TEXT NOT NULL)""")
    conn.execute("CREATE TABLE IF NOT EXISTS yera_carga (id INTEGER PRIMARY KEY, fecha TEXT, generado TEXT, n INTEGER, saldo_cup REAL, saldo_usd REAL)")


def leer_archivo(datos: bytes, clave: str) -> dict:
    if len(datos) < 40 or datos[:5] != b"YERA1":
        raise ErrorContable("Ese archivo no es de la Caja del Yera.")
    gz, sal, iv, cifrado = datos[5], datos[6:22], datos[22:34], datos[34:]
    llave = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=sal, iterations=210000).derive((clave or "").encode())
    try:
        plano = AESGCM(llave).decrypt(iv, cifrado, None)
    except Exception:
        raise ErrorContable("La contraseña no es la del archivo del Yera.")
    if gz:
        plano = gzip.decompress(plano)
    d = json.loads(plano.decode("utf-8"))
    if d.get("formato") != "caja-yera":
        raise ErrorContable("Ese archivo no es de la Caja del Yera.")
    return d


def importar(conn, d: dict):
    asegurar_tabla(conn)
    ahora = datetime.now().isoformat(timespec="seconds")
    conn.execute("DELETE FROM yera_mov")
    n = 0
    for m in d.get("movimientos") or []:
        if not isinstance(m, dict) or m.get("tipo") not in ("zelle", "recibi", "cambio", "pague", "entregue") or not m.get("id"):
            continue
        comp = m.pop("comprobante", None)
        blob, tipo = None, None
        if isinstance(comp, dict) and comp.get("datos"):
            blob, tipo = base64.b64decode(comp["datos"]), str(comp.get("tipo") or "image/jpeg")[:40]
        conn.execute("INSERT OR REPLACE INTO yera_mov (id, tipo, fecha, datos, comprobante, comprobante_tipo, importado) VALUES (?,?,?,?,?,?,?)",
                     (str(m["id"])[:60], m["tipo"], str(m.get("fecha") or "")[:10], json.dumps(m), blob, tipo, ahora))
        n += 1
    s = d.get("saldos") or {}
    conn.execute("INSERT INTO yera_carga (fecha, generado, n, saldo_cup, saldo_usd) VALUES (?,?,?,?,?)",
                 (ahora, str(d.get("generado") or "")[:30], n, s.get("CUP"), s.get("USD")))
    return n


def _dias(a, b):
    try:
        return abs((date.fromisoformat(a) - date.fromisoformat(b)).days)
    except ValueError:
        return 999


def _lineas_caja(conn, desde, hasta):
    """Movimientos de cajas y bancos (lo que entra y sale de dinero) en el período, con el asiento al que pertenecen."""
    filas = conn.execute(
        "SELECT a.id aid, a.numero, a.fecha, a.concepto, a.origen, l.moneda, l.importe_orig imp, cu.nombre cuenta, cu.rol"
        " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cu ON cu.id = l.cuenta_id"
        " WHERE a.anulado = 0 AND cu.es_efectivo = 1 AND a.fecha BETWEEN date(?, '-5 day') AND date(?, '+5 day')",
        (desde, hasta)).fetchall()
    por_asiento = {}
    for f in filas:
        a = por_asiento.setdefault(f["aid"], {"aid": f["aid"], "numero": f["numero"], "fecha": f["fecha"], "concepto": f["concepto"],
                                              "origen": f["origen"], "lineas": []})
        a["lineas"].append({"moneda": f["moneda"], "imp": f["imp"], "cuenta": f["cuenta"]})
    return list(por_asiento.values())


def _tiene(a, moneda, importe):
    return any(l["moneda"] == moneda and abs(l["imp"] - importe) < 0.01 for l in a["lineas"])


def _tiene_alguno(a, moneda, importes):
    return any(_tiene(a, moneda, x) for x in importes)


def _gan(m, moneda):
    """Lo que se quedó el Yera (su %) en esa moneda: sale del dinero de Gabriel."""
    return (m.get("ganancia") or 0) if m.get("gan_moneda") == moneda else 0


def cuadre(conn):
    """Compara cada movimiento del Yera con la contabilidad.
    estado: cuadra | no_coincide | falta_anotar; y además los Zelle anotados que el Yera no tiene (falta_en_yera)."""
    asegurar_tabla(conn)
    movs = [dict(json.loads(r["datos"]), _tiene_comp=bool(r["tiene"]))
            for r in conn.execute("SELECT datos, comprobante IS NOT NULL tiene FROM yera_mov ORDER BY fecha, id")]
    if not movs:
        return {"filas": [], "resumen": {}, "carga": None}
    desde, hasta = min(m["fecha"] for m in movs), max(m["fecha"] for m in movs)
    asientos = _lineas_caja(conn, desde, hasta)
    usados = set()
    filas = []

    def buscar(cond, m):
        cands = [a for a in asientos if a["aid"] not in usados and _dias(a["fecha"], m["fecha"]) <= DIAS and cond(a)]
        cands.sort(key=lambda a: (_dias(a["fecha"], m["fecha"]), a["origen"] != ("zelle" if m["tipo"] == "zelle" else a["origen"])))
        return cands[0] if cands else None

    for m in movs:
        t = m["tipo"]
        det = ""
        if t == "zelle":
            z = m.get("zelle") or 0
            a = buscar(lambda a: any(l["imp"] > 0 and abs(l["imp"] - z) < 0.01 and l["moneda"] == "USD" for l in a["lineas"]), m)
            texto, importe, moneda = f"Compré Zelle{(' · ' + m['banco']) if m.get('banco') else ''}", z, "USD"
            if a:
                pc, pu = m.get("pago_cup") or 0, m.get("pago_usd") or 0
                # la contadora puede anotar el pago solo, o el pago más la ganancia del Yera
                ok_cup = (not pc and not _gan(m, "CUP")) or _tiene_alguno(a, "CUP", [-pc, -(pc + _gan(m, "CUP"))])
                ok_usd = (not pu and not _gan(m, "USD")) or _tiene_alguno(a, "USD", [-pu, -(pu + _gan(m, "USD"))])
                if ok_cup and ok_usd:
                    estado = "cuadra"
                else:
                    estado = "no_coincide"
                    anot = ", ".join(f"{abs(l['imp']):,.2f} {l['moneda']}" for l in a["lineas"] if l["imp"] < 0)
                    pago = " y ".join(x for x in (f"{pu:,.2f} USD" if pu else "", f"{pc:,.2f} CUP" if pc else "") if x)
                    det = f"El Yera pagó {pago}; la contadora anotó {anot or 'otro pago'}."
        else:
            if t == "cambio":
                cup, usd = m.get("cup") or 0, m.get("usd") or 0
                a = buscar(lambda a: _tiene_alguno(a, "CUP", [-cup, -(cup + _gan(m, "CUP"))])
                           and _tiene_alguno(a, "USD", [usd, usd - _gan(m, "USD")]), m)
                texto, importe, moneda = "Cambié CUP a USD", usd, "USD"
                det = f"{cup:,.0f} CUP → {usd:,.2f} USD"
            else:
                imp, mon = m.get("importe") or 0, m.get("moneda") or "CUP"
                signo = 1 if t == "recibi" else -1
                a = buscar(lambda a: _tiene_alguno(a, mon, [signo * imp, signo * (imp + _gan(m, mon))]), m)
                texto = {"recibi": f"Recibí de {m.get('de') or '—'}", "pague": f"Pagué a {m.get('a') or '—'}",
                         "entregue": "Le entregué a Gabriel"}[t]
                importe, moneda = imp, mon
                det = m.get("concepto") or m.get("nota") or ""
            estado = "cuadra" if a else None
        if not a:
            # ¿hay algo parecido el mismo día (importe distinto)?
            mon_b = moneda
            parecido = [x for x in asientos if x["aid"] not in usados and _dias(x["fecha"], m["fecha"]) <= 1
                        and any(l["moneda"] == mon_b and importe and abs(abs(l["imp"]) - importe) / importe < 0.15 for l in x["lineas"])
                        and (t != "zelle" or x["origen"] == "zelle")]
            if parecido:
                a = parecido[0]
                estado = "no_coincide"
                otro = next(abs(l["imp"]) for l in a["lineas"] if l["moneda"] == mon_b and abs(abs(l["imp"]) - importe) / importe < 0.15)
                det = f"El Yera dice {importe:,.2f} {moneda}; la contadora anotó {otro:,.2f} {moneda}."
            else:
                estado = "falta_anotar"
        if a:
            usados.add(a["aid"])
        if m.get("ganancia"):
            g = f"El Yera cobró {m['gan_pct']} %: {m['ganancia']:,.2f} {m['gan_moneda']}."
            det = f"{det} {g}".strip() if det else g
        filas.append({"id": m["id"], "fecha": m["fecha"], "tipo": t, "texto": texto, "importe": r2(importe), "moneda": moneda, "estado": estado,
                      "detalle": det, "asiento": a, "confirmacion": m.get("confirmacion"), "comprobante": m["_tiene_comp"]})
    # Zelle anotados en la contabilidad que el Yera no tiene
    for a in asientos:
        if a["aid"] in usados or a["origen"] != "zelle" or not (desde <= a["fecha"] <= hasta):
            continue
        z = sum(l["imp"] for l in a["lineas"] if l["imp"] > 0 and l["moneda"] == "USD")
        filas.append({"id": None, "fecha": a["fecha"], "tipo": "zelle", "texto": a["concepto"] or "Compra de Zelle", "importe": r2(z), "moneda": "USD",
                      "estado": "falta_en_yera", "detalle": "Está en la contabilidad y el Yera no tiene su captura.", "asiento": a,
                      "confirmacion": None, "comprobante": False})
    filas.sort(key=lambda f: (f["fecha"], f["tipo"]))
    resumen = {k: sum(1 for f in filas if f["estado"] == k) for k in ("cuadra", "no_coincide", "falta_anotar", "falta_en_yera")}
    ganancias = {"USD": r2(sum(_gan(m, "USD") for m in movs)), "CUP": r2(sum(_gan(m, "CUP") for m in movs))}
    carga = conn.execute("SELECT * FROM yera_carga ORDER BY id DESC LIMIT 1").fetchone()
    return {"filas": filas, "resumen": resumen, "carga": dict(carga) if carga else None, "desde": desde, "hasta": hasta, "ganancias": ganancias}


def comprobante(conn, mid):
    asegurar_tabla(conn)
    r = conn.execute("SELECT comprobante, comprobante_tipo FROM yera_mov WHERE id = ?", (mid,)).fetchone()
    return (r["comprobante"], r["comprobante_tipo"]) if r and r["comprobante"] else (None, None)
