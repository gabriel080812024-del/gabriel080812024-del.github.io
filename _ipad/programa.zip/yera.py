"""Cuadre con el Yera: abre el archivo cifrado de su app (Caja del Yera) y lo compara con la contabilidad.

Los datos del Yera se guardan aparte (tabla yera_mov) y NUNCA se mezclan con los asientos: son la contrapartida
independiente para revisar lo que anotó la contadora. Cada carga reemplaza la anterior (el archivo trae todo)."""
import base64
import gzip
import hashlib
import json
from datetime import date, datetime

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

import contab as C
from contab import ErrorContable, r2

DIAS = 3  # margen de días entre lo del Yera y lo anotado


def asegurar_tabla(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS yera_mov (
        id TEXT PRIMARY KEY, tipo TEXT NOT NULL, fecha TEXT NOT NULL, datos TEXT NOT NULL,
        comprobante BLOB, comprobante_tipo TEXT, importado TEXT NOT NULL)""")
    conn.execute("CREATE TABLE IF NOT EXISTS yera_carga (id INTEGER PRIMARY KEY, fecha TEXT, generado TEXT, n INTEGER, saldo_cup REAL, saldo_usd REAL)")
    # la bitácora del Yera se acumula aquí y NUNCA se borra: es la prueba de lo que hizo aunque él borre su app
    conn.execute("CREATE TABLE IF NOT EXISTS yera_bitacora (serie INTEGER NOT NULL DEFAULT 1, n INTEGER NOT NULL, prev TEXT NOT NULL, hash TEXT NOT NULL,"
                 " d TEXT NOT NULL, recibido TEXT NOT NULL, PRIMARY KEY (serie, n))")
    if "aviso" not in [r[1] for r in conn.execute("PRAGMA table_info(yera_carga)")]:
        conn.execute("ALTER TABLE yera_carga ADD COLUMN aviso TEXT")


def leer_archivo(datos: bytes, clave: str) -> dict:
    if len(datos) < 40 or datos[:5] != b"YERA1":
        raise ErrorContable("Ese archivo no es de la Caja del Yera.")
    gz, sal, iv, cifrado = datos[5], datos[6:22], datos[22:34], datos[34:]
    llave = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=sal, iterations=210000).derive((clave or "").encode())
    try:
        plano = AESGCM(llave).decrypt(iv, cifrado, None)
    except Exception:
        raise ErrorContable("La contraseña no es la del archivo del Yera.")
    if gz:
        plano = gzip.decompress(plano)
    d = json.loads(plano.decode("utf-8"))
    if d.get("formato") != "caja-yera":
        raise ErrorContable("Ese archivo no es de la Caja del Yera.")
    return d


def importar(conn, d: dict):
    asegurar_tabla(conn)
    ahora = datetime.now().isoformat(timespec="seconds")
    conn.execute("DELETE FROM yera_mov")
    n = 0
    for m in d.get("movimientos") or []:
        if not isinstance(m, dict) or m.get("tipo") not in ("zelle", "recibi", "cambio", "pague", "entregue") or not m.get("id"):
            continue
        comp = m.pop("comprobante", None)
        blob, tipo = None, None
        if isinstance(comp, dict) and comp.get("datos"):
            blob, tipo = base64.b64decode(comp["datos"]), str(comp.get("tipo") or "image/jpeg")[:40]
        conn.execute("INSERT OR REPLACE INTO yera_mov (id, tipo, fecha, datos, comprobante, comprobante_tipo, importado) VALUES (?,?,?,?,?,?,?)",
                     (str(m["id"])[:60], m["tipo"], str(m.get("fecha") or "")[:10], json.dumps(m), blob, tipo, ahora))
        n += 1
    s = d.get("saldos") or {}
    aviso = revisar_bitacora(conn, d.get("bitacora"), ahora)
    generado = str(d.get("generado") or "")[:30]
    try:  # el teléfono lo pone en hora universal: pasarlo a la hora de aquí (si no, de noche sale el día siguiente)
        generado = datetime.fromisoformat(generado.replace("Z", "+00:00")).astimezone().replace(tzinfo=None).isoformat(timespec="seconds")
    except ValueError:
        pass
    conn.execute("INSERT INTO yera_carga (fecha, generado, n, saldo_cup, saldo_usd, aviso) VALUES (?,?,?,?,?,?)",
                 (ahora, generado, n, s.get("CUP"), s.get("USD"), aviso))
    return n


def _sello(e):
    return hashlib.sha256((str(e.get("prev")) + "|" + str(e.get("d"))).encode("utf-8")).hexdigest()


def revisar_bitacora(conn, entradas, ahora):
    """Comprueba la cadena de la bitácora que trae el archivo, la compara con la que ya teníamos y guarda lo nuevo.
    Devuelve el aviso (texto) si algo no cuadra, o None."""
    avisos = []
    lista = [e for e in (entradas or []) if isinstance(e, dict)]
    rota, prev = None, "0"
    for i, e in enumerate(lista):
        if e.get("n") != i + 1 or e.get("prev") != prev or _sello(e) != e.get("hash"):
            rota = i + 1
            break
        prev = e["hash"]
    if rota:
        avisos.append(f"La bitácora que viene en el archivo está alterada desde el apunte n.º {rota}.")
        lista = lista[:rota - 1]
    serie = conn.execute("SELECT MAX(serie) FROM yera_bitacora").fetchone()[0] or 1
    guardada = {r["n"]: r["hash"] for r in conn.execute("SELECT n, hash FROM yera_bitacora WHERE serie = ?", (serie,))}
    if guardada and not entradas:
        avisos.append(f"El archivo no trae bitácora y ya tenías {len(guardada)} apuntes: puede que se haya borrado la app o sus datos.")
    else:
        recibida = {e["n"]: e["hash"] for e in lista}
        faltan = sorted(n for n, h in guardada.items() if recibida.get(n) != h)
        if faltan:
            avisos.append(f"Faltan o cambiaron {len(faltan)} apuntes de la bitácora que ya tenías (desde el n.º {faltan[0]}): "
                          "se borró o se reinstaló la app, o se tocaron los datos. Lo que tenías guardado aquí se conserva y lo nuevo se guarda aparte.")
            serie, guardada = serie + 1, {}
        for e in lista:
            if e["n"] not in guardada:
                conn.execute("INSERT INTO yera_bitacora (serie, n, prev, hash, d, recibido) VALUES (?,?,?,?,?,?)",
                             (serie, e["n"], e["prev"], e["hash"], e["d"], ahora))
    return " ".join(avisos) or None


def bitacora(conn, limite=300):
    """Los apuntes guardados (lo último primero), marcando lo que se cambió o borró DESPUÉS de mandárselo a Gabriel."""
    asegurar_tabla(conn)
    ents = []
    for r in conn.execute("SELECT serie, n, d, recibido FROM yera_bitacora ORDER BY serie, n"):
        try:
            e = json.loads(r["d"])
        except ValueError:
            continue
        e["_n"], e["_recibido"], e["_serie"] = r["n"], r["recibido"], r["serie"]
        ents.append(e)
    visto, enviado = {}, set()   # cuándo se anotó cada operación y cuáles ya iban en un archivo mandado
    for e in ents:
        acc, mid = e.get("accion"), e.get("id")
        if acc == "inicio":
            for x in e.get("todas") or []:
                visto[x.get("id")] = e["_n"]
        elif acc in ("crear", "recuperar") and mid:
            visto[mid] = e["_n"]
        elif acc == "enviar":
            enviado |= set(visto)
        if acc in ("modificar", "borrar") and mid in enviado:
            e["_despues_de_mandar"] = True
        e["_cambios"] = _cambios(e.get("antes"), e.get("despues")) if acc == "modificar" else []
        try:  # hora del teléfono (universal) → hora de aquí
            e["_hora"] = datetime.fromisoformat(str(e.get("cuando")).replace("Z", "+00:00")).astimezone().strftime("%d/%m/%Y %H:%M")
        except ValueError:
            e["_hora"] = str(e.get("cuando") or "")[:16]
    return list(reversed(ents))[:limite]


ETIQ = {"zelle": "Zelle", "quien": "Quién mandó", "banco": "Banco", "confirmacion": "N.º confirmación", "fecha": "Fecha", "pago_usd": "Pagó USD",
        "pago_cup": "Pagó CUP", "tasa": "Tasa", "mercado_pct": "% vendedor", "gan_pct": "% ganancia", "ganancia": "Ganancia", "gan_moneda": "Ganancia en",
        "pago_en": "Paga en", "importe": "Importe", "moneda": "Moneda", "de": "De", "a": "A", "concepto": "Por", "nota": "Nota", "cup": "CUP", "usd": "USD",
        "dir": "Cambio", "foto": "Foto", "manual": "A mano", "cuenta": "Cuenta"}


def _cambios(antes, despues):
    a, b = antes or {}, despues or {}
    out = []
    for k in list(dict.fromkeys(list(a) + list(b))):
        if a.get(k) != b.get(k):
            out.append(f"{ETIQ.get(k, k)}: {a.get(k, '—')} → {b.get(k, '—')}")
    return out


def _dias(a, b):
    try:
        return abs((date.fromisoformat(a) - date.fromisoformat(b)).days)
    except ValueError:
        return 999


def _lineas_caja(conn, desde, hasta):
    """Movimientos de cajas y bancos (lo que entra y sale de dinero) en el período, con el asiento al que pertenecen."""
    filas = conn.execute(
        "SELECT a.id aid, a.numero, a.fecha, a.concepto, a.origen, l.moneda, l.importe_orig imp, cu.nombre cuenta, cu.rol"
        " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cu ON cu.id = l.cuenta_id"
        " WHERE a.anulado = 0 AND cu.es_efectivo = 1 AND a.fecha BETWEEN date(?, '-5 day') AND date(?, '+5 day')",
        (desde, hasta)).fetchall()
    por_asiento = {}
    for f in filas:
        a = por_asiento.setdefault(f["aid"], {"aid": f["aid"], "numero": f["numero"], "fecha": f["fecha"], "concepto": f["concepto"],
                                              "origen": f["origen"], "lineas": []})
        a["lineas"].append({"moneda": f["moneda"], "imp": f["imp"], "cuenta": f["cuenta"]})
    return list(por_asiento.values())


def _tiene(a, moneda, importe):
    return any(l["moneda"] == moneda and abs(l["imp"] - importe) < 0.01 for l in a["lineas"])


def _tiene_alguno(a, moneda, importes):
    return any(_tiene(a, moneda, x) for x in importes)


def _gan(m, moneda):
    """Lo que se quedó el Yera (su %) en esa moneda: sale del dinero de Gabriel."""
    return (m.get("ganancia") or 0) if m.get("gan_moneda") == moneda else 0


def cuadre(conn):
    """Compara cada movimiento del Yera con la contabilidad.
    estado: cuadra | no_coincide | falta_anotar; y además los Zelle anotados que el Yera no tiene (falta_en_yera)."""
    asegurar_tabla(conn)
    movs = [dict(json.loads(r["datos"]), _tiene_comp=bool(r["tiene"]))
            for r in conn.execute("SELECT datos, comprobante IS NOT NULL tiene FROM yera_mov ORDER BY fecha, id")]
    if not movs:
        return {"filas": [], "resumen": {}, "carga": None}
    desde, hasta = min(m["fecha"] for m in movs), max(m["fecha"] for m in movs)
    asientos = _lineas_caja(conn, desde, hasta)
    usados = set()
    filas = []

    def buscar(cond, m):
        cands = [a for a in asientos if a["aid"] not in usados and _dias(a["fecha"], m["fecha"]) <= DIAS and cond(a)]
        cands.sort(key=lambda a: (_dias(a["fecha"], m["fecha"]), a["origen"] != ("zelle" if m["tipo"] == "zelle" else a["origen"])))
        return cands[0] if cands else None

    for m in movs:
        t = m["tipo"]
        det = ""
        if t == "zelle":
            z = m.get("zelle") or 0
            a = buscar(lambda a: any(l["imp"] > 0 and abs(l["imp"] - z) < 0.01 and l["moneda"] == "USD" for l in a["lineas"]), m)
            quien = m.get("quien") or m.get("banco")
            texto, importe, moneda = f"Compré Zelle{(' · ' + quien) if quien else ''}{' (a mano, sin captura)' if m.get('manual') else ''}", z, "USD"
            if a:
                pc, pu = m.get("pago_cup") or 0, m.get("pago_usd") or 0
                # la contadora puede anotar el pago solo, o el pago más la ganancia del Yera
                ok_cup = (not pc and not _gan(m, "CUP")) or _tiene_alguno(a, "CUP", [-pc, -(pc + _gan(m, "CUP"))])
                ok_usd = (not pu and not _gan(m, "USD")) or _tiene_alguno(a, "USD", [-pu, -(pu + _gan(m, "USD"))])
                if ok_cup and ok_usd:
                    estado = "cuadra"
                else:
                    estado = "no_coincide"
                    anot = ", ".join(f"{abs(l['imp']):,.2f} {l['moneda']}" for l in a["lineas"] if l["imp"] < 0)
                    pago = " y ".join(x for x in (f"{pu:,.2f} USD" if pu else "", f"{pc:,.2f} CUP" if pc else "") if x)
                    det = f"El Yera pagó {pago}; la contadora anotó {anot or 'otro pago'}."
        else:
            if t == "cambio":
                cup, usd = m.get("cup") or 0, m.get("usd") or 0
                if m.get("dir") == "usd_cup":   # dio USD y recibió CUP
                    a = buscar(lambda a: _tiene_alguno(a, "USD", [-usd, -(usd + _gan(m, "USD"))])
                               and _tiene_alguno(a, "CUP", [cup, cup - _gan(m, "CUP")]), m)
                    texto, importe, moneda = "Cambié USD a CUP", usd, "USD"
                    det = f"{usd:,.2f} USD → {cup:,.0f} CUP"
                else:
                    a = buscar(lambda a: _tiene_alguno(a, "CUP", [-cup, -(cup + _gan(m, "CUP"))])
                               and _tiene_alguno(a, "USD", [usd, usd - _gan(m, "USD")]), m)
                    texto, importe, moneda = "Cambié CUP a USD", usd, "USD"
                    det = f"{cup:,.0f} CUP → {usd:,.2f} USD"
            else:
                imp, mon = m.get("importe") or 0, m.get("moneda") or "CUP"
                signo = 1 if t == "recibi" else -1
                a = buscar(lambda a: _tiene_alguno(a, mon, [signo * imp, signo * (imp + _gan(m, mon))]), m)
                texto = {"recibi": f"Recibí de {m.get('de') or '—'}", "pague": f"Pagué a {m.get('a') or '—'}",
                         "entregue": "Le entregué a Gabriel"}[t]
                importe, moneda = imp, mon
                det = m.get("concepto") or m.get("nota") or ""
            estado = "cuadra" if a else None
        if not a:
            # ¿hay algo parecido el mismo día (importe distinto)?
            mon_b = moneda
            parecido = [x for x in asientos if x["aid"] not in usados and _dias(x["fecha"], m["fecha"]) <= 1
                        and any(l["moneda"] == mon_b and importe and abs(abs(l["imp"]) - importe) / importe < 0.15 for l in x["lineas"])
                        and (t != "zelle" or x["origen"] == "zelle")]
            if parecido:
                a = parecido[0]
                estado = "no_coincide"
                otro = next(abs(l["imp"]) for l in a["lineas"] if l["moneda"] == mon_b and abs(abs(l["imp"]) - importe) / importe < 0.15)
                det = f"El Yera dice {importe:,.2f} {moneda}; la contadora anotó {otro:,.2f} {moneda}."
            else:
                estado = "falta_anotar"
        if a:
            usados.add(a["aid"])
        if m.get("ganancia"):
            g = f"El Yera cobró {m['gan_pct']} %: {m['ganancia']:,.2f} {m['gan_moneda']}."
            det = f"{det} {g}".strip() if det else g
        filas.append({"id": m["id"], "fecha": m["fecha"], "tipo": t, "texto": texto, "importe": r2(importe), "moneda": moneda, "estado": estado,
                      "detalle": det, "asiento": a, "confirmacion": m.get("confirmacion"), "comprobante": m["_tiene_comp"]})
    # Zelle anotados en la contabilidad que el Yera no tiene
    for a in asientos:
        if a["aid"] in usados or a["origen"] != "zelle" or not (desde <= a["fecha"] <= hasta):
            continue
        z = sum(l["imp"] for l in a["lineas"] if l["imp"] > 0 and l["moneda"] == "USD")
        filas.append({"id": None, "fecha": a["fecha"], "tipo": "zelle", "texto": a["concepto"] or "Compra de Zelle", "importe": r2(z), "moneda": "USD",
                      "estado": "falta_en_yera", "detalle": "Está en la contabilidad y el Yera no tiene su captura.", "asiento": a,
                      "confirmacion": None, "comprobante": False})
    filas.sort(key=lambda f: (f["fecha"], f["tipo"]))
    resumen = {k: sum(1 for f in filas if f["estado"] == k) for k in ("cuadra", "no_coincide", "falta_anotar", "falta_en_yera")}
    ganancias = {"USD": r2(sum(_gan(m, "USD") for m in movs)), "CUP": r2(sum(_gan(m, "CUP") for m in movs))}
    carga = conn.execute("SELECT * FROM yera_carga ORDER BY id DESC LIMIT 1").fetchone()
    return {"filas": filas, "resumen": resumen, "carga": dict(carga) if carga else None, "desde": desde, "hasta": hasta, "ganancias": ganancias}


def comprobante(conn, mid):
    asegurar_tabla(conn)
    r = conn.execute("SELECT comprobante, comprobante_tipo FROM yera_mov WHERE id = ?", (mid,)).fetchone()
    return (r["comprobante"], r["comprobante_tipo"]) if r and r["comprobante"] else (None, None)
