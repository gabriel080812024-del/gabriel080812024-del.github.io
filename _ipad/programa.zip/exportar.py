"""Exporta informes a Excel."""
import io
import re

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

AZUL = "1F2328"
NARANJA = "C2700A"


def _valor(v, fmt):
    if isinstance(v, tuple):
        fmt, v = v
    if v is None or v == "":
        return None, None
    if fmt == "p":
        return v, '0.0%;[Red]-0.0%'
    if fmt == "r":
        return v, '0.00"x"'
    if fmt == "d":
        return v, '0 "días"'
    if fmt == "e":
        return v, '0'
    if fmt in ("n",) and isinstance(v, (int, float)):
        return v, '#,##0.00;[Red](#,##0.00);"–"'
    return v, None


def a_excel(informes, empresa):
    wb = Workbook()
    wb.remove(wb.active)
    usados = set()
    for inf in informes:
        nombre = re.sub(r"[\[\]\*\?/\\:]", "", inf.titulo)[:28] or "Informe"
        base, i = nombre, 2
        while nombre in usados:
            nombre = f"{base[:25]} {i}"
            i += 1
        usados.add(nombre)
        ws = wb.create_sheet(nombre)
        ws["A1"] = empresa
        ws["A1"].font = Font(bold=True, size=14, color=NARANJA)
        ws["A2"] = inf.titulo
        ws["A2"].font = Font(bold=True, size=12)
        ws["A3"] = inf.subtitulo
        ws["A3"].font = Font(italic=True, color="666666")
        fila = 5
        enc = ["Concepto"] + inf.columnas
        for j, t in enumerate(enc, 1):
            c = ws.cell(fila, j, t)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=AZUL)
            c.alignment = Alignment(horizontal="center", wrap_text=True)
        fila += 1
        for f in inf.filas:
            c = ws.cell(fila, 1, ("    " * f["nivel"]) + f["etiqueta"])
            negrita = f["estilo"] in ("seccion", "subseccion", "grupo", "total", "resultado", "gran_total")
            c.font = Font(bold=negrita, italic=f["estilo"] == "pct",
                          color=NARANJA if f["estilo"] == "seccion" else ("6B7280" if f["estilo"] == "pct" else "000000"))
            for j, v in enumerate(f["valores"], 2):
                fmt = f.get("fmt") or (inf.formatos[j - 2] if j - 2 < len(inf.formatos) else "n")
                val, nf = _valor(v, fmt)
                cel = ws.cell(fila, j, val)
                if nf:
                    cel.number_format = nf
                cel.font = Font(bold=negrita, italic=f["estilo"] == "pct")
            if f["estilo"] in ("total", "resultado", "gran_total"):
                for j in range(1, len(enc) + 1):
                    ws.cell(fila, j).border = Border(top=Side(style="thin"))
                    if f["estilo"] != "total":
                        ws.cell(fila, j).fill = PatternFill("solid", fgColor="F3F4F6")
            fila += 1
        if inf.nota:
            ws.cell(fila + 1, 1, inf.nota).font = Font(italic=True, color="666666")
        ws.column_dimensions["A"].width = 52
        for j in range(2, len(enc) + 1):
            ws.column_dimensions[get_column_letter(j)].width = 50 if inf.formatos[j - 2:j - 1] == ["t"] and j > 2 else 16
        ws.freeze_panes = "B6"
    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return out


def estado_cuenta_excel(ec, nombre, lado, empresa):
    """Estado de cuenta con el mismo formato de la hoja de Gabriel: facturas a la izquierda, pagos a la derecha."""
    from datetime import datetime
    wb = Workbook()
    ws = wb.active
    ws.title = nombre[:28] or "Estado de cuenta"
    verde = PatternFill("solid", fgColor="D8E4BC")
    naranja = PatternFill("solid", fgColor="F8CBAD")
    fina = Side(style="thin", color="999999")
    borde = Border(left=fina, right=fina, top=fina, bottom=fina)
    num = '#,##0.00;[Red]-#,##0.00;""'
    ws.merge_cells("A1:I1")
    ws["A1"] = nombre
    ws["A1"].font = Font(bold=True, size=14)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws["A2"] = f"{empresa} · {'Cuentas por cobrar' if lado == 'cobrar' else 'Cuentas por pagar'} · al {datetime.now():%d/%m/%Y}"
    ws["A2"].font = Font(italic=True, color="666666")
    enc_izq = ["Fecha", "Factura", "Importe USD", "Importe CUP"]
    enc_der = ["Fecha", "Nombre", "Monto USD", "Monto CUP"]
    for j, t in enumerate(enc_izq, 1):
        c = ws.cell(4, j, t)
        c.fill, c.border, c.font = verde, borde, Font(bold=True)
    for j, t in enumerate(enc_der, 6):
        c = ws.cell(4, j, t)
        c.fill, c.border, c.font = verde, borde, Font(bold=True)

    def fecha(f):
        return datetime.strptime(f, "%Y-%m-%d")

    fila = 5
    filas_izq = []
    if ec["desde"]:
        filas_izq.append((ec["desde"], "Saldo anterior", ec["tot"]["USD"]["anterior"], ec["tot"]["CUP"]["anterior"]))
    for x in ec["cargos"]:
        filas_izq.append((x["fecha"], x["texto"], x["importe"] if x["moneda"] == "USD" else None,
                          x["importe"] if x["moneda"] == "CUP" else None))
    filas_der = [(x["fecha"], x["nota"] or x["texto"], x["importe"] if x["moneda"] == "USD" else None,
                  x["importe"] if x["moneda"] == "CUP" else None) for x in ec["pagos"]]
    alto = max(len(filas_izq), len(filas_der), 1)
    for i in range(alto):
        for col0, datos in ((1, filas_izq), (6, filas_der)):
            vals = datos[i] if i < len(datos) else (None, None, None, None)
            for k, v in enumerate(vals):
                c = ws.cell(fila + i, col0 + k, fecha(v) if k == 0 and v else v)
                c.border = borde
                if k == 0 and v:
                    c.number_format = "d/m/yy"
                if k >= 2:
                    c.number_format = num
    fila += alto
    t = ec["tot"]
    total = [("Total", t["USD"]["total_cargos"], t["CUP"]["total_cargos"])]
    for etq, usd, cup in total:
        ws.cell(fila, 1, etq).font = Font(bold=True)
        for col, v in ((3, usd), (4, cup)):
            c = ws.cell(fila, col, v)
            c.number_format, c.font = num, Font(bold=True)
        for col, v in ((8, t["USD"]["pagos"]), (9, t["CUP"]["pagos"])):
            c = ws.cell(fila, col, v)
            c.number_format, c.font = num, Font(bold=True)
        ws.cell(fila, 7, "Total").font = Font(bold=True)
        for j in list(range(1, 5)) + list(range(6, 10)):
            ws.cell(fila, j).border = borde
    fila += 1
    ws.cell(fila, 1, "Pendiente").font = Font(bold=True)
    for col, v in ((3, t["USD"]["pendiente"]), (4, t["CUP"]["pendiente"])):
        c = ws.cell(fila, col, v)
        c.number_format, c.font = num, Font(bold=True)
    for j in range(1, 5):
        ws.cell(fila, j).fill = naranja
        ws.cell(fila, j).border = borde
    for col, w in zip("ABCDEFGHI", (11, 34, 15, 15, 3, 11, 34, 15, 15)):
        ws.column_dimensions[col].width = w
    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return out
