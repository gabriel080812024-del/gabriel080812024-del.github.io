// Avisa al programa que la ventana sigue abierta (si se cierra, el programa se apaga solo)
function latido() { fetch('/api/latido', {method: 'POST', keepalive: true}).catch(() => {}); }
latido(); setInterval(latido, 5000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) latido(); });

// Mi Contabilidad — ayudas de los formularios
const BASE = document.body.dataset.base || 'USD';
// cerrar los menús desplegables al tocar o hacer clic fuera (en el iPad Safari no manda "click" al tocar zonas vacías)
function cerrarMenus(e) {
  document.querySelectorAll('details.desplegable[open]').forEach(d => { if (!d.contains(e.target)) d.removeAttribute('open'); });
}
document.addEventListener('click', cerrarMenus);
document.addEventListener('pointerdown', cerrarMenus);

// evitar que un doble toque en "Guardar" anote dos veces
document.addEventListener('submit', e => {
  const f = e.target;
  if (!f || f.tagName !== 'FORM' || (f.getAttribute('method') || 'get').toLowerCase() !== 'post') return;
  if (f.querySelector('input[type=file]')) return;  // restaurar una copia: tiene su propio aviso
  if (f.dataset.enviando) { e.preventDefault(); return; }
  if (e.defaultPrevented) return;  // por ejemplo, dijo "Cancelar" en una confirmación
  f.dataset.enviando = '1';
  const botones = [...f.querySelectorAll('button:not([type=button]), input[type=submit]')];
  setTimeout(() => botones.forEach(b => {  // después de que salga el envío, para no perder el botón pulsado
    b.disabled = true;
    if (b.tagName === 'BUTTON' && b.classList.contains('primario')) { b.dataset.textoAntes = b.textContent; b.textContent = 'Guardando…'; }
  }), 0);
  setTimeout(() => desbloquear(f), 5000);  // por si la pantalla no cambia (por ejemplo, al descargar un archivo)
});
function desbloquear(f) {
  delete f.dataset.enviando;
  f.querySelectorAll('button, input[type=submit]').forEach(b => {
    b.disabled = false;
    if (b.dataset.textoAntes) { b.textContent = b.dataset.textoAntes; delete b.dataset.textoAntes; }
  });
}
window.addEventListener('pageshow', () => document.querySelectorAll('form[data-enviando]').forEach(desbloquear));

function numero(t) {
  t = (t || '').replace(/\s|\$/g, '');
  if (!t) return 0;
  if (t.includes(',') && t.includes('.')) t = t.lastIndexOf('.') > t.lastIndexOf(',') ? t.replace(/,/g, '') : t.replace(/\./g, '').replace(',', '.');
  else if (t.includes(',')) { const p = t.split(','); t = (p.length === 2 && p[1].length <= 2) ? t.replace(',', '.') : t.replace(/,/g, ''); }
  const v = parseFloat(t); return isNaN(v) ? 0 : v;
}
function dinero(v) { return v.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}); }

// --- selector de período
function cambiarModo() {
  document.querySelectorAll('form.periodo').forEach(f => {
    const modo = f.querySelector('[name=modo]')?.value;
    const vista = f.querySelector('[name=vista]')?.value;
    if (!modo) return;
    f.querySelectorAll('[class*="m-"]').forEach(e => {
      const clases = [...e.classList].filter(c => c.startsWith('m-'));
      let ver = clases.some(c => c === 'm-' + modo);
      if (e.classList.contains('m-anio-only')) ver = modo === 'anio';
      if (e.classList.contains('m-anio') && modo === 'anio') ver = true;
      e.style.display = ver ? '' : 'none';
    });
    f.querySelectorAll('.v-comparar, .v-evolucion').forEach(e => {
      let ver = e.classList.contains('v-' + vista);
      if (e.classList.contains('m-anio-only')) ver = ver && modo === 'anio';
      e.style.display = ver ? '' : 'none';
    });
  });
}
cambiarModo();

// --- tasa del día
async function traerTasa(fecha, campo, forzar) {
  if (!campo || (campo.value && !forzar && !campo.dataset.auto)) return;
  try {
    const r = await fetch('/api/tasa?fecha=' + encodeURIComponent(fecha));
    const j = await r.json();
    if (j.tasa) { campo.value = j.tasa; campo.dataset.auto = '1'; campo.dispatchEvent(new Event('input')); }
  } catch (e) {}
}

// --- formularios de registro rápido
const reg = document.getElementById('registro');
if (reg) {
  const fecha = reg.querySelector('[name=fecha]');
  const tasa = document.getElementById('tasa');
  const caja = document.getElementById('caja');
  const moneda = document.getElementById('moneda');
  const destino = document.getElementById('destino');
  const importe = reg.querySelector('[name=importe]');
  const equivale = document.getElementById('equivale');
  tasa.addEventListener('input', e => { if (e.isTrusted) delete tasa.dataset.auto; });
  function mon() {
    if (caja && caja.value === 'apertura') return document.getElementById('moneda_deuda')?.value;
    return caja ? caja.selectedOptions[0]?.dataset.moneda : moneda?.value;
  }
  function actualizar() {
    const m = mon();
    reg.querySelectorAll('.moneda-etq').forEach(e => e.textContent = m ? '(' + m + ')' : '');
    if (destino) reg.querySelectorAll('.moneda-dest').forEach(e => e.textContent = '(' + destino.selectedOptions[0]?.dataset.moneda + ')');
    const v = numero(importe.value), t = numero(tasa.value);
    if (equivale) {
      if (v && t && m) {
        const otra = m === 'CUP' ? 'USD' : 'CUP';
        const conv = m === 'CUP' ? v / t : v * t;
        equivale.textContent = `${dinero(v)} ${m} = ${dinero(conv)} ${otra}`;
      } else equivale.textContent = '';
    }
  }
  [caja, moneda, destino, importe, tasa].forEach(e => e && e.addEventListener('input', actualizar));
  const monDeuda = document.getElementById('moneda_deuda');
  if (monDeuda) {
    monDeuda.value = monDeuda.dataset.sel || mon() || 'USD';
    let tocado = !!monDeuda.dataset.sel;
    monDeuda.addEventListener('change', () => { tocado = true; });
    caja && caja.addEventListener('change', () => { if (!tocado && caja.value !== 'apertura') monDeuda.value = mon(); });
    monDeuda.addEventListener('change', actualizar);
  }
  [caja, moneda, destino].forEach(e => e && e.addEventListener('change', actualizar));
  fecha.addEventListener('change', () => traerTasa(fecha.value, tasa, true));
  if (!tasa.value) traerTasa(fecha.value, tasa, true);
  actualizar();

  // Ingreso / Gasto con alguien que tiene deudas: avisar y ofrecer pasar a Cobrar/Pagar deuda
  const aviso = document.getElementById('aviso-deuda');
  if (aviso) {
    const nombre = reg.querySelector('[name=tercero]');
    const destino = document.getElementById('pasar-deuda').dataset.destino;
    async function revisarDeuda() {
      aviso.hidden = true;
      if (!nombre.value.trim()) return;
      try {
        const r = await fetch(`/api/deuda?lado=${destino === 'cobro' ? 'cobrar' : 'pagar'}&tercero=${encodeURIComponent(nombre.value)}`);
        const d = await r.json();
        const partes = Object.entries(d).map(([m, v]) => `${m} ${dinero(v)}`);
        if (!partes.length) return;
        document.getElementById('aviso-deuda-texto').textContent =
          destino === 'cobro' ? `${nombre.value.trim()} te debe ${partes.join(' y ')}.` : `Le debes a ${nombre.value.trim()} ${partes.join(' y ')}.`;
        aviso.hidden = false;
      } catch (e) {}
    }
    nombre.addEventListener('change', revisarDeuda);
    nombre.addEventListener('blur', revisarDeuda);
    document.getElementById('pasar-deuda').addEventListener('click', () => {
      const q = new URLSearchParams();
      ['fecha', 'tercero', 'caja', 'importe', 'tasa', 'referencia'].forEach(k => { const e = reg.querySelector(`[name=${k}]`); if (e && e.value) q.set(k, e.value); });
      const concepto = reg.querySelector('[name=concepto]');
      if (concepto && concepto.value && !q.get('referencia')) q.set('referencia', concepto.value);
      location.href = `/registrar/${destino}?` + q.toString();
    });
    if (nombre.value) revisarDeuda();
  }

  const doc = document.getElementById('documento');
  const tercero = reg.querySelector('[name=tercero]');
  if (doc) {
    const tipo = reg.dataset.tipo;
    async function pendientes() {
      const sel = doc.dataset.sel; doc.dataset.sel = '';
      const actual = sel || doc.value;
      doc.querySelectorAll('option').forEach(o => { if (o.value !== '' && o.value !== 'anticipo') o.remove(); });
      const ayuda = document.getElementById('ayuda-doc');
      if (!tercero.value.trim()) { ayuda.textContent = 'Escribe primero el nombre para ver sus facturas pendientes.'; return; }
      const r = await fetch(`/api/pendientes?tipo=${tipo}&tercero=${encodeURIComponent(tercero.value)}`);
      const lista = await r.json();
      lista.forEach(d => { const o = new Option(d.texto, d.id); o.dataset.pendiente = d.pendiente; o.dataset.moneda = d.moneda; doc.add(o); });
      ayuda.textContent = lista.length ? `Tiene ${lista.length} deuda(s) pendiente(s). Si lo dejas en Automático, el dinero se aplica a sus facturas más antiguas.` : "No tiene deudas pendientes; se anotará como anticipo o pago a cuenta.";
      if (actual) {
        if (![...doc.options].some(o => o.value === String(actual))) doc.add(new Option('La misma deuda que tenía este movimiento', actual));
        doc.value = actual;
      }
    }
    tercero.addEventListener('change', pendientes);
    tercero.addEventListener('blur', pendientes);
    doc.addEventListener('change', () => {
      const o = doc.selectedOptions[0];
      if (o && o.dataset.pendiente && !importe.value) {
        // propone el importe si la caja está en la misma moneda
        if (mon() === o.dataset.moneda) { importe.value = o.dataset.pendiente; actualizar(); }
      }
    });
    if (tercero.value) pendientes();
  }
}

// --- asiento manual
function agregarLinea(datos) {
  const tpl = document.getElementById('plantilla-linea');
  const tr = tpl.content.firstElementChild.cloneNode(true);
  document.getElementById('filas').appendChild(tr);
  const cuenta = tr.querySelector('.cuenta'), moneda = tr.querySelector('.moneda');
  if (datos) {
    cuenta.value = datos.cuenta || ''; moneda.value = datos.moneda || BASE;
    tr.querySelector('[name="tercero[]"]').value = datos.tercero || '';
    tr.querySelector('[name="debe[]"]').value = datos.debe || '';
    tr.querySelector('[name="haber[]"]').value = datos.haber || '';
    tr.querySelector('[name="descripcion[]"]').value = datos.descripcion || '';
  }
  cuenta.addEventListener('change', () => {
    const o = cuenta.selectedOptions[0];
    if (o.dataset.moneda) moneda.value = o.dataset.moneda;
    tr.querySelector('[name="tercero[]"]').required = o.dataset.tercero === '1';
    sumar();
  });
  tr.querySelectorAll('input, select').forEach(e => e.addEventListener('input', sumar));
}
function sumar() {
  const t = numero(document.getElementById('tasa')?.value);
  let d = 0, h = 0, falta = false;
  document.querySelectorAll('#filas tr').forEach(tr => {
    const m = tr.querySelector('.moneda').value;
    const conv = v => { if (m === BASE) return v; if (!t) { if (v) falta = true; return 0; } return m === 'CUP' ? v / t : v * t; };
    d += conv(numero(tr.querySelector('[name="debe[]"]').value));
    h += conv(numero(tr.querySelector('[name="haber[]"]').value));
  });
  document.getElementById('t-debe').textContent = dinero(d);
  document.getElementById('t-haber').textContent = dinero(h);
  const dif = document.getElementById('t-dif');
  if (falta) dif.innerHTML = '<span class="rojo">Falta la tasa</span>';
  else if (Math.abs(d - h) < 0.01 && d > 0) dif.innerHTML = '<span class="verde">✓ Cuadra</span>';
  else dif.innerHTML = d || h ? `<span class="rojo">Diferencia: ${dinero(Math.abs(d - h))} ${BASE}</span>` : '';
}
function iniciarAsiento(previas) {
  const f = document.getElementById('asiento');
  const fecha = f.querySelector('[name=fecha]'), tasa = document.getElementById('tasa');
  if (previas && previas.length) previas.forEach(p => agregarLinea(p)); else { agregarLinea(); agregarLinea(); }
  tasa.addEventListener('input', sumar);
  fecha.addEventListener('change', () => traerTasa(fecha.value, tasa, true));
  if (!tasa.value) traerTasa(fecha.value, tasa, true);
  sumar();
}

// Botón "Atrás" (la ventana del programa no tiene la flecha del navegador)
function volverAtras() {
  const boton = document.querySelector('.atras');
  const vieneDeAqui = document.referrer && document.referrer.startsWith(location.origin) && document.referrer !== location.href;
  if (vieneDeAqui && history.length > 1) history.back();
  else location.href = (boton && boton.dataset.padre) || '/';
}
// Atajos de teclado: Cmd+[ o Alt+← vuelven atrás
document.addEventListener('keydown', e => {
  const enCampo = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
  if (((e.metaKey || e.ctrlKey) && e.key === '[') || (e.altKey && e.key === 'ArrowLeft' && !enCampo)) {
    if (document.querySelector('.atras')) { e.preventDefault(); volverAtras(); }
  }
});

/* Buscador de todo el programa (⌘K, Ctrl+K o /) */
(function () {
  const dlg = document.getElementById("buscador");
  if (!dlg) return;
  const q = document.getElementById("bus-q"), res = document.getElementById("bus-res");
  let tmr = null, pedido = 0, sel = -1;
  const items = () => [...res.querySelectorAll(".bus-item")];
  function marcar(i) {
    const l = items(); if (!l.length) { sel = -1; return; }
    sel = (i + l.length) % l.length;
    l.forEach((a, k) => a.classList.toggle("sel", k === sel));
    l[sel].scrollIntoView({ block: "nearest" });
  }
  async function buscar() {
    const n = ++pedido;
    try {
      const r = await fetch("/buscar?q=" + encodeURIComponent(q.value), { headers: { "X-Requested-With": "buscador" } });
      if (n !== pedido) return;
      res.innerHTML = await r.text(); marcar(0);
    } catch (e) { if (n === pedido) res.innerHTML = '<p class="bus-vacio">No se pudo buscar. Vuelve a intentarlo.</p>'; }
  }
  window.abrirBuscador = function () {
    if (dlg.open) return;
    document.querySelectorAll("details[open]").forEach((d) => d.removeAttribute("open"));
    dlg.showModal(); q.select(); buscar();
  };
  window.cerrarBuscador = () => dlg.close();
  q.addEventListener("input", () => { clearTimeout(tmr); tmr = setTimeout(buscar, 140); });
  q.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); marcar(sel + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); marcar(sel - 1); }
    else if (e.key === "Enter") { e.preventDefault(); const a = items()[sel]; if (a) a.click(); }
  });
  res.addEventListener("mousemove", (e) => { const a = e.target.closest(".bus-item"); if (a) marcar(items().indexOf(a)); });
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
  document.addEventListener("keydown", (e) => {
    const enCampo = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
    if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) { e.preventDefault(); dlg.open ? dlg.close() : abrirBuscador(); }
    else if (e.key === "/" && !enCampo && !dlg.open) { e.preventDefault(); abrirBuscador(); }
  });
})();
