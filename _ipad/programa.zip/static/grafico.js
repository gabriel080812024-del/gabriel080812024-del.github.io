/* Gráfico de partidas (como en TIKR): en los estados financieros, tocas una o varias filas y se dibujan arriba.
   Se puede elegir barras o líneas, valores o crecimiento %, ver mín / mediana / máx y exportar
   (imagen para WhatsApp, PDF o Excel con su gráfico). Todo se dibuja aquí mismo: funciona sin internet. */
(function () {
  "use strict";
  const tablas = [...document.querySelectorAll(".term-tabla")].filter((t) => t.querySelector("tr.graficable"));
  if (!tablas.length) return;
  document.body.classList.add("con-grafico");

  const COLORES = ["#0f766e", "#e8890c", "#2f6fbf", "#7a5bd0", "#c2416b", "#5b8c1a"];
  const MAX = 6;
  const pagina = (new URLSearchParams(location.search).get("tab") || location.pathname);
  const CLAVE = "mc_graf:" + pagina;
  const empresa = (document.querySelector(".term-emp h1") || {}).textContent || document.title.split("·")[0].trim();
  const elegidas = [];  // [{tr, etiqueta, datos, color}]
  let tipo = "barras", modo = "valores", mmm = false, tituloTocado = false;
  try { const p = JSON.parse(sessionStorage.getItem("mc_graf_pref") || "{}"); tipo = p.tipo || tipo; modo = p.modo || modo; mmm = !!p.mmm; } catch (e) {}

  // ------------------------------------------------------------ el panel
  const panel = document.createElement("section");
  panel.className = "graf-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="graf-cab">
      <input class="graf-titulo" aria-label="Título del gráfico" maxlength="90">
      <div class="graf-exp">
        <button type="button" data-exp="png" class="secundario">Imagen</button>
        <button type="button" data-exp="pdf" class="secundario">PDF</button>
        <button type="button" data-exp="xlsx" class="secundario">Excel</button>
        <button type="button" class="secundario graf-quitar" title="Quitar todas las filas del gráfico" aria-label="Cerrar el gráfico">✕</button>
      </div>
    </div>
    <div class="graf-ctrl">
      <span class="seg"><a href="#" data-tipo="barras">Barras</a><a href="#" data-tipo="lineas">Líneas</a></span>
      <span class="seg"><a href="#" data-modo="valores">Valores</a><a href="#" data-modo="crec">Crecimiento %</a></span>
      <label class="graf-mmm"><input type="checkbox"> Mín / mediana / máx</label>
      <span class="graf-ley"></span>
    </div>
    <div class="graf-lienzo"></div>
    <p class="graf-nota">Toca más filas para compararlas (hasta ${MAX}). Toca otra vez para quitarlas.</p>`;
  tablas[0].parentNode.insertBefore(panel, tablas[0]);
  const lienzo = panel.querySelector(".graf-lienzo"), titulo = panel.querySelector(".graf-titulo");
  const flotante = document.createElement("button");
  flotante.type = "button"; flotante.className = "graf-flotante"; flotante.hidden = true;
  flotante.onclick = () => panel.scrollIntoView({ behavior: "smooth", block: "start" });
  document.body.appendChild(flotante);

  const columnas = (tabla) => [...tabla.querySelectorAll("thead th")].slice(1).map((th) => th.textContent.trim());
  const COLS = columnas(tablas[0]);
  const etiquetaDe = (tr) => tr.querySelector("td.etq").textContent.replace(/\?\s*$/, "").trim();

  // ------------------------------------------------------------ elegir filas
  function alternar(tr, silencioso) {
    const i = elegidas.findIndex((x) => x.tr === tr);
    if (i >= 0) {
      elegidas.splice(i, 1);
      tr.classList.remove("g-sel"); tr.style.removeProperty("--g-color");
    } else {
      if (elegidas.length >= MAX) { if (!silencioso) avisar(`Se pueden comparar hasta ${MAX} filas a la vez.`); return; }
      const usados = elegidas.map((x) => x.color);
      const color = COLORES.find((c) => !usados.includes(c)) || COLORES[0];
      elegidas.push({ tr, etiqueta: etiquetaDe(tr), datos: JSON.parse(tr.dataset.g), color });
      tr.classList.add("g-sel"); tr.style.setProperty("--g-color", color);
    }
    try { sessionStorage.setItem(CLAVE, JSON.stringify(elegidas.map((x) => x.etiqueta))); } catch (e) {}
    dibujar();
  }
  tablas.forEach((t) => t.addEventListener("click", (e) => {
    const tr = e.target.closest("tr.graficable");
    if (!tr || (e.target.closest("a") && !e.target.closest(".g-ck"))) return;  // el nombre de la cuenta sigue llevando a sus movimientos
    e.preventDefault();
    alternar(tr);
  }));
  let tAviso = null;
  function avisar(t) {
    flotante.hidden = false; flotante.textContent = t; clearTimeout(tAviso);
    tAviso = setTimeout(actualizarFlotante, 2500);
  }

  // ------------------------------------------------------------ cálculo
  const UNIDAD = { n: "dinero", p: "%", r: "veces", d: "días", e: "cantidad" };
  function serie(x) {
    const v = x.datos.v;
    if (modo === "valores") return v.map((y) => (y === null ? null : x.datos.f === "p" ? y * 100 : y));
    return v.map((y, k) => (k === 0 || y === null || v[k - 1] === null || Math.abs(v[k - 1]) < 0.005) ? null : (y - v[k - 1]) / Math.abs(v[k - 1]) * 100);
  }
  function fmtNum(y, f, corto) {
    if (y === null || y === undefined || isNaN(y)) return "–";
    if (f === "%" || f === "p") return y.toFixed(1) + " %";
    if (f === "r") return y.toFixed(2);
    if (f === "d") return Math.round(y) + " días";
    const a = Math.abs(y);
    if (corto && a >= 1e6) return (y / 1e6).toFixed(1) + "M";
    if (corto && a >= 1e3) return (y / 1e3).toFixed(a >= 1e5 ? 0 : 1) + "k";
    const s = a.toLocaleString("en-US", { minimumFractionDigits: corto ? 0 : 2, maximumFractionDigits: corto ? 0 : 2 });
    return y < 0 ? "(" + s + ")" : s;
  }
  function escalaBonita(mn, mx) {
    if (mn === mx) { mx = mn + 1; }
    const paso0 = (mx - mn) / 4, p10 = Math.pow(10, Math.floor(Math.log10(paso0)));
    const paso = [1, 2, 2.5, 5, 10].map((m) => m * p10).find((p) => p >= paso0) || paso0;
    return { mn: Math.floor(mn / paso) * paso, mx: Math.ceil(mx / paso) * paso, paso };
  }

  // ------------------------------------------------------------ dibujo (SVG con colores fijos: sirve para exportar)
  function svg() {
    const W = 880, H = 330, X0 = 70, Y0 = 22, Y1 = 280;
    const izq = [], der = [];
    const fBase = modo === "crec" ? "%" : (elegidas[0] && elegidas[0].datos.f);
    elegidas.forEach((x) => ((modo === "crec" || x.datos.f === fBase) ? izq : der).push(x));
    const fDer = der[0] && der[0].datos.f;
    const X1 = der.length ? W - 70 : W - 20;
    const n = COLS.length, ancho = (X1 - X0) / n;
    const valsI = izq.flatMap(serie).filter((y) => y !== null);
    const eI = escalaBonita(Math.min(0, ...valsI), Math.max(0, ...valsI));
    const yI = (v) => Y1 - (v - eI.mn) / (eI.mx - eI.mn) * (Y1 - Y0);
    const t = [];
    const txt = (x, y, s, o = {}) => `<text x="${x}" y="${y}" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="${o.fs || 12}" fill="${o.c || "#5b766f"}" text-anchor="${o.a || "middle"}" font-weight="${o.w || 400}">${String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;")}</text>`;
    for (let v = eI.mn; v <= eI.mx + eI.paso / 2; v += eI.paso) {
      t.push(`<line x1="${X0}" x2="${X1}" y1="${yI(v)}" y2="${yI(v)}" stroke="#e3ece9" stroke-width="1"/>`);
      t.push(txt(X0 - 8, yI(v) + 4, fmtNum(v, modo === "crec" ? "%" : fBase, true), { a: "end", fs: 11 }));
    }
    t.push(`<line x1="${X0}" x2="${X1}" y1="${yI(0)}" y2="${yI(0)}" stroke="#9fb5ae" stroke-width="1.2"/>`);
    const cada = Math.ceil(n / 12);
    COLS.forEach((c, k) => { if (k % cada === 0 || k === n - 1) t.push(txt(X0 + ancho * k + ancho / 2, Y1 + 20, c, { fs: 11.5 })); });
    const cx = (k) => X0 + ancho * k + ancho / 2;
    if (tipo === "barras") {
      const bw = Math.max(3, Math.min(34, (ancho - 10) / Math.max(1, izq.length)));
      izq.forEach((x, j) => serie(x).forEach((v, k) => {
        if (v === null) return;
        const xx = cx(k) - bw * izq.length / 2 + bw * j, a = yI(Math.max(v, 0)), b = yI(Math.min(v, 0));
        t.push(`<rect x="${xx + 1}" y="${a}" width="${bw - 2}" height="${Math.max(1, b - a)}" rx="3" fill="${x.color}"><title>${x.etiqueta} · ${COLS[k]}: ${fmtNum(v, modo === "crec" ? "%" : x.datos.f)}</title></rect>`);
        if (izq.length === 1 && n <= 12) t.push(txt(xx + bw / 2, (v >= 0 ? a - 6 : b + 14), fmtNum(v, modo === "crec" ? "%" : x.datos.f, true), { fs: 11, c: "#16302b", w: 600 }));
      }));
    } else {
      izq.forEach((x) => linea(t, serie(x), yI, x, cx, false, n));
    }
    if (der.length) {
      const valsD = der.flatMap(serie).filter((y) => y !== null);
      const eD = escalaBonita(Math.min(0, ...valsD), Math.max(0, ...valsD));
      const yD = (v) => Y1 - (v - eD.mn) / (eD.mx - eD.mn) * (Y1 - Y0);
      for (let v = eD.mn; v <= eD.mx + eD.paso / 2; v += eD.paso) t.push(txt(X1 + 8, yD(v) + 4, fmtNum(v, fDer, true), { a: "start", fs: 11 }));
      der.forEach((x) => linea(t, serie(x), yD, x, cx, true, n));
    }
    if (mmm && izq.length) {
      const v = serie(izq[0]).filter((y) => y !== null).sort((a, b) => a - b);
      if (v.length) {
        const med = v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2;
        let ultimaY = -1e9;  // las etiquetas no se montan si los valores están cerca
        [["Máx", v[v.length - 1]], ["Mediana", med], ["Mín", v[0]]].forEach(([e, val]) => {
          t.push(`<line x1="${X0}" x2="${X1}" y1="${yI(val)}" y2="${yI(val)}" stroke="#16302b" stroke-width="1" stroke-dasharray="4 4" opacity=".55"/>`);
          const ye = Math.max(yI(val) - 5, ultimaY + 14);
          ultimaY = ye;
          t.push(`<rect x="${X1 - 112}" y="${ye - 11}" width="108" height="14" fill="#ffffff" opacity=".85"/>`);
          t.push(txt(X1 - 6, ye, `${e} ${fmtNum(val, modo === "crec" ? "%" : fBase, true)}`, { a: "end", fs: 11, c: "#16302b", w: 600 }));
        });
      }
    }
    return { cuerpo: t.join(""), W, H, fBase, fDer };
  }
  function linea(t, s, y, x, cx, punteada, n) {
    const pts = s.map((v, k) => (v === null ? null : [cx(k), y(v), v, k])).filter(Boolean);
    if (!pts.length) return;
    t.push(`<polyline points="${pts.map((p) => p[0] + "," + p[1]).join(" ")}" fill="none" stroke="${x.color}" stroke-width="2.6" stroke-linejoin="round" ${punteada ? 'stroke-dasharray="7 5"' : ""}/>`);
    pts.forEach((p) => t.push(`<circle cx="${p[0]}" cy="${p[1]}" r="${n > 16 ? 2.5 : 4}" fill="#fff" stroke="${x.color}" stroke-width="2.2"><title>${x.etiqueta} · ${COLS[p[3]]}: ${fmtNum(p[2], modo === "crec" ? "%" : x.datos.f)}</title></circle>`));
  }
  function svgCompleto(paraExportar, conCabecera = true) {
    const g = svg();
    const arriba = paraExportar && conCabecera ? 46 : (paraExportar ? 6 : 0);
    const extra = paraExportar ? arriba + 24 : 0;
    let cab = "";
    if (paraExportar) {
      cab = `<rect width="${g.W}" height="${g.H + extra}" fill="#ffffff"/>`
        + (conCabecera ? `<text x="24" y="32" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="19" font-weight="700" fill="#16302b">${esc(titulo.value)}</text>`
        + `<text x="24" y="52" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" fill="#5b766f">${esc(subtitulo())}</text>` : "");
      let x = 24;
      elegidas.forEach((e) => {
        cab += `<rect x="${x}" y="${g.H + arriba - 2}" width="12" height="12" rx="3" fill="${e.color}"/>`
          + `<text x="${x + 18}" y="${g.H + arriba + 8}" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" fill="#16302b">${esc(e.etiqueta)}</text>`;
        x += 30 + e.etiqueta.length * 6.6;
      });
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${g.W} ${g.H + extra}" width="100%" role="img" aria-label="Gráfico de las filas elegidas">`
      + cab + (paraExportar ? `<g transform="translate(0,${arriba})">${g.cuerpo}</g>` : g.cuerpo) + "</svg>";
  }
  const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  function subtitulo() {
    const tab = document.querySelector(".term-tabs a.on");
    const per = document.querySelector(".term-ctrl .seg a.on");
    const base = (document.body.dataset.base || "USD");
    return [tab && tab.textContent.trim(), per && per.textContent.trim(), modo === "crec" ? "crecimiento % vs. período anterior" : "cifras en " + base].filter(Boolean).join(" · ");
  }
  function dibujar() {
    panel.hidden = !elegidas.length;
    actualizarFlotante();
    if (!elegidas.length) return;
    if (!tituloTocado) titulo.value = empresa + " · " + elegidas.map((x) => x.etiqueta).join(", ");
    lienzo.innerHTML = svgCompleto(false);
    panel.querySelector(".graf-ley").innerHTML = elegidas.map((x) =>
      `<span class="graf-chip"><i style="background:${x.color}"></i>${esc(x.etiqueta)}</span>`).join("");
    panel.querySelectorAll("[data-tipo]").forEach((a) => a.classList.toggle("on", a.dataset.tipo === tipo));
    panel.querySelectorAll("[data-modo]").forEach((a) => a.classList.toggle("on", a.dataset.modo === modo));
    panel.querySelector(".graf-mmm input").checked = mmm;
    try { sessionStorage.setItem("mc_graf_pref", JSON.stringify({ tipo, modo, mmm })); } catch (e) {}
  }
  function actualizarFlotante() {
    if (!elegidas.length) { flotante.hidden = true; return; }
    const r = panel.getBoundingClientRect();
    const fuera = r.bottom < 60 || r.top > (window.innerHeight || 800);
    flotante.hidden = !fuera;
    flotante.textContent = `↑ Ver gráfico (${elegidas.length})`;
  }
  (document.querySelector(".desplaza") || window).addEventListener("scroll", actualizarFlotante, { passive: true });

  panel.addEventListener("click", (e) => {
    const a = e.target.closest("[data-tipo],[data-modo]");
    if (a) { e.preventDefault(); if (a.dataset.tipo) tipo = a.dataset.tipo; if (a.dataset.modo) modo = a.dataset.modo; dibujar(); }
    if (e.target.closest(".graf-quitar")) { [...elegidas].forEach((x) => alternar(x.tr, true)); tituloTocado = false; }
    const b = e.target.closest("[data-exp]");
    if (b) exportar(b.dataset.exp, b);
  });
  panel.querySelector(".graf-mmm input").addEventListener("change", (e) => { mmm = e.target.checked; dibujar(); });
  titulo.addEventListener("input", () => { tituloTocado = true; });

  // ------------------------------------------------------------ exportar
  function imagenPNG(conCabecera = true) {
    return new Promise((ok, mal) => {
      const s = svgCompleto(true, conCabecera);
      const img = new Image();
      img.onload = () => {
        const esc2 = 2, w = 880, h = img.height / img.width * 880 || 400;
        const cv = document.createElement("canvas"); cv.width = w * esc2; cv.height = h * esc2;
        const cx = cv.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, cv.width, cv.height);
        cx.drawImage(img, 0, 0, cv.width, cv.height);
        ok(cv.toDataURL("image/png"));
      };
      img.onerror = () => mal(new Error("No se pudo preparar la imagen."));
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s.replace('width="100%"', 'width="880"'));
    });
  }
  async function exportar(formato, boton) {
    const antes = boton.textContent;
    boton.textContent = "Preparando…"; boton.disabled = true;
    try {
      const datos = {
        titulo: titulo.value, subtitulo: subtitulo(), columnas: COLS, tipo, modo,
        filas: elegidas.map((x) => ({ etiqueta: x.etiqueta, color: x.color, f: modo === "crec" ? "%" : x.datos.f, v: serie(x) })),
      };
      const f = document.createElement("form");
      f.method = "post"; f.action = "/estados/grafico"; f.style.display = "none";
      const campo = (n, v) => { const i = document.createElement("input"); i.type = "hidden"; i.name = n; i.value = v; f.appendChild(i); };
      campo("formato", formato);
      campo("datos", JSON.stringify(datos));
      if (formato !== "xlsx") campo("imagen", await imagenPNG(formato === "png"));
      document.body.appendChild(f);
      f.submit();
      setTimeout(() => f.remove(), 3000);
    } catch (e) {
      alert(e.message || e);
    } finally {
      setTimeout(() => { boton.textContent = antes; boton.disabled = false; }, 1500);
    }
  }

  // ------------------------------------------------------------ volver a marcar lo que estaba elegido
  try {
    const antes = JSON.parse(sessionStorage.getItem(CLAVE) || "[]");
    const filas = tablas.flatMap((t) => [...t.querySelectorAll("tr.graficable")]);
    antes.forEach((et) => { const tr = filas.find((r) => etiquetaDe(r) === et); if (tr) alternar(tr, true); });
  } catch (e) {}
  dibujar();
})();
