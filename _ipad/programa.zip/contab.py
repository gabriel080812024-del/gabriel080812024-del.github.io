"""Motor contable: asientos de partida doble en CUP/USD e informes financieros."""
import calendar
from datetime import date, datetime, timedelta

from db import get_config

MONEDAS = ("CUP", "USD")
MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto",
         "Septiembre", "Octubre", "Noviembre", "Diciembre"]
MESES_CORTOS = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
TIPOS_TERCERO = ["Proveedor", "Cliente", "Persona", "Institución", "Banco", "Empleado", "Socio", "Otro"]
TIPO_CUENTA = {"activo": "Activo", "pasivo": "Pasivo", "patrimonio": "Patrimonio",
               "ingreso": "Ingreso", "gasto": "Gasto / Costo"}
SECCIONES = {
    "activo": [("corriente", "Corriente (menos de 1 año)"), ("no_corriente", "No corriente (más de 1 año)")],
    "pasivo": [("corriente", "Corriente (menos de 1 año)"), ("no_corriente", "No corriente (más de 1 año)")],
    "patrimonio": [("patrimonio", "Patrimonio")],
    "ingreso": [("operacion", "Ingresos de operación"), ("otros", "Otros ingresos")],
    "gasto": [("costo", "Costo de ventas"), ("operacion", "Gastos de operación"),
              ("otros", "Gastos financieros y otros"), ("impuesto", "Impuesto sobre utilidades")],
}
FLUJOS = {"operacion": "Operación", "inversion": "Inversión", "financiacion": "Financiación"}
ORIGENES = {
    "manual": "Asiento manual", "ingreso": "Ingreso", "gasto": "Gasto o compra",
    "factura_cobrar": "Factura por cobrar", "factura_pagar": "Factura por pagar",
    "cobro": "Cobro", "pago": "Pago", "transferencia": "Transferencia / cambio",
    "movimiento": "Otro movimiento de dinero", "ajuste_cambio": "Ajuste por tasa de cambio",
    "saldo_inicial": "Saldo inicial",
    "compra_inventario": "Compra de mercancía", "costo_venta": "Costo de lo vendido",
    "ajuste_inventario": "Ajuste de inventario", "arqueo": "Arqueo de caja",
    "rebaja_cobrar": "Rebaja / devolución de cliente", "rebaja_pagar": "Rebaja / devolución de proveedor",
    "zelle": "Compra de Zelle",
}


class ErrorContable(Exception):
    pass


import threading
CONTEXTO = threading.local()  # CONTEXTO.usuario = quién está anotando (lo pone la pantalla)


def r2(x):
    return round((x or 0) + 0.0, 2)


def hoy():
    return date.today().isoformat()


def moneda_base(conn):
    return get_config(conn, "moneda_base", "USD")


def nombre_empresa(conn):
    return get_config(conn, "empresa", "Mi Negocio")


# ---------------------------------------------------------------- tasas

def tasa_del_dia(conn, fecha=None):
    fecha = fecha or hoy()
    fila = conn.execute("SELECT cup_por_usd FROM tasas WHERE fecha <= ? ORDER BY fecha DESC LIMIT 1",
                        (fecha,)).fetchone()
    if not fila:
        fila = conn.execute("SELECT cup_por_usd FROM tasas ORDER BY fecha ASC LIMIT 1").fetchone()
    return fila["cup_por_usd"] if fila else None


def guardar_tasa_si_falta(conn, fecha, tasa):
    if tasa and tasa > 0:
        conn.execute("INSERT OR IGNORE INTO tasas (fecha, cup_por_usd) VALUES (?, ?)", (fecha, tasa))


def convertir(importe, de, a, tasa):
    """Convierte entre CUP y USD. tasa = CUP por 1 USD."""
    if de == a:
        return importe
    if not tasa or tasa <= 0:
        raise ErrorContable("Falta la tasa de cambio (cuántos CUP vale 1 USD).")
    if de == "CUP" and a == "USD":
        return importe / tasa
    return importe * tasa


# ---------------------------------------------------------------- cuentas

def cuentas(conn, solo_activas=False):
    q = "SELECT * FROM cuentas"
    if solo_activas:
        q += " WHERE activa = 1"
    return [dict(c) for c in conn.execute(q + " ORDER BY codigo")]


def cuenta_por_rol(conn, rol):
    c = conn.execute("SELECT * FROM cuentas WHERE rol = ?", (rol,)).fetchone()
    if not c:
        raise ErrorContable(f"Falta la cuenta del sistema '{rol}'.")
    return dict(c)


def natural(tipo, debe, haber):
    return (debe - haber) if tipo in ("activo", "gasto") else (haber - debe)


# ---------------------------------------------------------------- asientos

def cerrado_hasta(conn):
    """Último día del período cerrado (nadie puede anotar, cambiar ni borrar con esa fecha o antes)."""
    return get_config(conn, "cerrado_hasta") or None


def comprobar_abierto(conn, fecha):
    ch = cerrado_hasta(conn)
    if ch and fecha and fecha <= ch:
        f = datetime.strptime(ch, "%Y-%m-%d").strftime("%d/%m/%Y")
        raise ErrorContable(f"Ese mes está cerrado (hasta el {f}): no se puede anotar, cambiar ni borrar nada con esa fecha. "
                            "Si de verdad hace falta, un administrador puede reabrirlo en Más → Cierre de mes.")


def crear_asiento(conn, fecha, concepto, lineas, origen="manual", referencia=None,
                  documento_id=None, tasa=None, asiento_id=None):
    """lineas: [{cuenta_id, importe (con signo: + debe / - haber, en moneda original), moneda,
    tercero_id?, documento_id?, descripcion?, base? (importe en moneda base con signo, opcional)}]"""
    if not fecha:
        raise ErrorContable("Falta la fecha.")
    try:
        datetime.strptime(fecha, "%Y-%m-%d")
    except ValueError:
        raise ErrorContable("La fecha no es válida.")
    comprobar_abierto(conn, fecha)
    if asiento_id:
        viejo = conn.execute("SELECT fecha FROM asientos WHERE id = ?", (asiento_id,)).fetchone()
        if viejo:
            comprobar_abierto(conn, viejo["fecha"])
    concepto = (concepto or "").strip()[:300]
    if not concepto:
        raise ErrorContable("Escribe un concepto (qué fue este movimiento).")
    base = moneda_base(conn)
    lineas = [l for l in lineas if abs(l.get("importe") or 0) > 0.0000001 or abs(l.get("base") or 0) > 0.0000001]
    if len(lineas) < 2:
        raise ErrorContable("Un asiento necesita al menos dos líneas con importe.")
    calc = []
    for l in lineas:
        c = conn.execute("SELECT * FROM cuentas WHERE id = ?", (l["cuenta_id"],)).fetchone()
        if not c:
            raise ErrorContable("Una de las cuentas no existe.")
        if c["es_grupo"]:
            raise ErrorContable(f"'{c['nombre']}' es un grupo; elige una cuenta dentro de él.")
        if not c["activa"]:
            raise ErrorContable(f"La cuenta '{c['nombre']}' está desactivada.")
        moneda = l.get("moneda") or base
        if moneda not in MONEDAS:
            raise ErrorContable("Moneda no válida.")
        if c["moneda"] and c["moneda"] != moneda:
            raise ErrorContable(f"La cuenta '{c['nombre']}' solo admite {c['moneda']}.")
        if c["por_tercero"] and not l.get("tercero_id"):
            raise ErrorContable(f"La cuenta '{c['nombre']}' necesita saber de quién es (proveedor, cliente, persona...).")
        importe = l.get("importe") or 0
        if abs(importe) >= 1e12:
            raise ErrorContable("Importe demasiado grande.")
        if l.get("base") is not None:
            b = r2(l["base"])
        else:
            b = r2(convertir(importe, moneda, base, tasa))
        calc.append(dict(l, moneda=moneda, base=b, importe=r2(importe)))
    diferencia = r2(sum(x["base"] for x in calc))
    if abs(diferencia) > 0.02 * len(calc) + 0.001:
        raise ErrorContable(f"El asiento no cuadra: el debe y el haber difieren en {abs(diferencia):,.2f} {base}.")
    if diferencia:
        mayor = max(calc, key=lambda x: abs(x["base"]))
        mayor["base"] = r2(mayor["base"] - diferencia)
    if asiento_id:  # modificar: se conserva el número y se reemplazan las líneas
        if not conn.execute("SELECT 1 FROM asientos WHERE id = ?", (asiento_id,)).fetchone():
            raise ErrorContable("Ese movimiento ya no existe.")
        conn.execute("DELETE FROM lineas WHERE asiento_id = ?", (asiento_id,))
        conn.execute("UPDATE asientos SET fecha = ?, concepto = ?, referencia = ?, origen = ?, documento_id = ?, tasa = ?"
                     " WHERE id = ?", (fecha, concepto, (referencia or "").strip() or None, origen, documento_id, tasa,
                                      asiento_id))
        aid = asiento_id
    else:
        numero = (conn.execute("SELECT MAX(numero) FROM asientos").fetchone()[0] or 0) + 1
        cur = conn.execute(
            "INSERT INTO asientos (numero, fecha, concepto, referencia, origen, documento_id, tasa, creado, usuario)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (numero, fecha, concepto, (referencia or "").strip() or None, origen, documento_id, tasa,
             datetime.now().isoformat(timespec="seconds"), getattr(CONTEXTO, "usuario", None)),
        )
        aid = cur.lastrowid
    for x in calc:
        conn.execute(
            "INSERT INTO lineas (asiento_id, cuenta_id, tercero_id, documento_id, debe, haber, moneda,"
            " importe_orig, descripcion) VALUES (?,?,?,?,?,?,?,?,?)",
            (aid, x["cuenta_id"], x.get("tercero_id"), x.get("documento_id"),
             x["base"] if x["base"] > 0 else 0, -x["base"] if x["base"] < 0 else 0,
             x["moneda"], x["importe"], x.get("descripcion")),
        )
    return aid


def eliminar_asiento(conn, asiento_id):
    """Borra un movimiento de verdad. Queda una copia en la tabla 'eliminados' por si hiciera falta."""
    import json
    a = conn.execute("SELECT * FROM asientos WHERE id = ?", (asiento_id,)).fetchone()
    if not a:
        raise ErrorContable("Ese movimiento ya no existe.")
    comprobar_abierto(conn, a["fecha"])
    doc = None
    if a["origen"] in ("factura_cobrar", "factura_pagar") and a["documento_id"]:
        doc = conn.execute("SELECT * FROM documentos WHERE id = ?", (a["documento_id"],)).fetchone()
        otros = conn.execute(
            "SELECT DISTINCT x.numero FROM asientos x LEFT JOIN lineas l ON l.asiento_id = x.id"
            " WHERE x.id != ? AND (x.documento_id = ? OR l.documento_id = ?)",
            (asiento_id, a["documento_id"], a["documento_id"])).fetchall()
        if otros:
            nums = ", ".join(str(o["numero"]) for o in otros)
            raise ErrorContable(f"Esta factura tiene cobros/pagos (movimientos n.º {nums}). Elimínalos primero.")
    import inventario
    inventario.eliminar_movs_de_asiento(conn, asiento_id)
    lineas = [dict(l) for l in conn.execute("SELECT * FROM lineas WHERE asiento_id = ?", (asiento_id,))]
    conn.execute("INSERT INTO eliminados (fecha, numero, datos) VALUES (?, ?, ?)",
                 (datetime.now().isoformat(timespec="seconds"), a["numero"],
                  json.dumps({"asiento": dict(a), "lineas": lineas, "documento": dict(doc) if doc else None},
                             ensure_ascii=False)))
    conn.execute("DELETE FROM lineas WHERE asiento_id = ?", (asiento_id,))
    conn.execute("UPDATE asientos SET documento_id = NULL WHERE id = ?", (asiento_id,))
    conn.execute("DELETE FROM asientos WHERE id = ?", (asiento_id,))
    if doc:
        conn.execute("DELETE FROM documentos WHERE id = ?", (doc["id"],))


def anular_asiento(conn, asiento_id, motivo):
    a = conn.execute("SELECT * FROM asientos WHERE id = ?", (asiento_id,)).fetchone()
    if not a:
        raise ErrorContable("No existe ese asiento.")
    if a["anulado"]:
        raise ErrorContable("Ya estaba anulado.")
    comprobar_abierto(conn, a["fecha"])
    import inventario
    if inventario.movs_de_asiento(conn, asiento_id):
        raise ErrorContable("Este movimiento es del inventario: usa Eliminar (así se corrige también la existencia).")
    if a["origen"] in ("factura_cobrar", "factura_pagar") and a["documento_id"]:
        anular_documento(conn, a["documento_id"], motivo)
        return
    conn.execute("UPDATE asientos SET anulado = 1, motivo_anulacion = ? WHERE id = ?",
                 (motivo or "Anulado", asiento_id))


def anular_documento(conn, documento_id, motivo):
    d = conn.execute("SELECT * FROM documentos WHERE id = ?", (documento_id,)).fetchone()
    if not d or d["anulado"]:
        raise ErrorContable("Esa factura no existe o ya estaba anulada.")
    comprobar_abierto(conn, d["fecha"])
    import inventario
    if d["asiento_id"] and inventario.movs_de_asiento(conn, d["asiento_id"]):
        raise ErrorContable("Esta factura es del inventario: usa Eliminar (así se corrige también la existencia).")
    pagos = conn.execute(
        "SELECT COUNT(*) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " WHERE l.documento_id = ? AND a.anulado = 0 AND a.id != ?",
        (documento_id, d["asiento_id"] or 0)).fetchone()[0]
    if pagos:
        raise ErrorContable("Esa factura ya tiene cobros o pagos. Anula primero esos cobros/pagos.")
    conn.execute("UPDATE documentos SET anulado = 1 WHERE id = ?", (documento_id,))
    conn.execute("UPDATE asientos SET anulado = 1, motivo_anulacion = ? WHERE id = ?",
                 (motivo or "Factura anulada", d["asiento_id"]))


# ---------------------------------------------------------------- terceros y documentos

def tercero_por_nombre(conn, nombre, tipo_defecto="Proveedor", crear=True):
    nombre = " ".join((nombre or "").split())[:120]
    if not nombre:
        return None
    t = conn.execute("SELECT id FROM terceros WHERE lower(nombre) = lower(?)", (nombre,)).fetchone()
    if t:
        return t["id"]
    if not crear:
        return None
    return conn.execute("INSERT INTO terceros (nombre, tipo) VALUES (?, ?)", (nombre, tipo_defecto)).lastrowid


def pendiente_documento(conn, doc):
    signo = 1 if doc["tipo"] == "cobrar" else -1
    total = conn.execute(
        "SELECT COALESCE(SUM(l.importe_orig), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " WHERE l.documento_id = ? AND a.anulado = 0", (doc["id"],)).fetchone()[0]
    return r2(signo * total)


def documentos(conn, tipo=None, tercero_id=None, solo_pendientes=False):
    q = ("SELECT d.*, t.nombre AS tercero, t.tipo AS tercero_tipo, c.nombre AS cuenta FROM documentos d"
         " JOIN terceros t ON t.id = d.tercero_id JOIN cuentas c ON c.id = d.cuenta_id WHERE d.anulado = 0")
    p = []
    if tipo:
        q += " AND d.tipo = ?"
        p.append(tipo)
    if tercero_id:
        q += " AND d.tercero_id = ?"
        p.append(tercero_id)
    out = []
    sumas = _memo(conn, ("sumas_docs",), lambda: {r[0]: r[1] for r in conn.execute(
        "SELECT l.documento_id, COALESCE(SUM(l.importe_orig), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " WHERE a.anulado = 0 AND l.documento_id IS NOT NULL GROUP BY l.documento_id")})
    for d in conn.execute(q + " ORDER BY d.fecha, d.id", p):
        d = dict(d)
        d["pendiente"] = r2((1 if d["tipo"] == "cobrar" else -1) * sumas.get(d["id"], 0))
        d["pagado"] = r2(d["importe"] - d["pendiente"])
        d["estado"] = "Pagada" if abs(d["pendiente"]) < 0.005 else ("Parcial" if d["pagado"] > 0.004 else "Pendiente")
        d["vencida"] = bool(d["pendiente"] > 0.004 and d["vencimiento"] and d["vencimiento"] < hoy())
        if solo_pendientes and abs(d["pendiente"]) < 0.005:
            continue
        out.append(d)
    return out


def registrar_documento(conn, tipo, tercero_id, fecha, vencimiento, numero, concepto, cuenta_id,
                        moneda, importe, tasa, documento_id=None):
    if importe <= 0:
        raise ErrorContable("El importe tiene que ser mayor que cero.")
    if not tercero_id:
        raise ErrorContable("Indica a quién corresponde la factura.")
    if vencimiento and vencimiento < fecha:
        raise ErrorContable("El vencimiento no puede ser antes de la fecha de la factura.")
    cuenta_puente = cuenta_por_rol(conn, ("cxc_" if tipo == "cobrar" else "cxp_") + moneda)
    if documento_id:
        return _modificar_documento(conn, documento_id, tipo, tercero_id, fecha, vencimiento, numero, concepto,
                                    cuenta_id, moneda, importe, tasa, cuenta_puente)
    did = conn.execute(
        "INSERT INTO documentos (tipo, tercero_id, numero, fecha, vencimiento, concepto, cuenta_id, moneda,"
        " importe, tasa) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (tipo, tercero_id, numero or None, fecha, vencimiento or None, concepto, cuenta_id, moneda,
         r2(importe), tasa)).lastrowid
    signo = 1 if tipo == "cobrar" else -1
    lineas = [
        {"cuenta_id": cuenta_puente["id"], "importe": signo * importe, "moneda": moneda,
         "tercero_id": tercero_id, "documento_id": did},
        {"cuenta_id": cuenta_id, "importe": -signo * importe, "moneda": moneda, "tercero_id": tercero_id},
    ]
    etiqueta = "Factura por cobrar" if tipo == "cobrar" else "Factura por pagar"
    aid = crear_asiento(conn, fecha, concepto, lineas, origen="factura_" + tipo,
                        referencia=numero or etiqueta, documento_id=did, tasa=tasa)
    conn.execute("UPDATE documentos SET asiento_id = ? WHERE id = ?", (aid, did))
    aplicar_anticipos(conn, did)
    return did


def aplicar_anticipos(conn, did):
    """Si la persona tiene adelantos sueltos (pagos a cuenta sin factura) en la moneda de esta factura nueva,
    se unen solos a la factura, del más viejo al más nuevo, hasta cubrirla. Es lo mismo que abrir el pago del
    adelanto y elegir la factura, pero sin que haga falta acordarse. Deja en CONTEXTO.anticipo lo aplicado."""
    CONTEXTO.anticipo = None
    doc = conn.execute("SELECT * FROM documentos WHERE id = ?", (did,)).fetchone()
    puente = cuenta_por_rol(conn, ("cxc_" if doc["tipo"] == "cobrar" else "cxp_") + doc["moneda"])
    dir_ = -1 if doc["tipo"] == "cobrar" else 1  # signo de importe_orig que tiene un adelanto
    sueltas = conn.execute(
        "SELECT l.* FROM lineas l JOIN asientos a ON a.id = l.asiento_id WHERE l.cuenta_id = ? AND l.tercero_id = ?"
        " AND l.documento_id IS NULL AND a.anulado = 0 ORDER BY a.fecha, a.numero, l.id",
        (puente["id"], doc["tercero_id"])).fetchall()
    disponible = r2(dir_ * sum(l["importe_orig"] for l in sueltas))  # neto: descuenta deudas sueltas
    falta = r2(min(disponible, pendiente_documento(conn, doc)))
    if falta <= 0.004:
        return 0
    aplicado, tocados = 0.0, set()
    for l in sueltas:
        v = dir_ * l["importe_orig"]
        if v <= 0.004 or falta <= 0.004:
            continue
        if v <= falta + 0.004:
            conn.execute("UPDATE lineas SET documento_id = ? WHERE id = ?", (did, l["id"]))
            parte = v
        else:  # el adelanto es mayor que la factura: se parte la línea, el resto sigue como adelanto
            parte = falta
            k = parte / v
            d1, h1 = r2(l["debe"] * k), r2(l["haber"] * k)
            conn.execute("UPDATE lineas SET importe_orig = ?, debe = ?, haber = ? WHERE id = ?",
                         (r2(l["importe_orig"] - dir_ * parte), r2(l["debe"] - d1), r2(l["haber"] - h1), l["id"]))
            conn.execute("INSERT INTO lineas (asiento_id, cuenta_id, tercero_id, documento_id, debe, haber, moneda,"
                         " importe_orig, descripcion) VALUES (?,?,?,?,?,?,?,?,?)",
                         (l["asiento_id"], l["cuenta_id"], l["tercero_id"], did, d1, h1, l["moneda"],
                          r2(dir_ * parte), "Anticipo aplicado"))
        falta, aplicado = r2(falta - parte), r2(aplicado + parte)
        tocados.add(l["asiento_id"])
    num = doc["numero"] or doc["id"]
    for aid in tocados:
        a = conn.execute("SELECT concepto FROM asientos WHERE id = ?", (aid,)).fetchone()
        docs = {x[0] for x in conn.execute("SELECT DISTINCT documento_id FROM lineas WHERE asiento_id = ?"
                                           " AND cuenta_id = ?", (aid, puente["id"]))}
        nuevo = (a["concepto"] or "").replace("(anticipo / pago a cuenta)", f"(anticipo aplicado a factura {num})")
        conn.execute("UPDATE asientos SET concepto = ?, documento_id = ? WHERE id = ?",
                     (nuevo, did if docs == {did} else None, aid))
    CONTEXTO.anticipo = (aplicado, doc["moneda"])
    return aplicado


def _modificar_documento(conn, did, tipo, tercero_id, fecha, vencimiento, numero, concepto, cuenta_id, moneda,
                         importe, tasa, cuenta_puente):
    viejo = conn.execute("SELECT * FROM documentos WHERE id = ?", (did,)).fetchone()
    if not viejo or viejo["tipo"] != tipo:
        raise ErrorContable("Esa factura no existe.")
    if viejo["anulado"]:
        raise ErrorContable("Esa factura está anulada; no se puede modificar.")
    pagos = conn.execute("SELECT COUNT(*) FROM lineas l WHERE l.documento_id = ? AND l.asiento_id != ?",
                         (did, viejo["asiento_id"])).fetchone()[0]
    if pagos and (moneda != viejo["moneda"] or abs((tasa or 0) - (viejo["tasa"] or 0)) > 1e-9
                  or tercero_id != viejo["tercero_id"]):
        raise ErrorContable("Esta factura ya tiene cobros/pagos: no se puede cambiar la moneda, la tasa ni la persona. "
                            "Elimina primero los cobros/pagos si necesitas cambiar eso.")
    conn.execute("UPDATE documentos SET tercero_id=?, numero=?, fecha=?, vencimiento=?, concepto=?, cuenta_id=?,"
                 " moneda=?, importe=?, tasa=? WHERE id=?",
                 (tercero_id, numero or None, fecha, vencimiento or None, concepto, cuenta_id, moneda, r2(importe),
                  tasa, did))
    signo = 1 if tipo == "cobrar" else -1
    lineas = [
        {"cuenta_id": cuenta_puente["id"], "importe": signo * importe, "moneda": moneda,
         "tercero_id": tercero_id, "documento_id": did},
        {"cuenta_id": cuenta_id, "importe": -signo * importe, "moneda": moneda, "tercero_id": tercero_id},
    ]
    etiqueta = "Factura por cobrar" if tipo == "cobrar" else "Factura por pagar"
    crear_asiento(conn, fecha, concepto, lineas, origen="factura_" + tipo, referencia=numero or etiqueta,
                  documento_id=did, tasa=tasa, asiento_id=viejo["asiento_id"])
    if pendiente_documento(conn, dict(viejo)) < -0.005:
        raise ErrorContable("El nuevo importe es menor que lo que ya se cobró/pagó de esa factura.")
    return did


def registrar_cobro_pago(conn, tipo, fecha, tercero_id, documento_id, caja_id, importe, tasa, concepto,
                         referencia=None, cuenta_deuda_id=None, asiento_id=None, anticipo=False,
                         contra_id=None, moneda_contra=None, origen=None, moneda_deuda=None):
    """tipo 'cobro' (entra dinero) o 'pago' (sale dinero). importe en la moneda de la caja.
    Si no se elige factura ni cuenta, se aplica solo a las facturas pendientes más antiguas de esa persona;
    lo que sobre queda como anticipo. Con anticipo=True no se aplica a ninguna factura."""
    if importe <= 0:
        raise ErrorContable("El importe tiene que ser mayor que cero.")
    if not tercero_id:
        raise ErrorContable("Indica quién paga o a quién se le paga.")
    base = moneda_base(conn)
    origen = origen or tipo
    if contra_id:  # rebaja o devolución: en vez de caja, la contrapartida es la cuenta de ventas/compras
        caja = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_grupo = 0", (contra_id,)).fetchone()
        if not caja:
            raise ErrorContable("Elige la cuenta.")
        caja_id = caja["id"]
        mon_caja = moneda_contra or base
        if mon_caja not in MONEDAS:
            raise ErrorContable("Elige la moneda.")
    else:
        caja = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1", (caja_id,)).fetchone()
        if not caja:
            raise ErrorContable("Elige la caja o banco.")
        mon_caja = caja["moneda"] or base
    signo = 1 if tipo == "cobro" else -1
    lado = "cobrar" if tipo == "cobro" else "pagar"
    base_caja = r2(convertir(importe, mon_caja, base, tasa))
    lineas = [{"cuenta_id": caja_id, "importe": signo * importe, "moneda": mon_caja, "base": signo * base_caja,
               "tercero_id": tercero_id}]
    nombre_t = conn.execute("SELECT nombre FROM terceros WHERE id = ?", (tercero_id,)).fetchone()[0]

    if cuenta_deuda_id:
        puente = conn.execute("SELECT * FROM cuentas WHERE id = ? AND por_tercero = 1 AND es_grupo = 0 AND tipo = ?",
                              (cuenta_deuda_id, "activo" if tipo == "cobro" else "pasivo")).fetchone()
        if not puente:
            raise ErrorContable("Esa deuda no corresponde a este tipo de movimiento.")
        mon_deuda = puente["moneda"] or mon_caja
        lineas.append({"cuenta_id": puente["id"], "importe": -signo * r2(convertir(importe, mon_caja, mon_deuda, tasa)),
                       "moneda": mon_deuda, "base": -signo * base_caja, "tercero_id": tercero_id})
        concepto = concepto or ("Cobro a " if tipo == "cobro" else "Pago a ") + f"{nombre_t} ({puente['nombre']})"
        return crear_asiento(conn, fecha, concepto, lineas, origen=origen, referencia=referencia, tasa=tasa,
                             asiento_id=asiento_id)

    if documento_id:
        doc = conn.execute("SELECT * FROM documentos WHERE id = ? AND anulado = 0", (documento_id,)).fetchone()
        if not doc or doc["tercero_id"] != tercero_id:
            raise ErrorContable("Esa factura no es de esta persona/empresa.")
        if doc["tipo"] != lado:
            raise ErrorContable("Esa factura no corresponde a este tipo de movimiento.")
        pendiente = pendiente_documento(conn, doc)
        aplicado = r2(convertir(importe, mon_caja, doc["moneda"], tasa))
        if aplicado > pendiente + 0.01:
            raise ErrorContable(
                f"Ese importe ({aplicado:,.2f} {doc['moneda']}) es mayor que lo que falta de la factura "
                f"({pendiente:,.2f} {doc['moneda']}).")
        candidatas = [(dict(doc), pendiente)]
    elif anticipo:
        candidatas = []
    else:
        mon_d = moneda_deuda if moneda_deuda in MONEDAS else mon_caja
        candidatas = [(d, d["pendiente"]) for d in documentos(conn, lado, tercero_id, solo_pendientes=True)
                      if d["pendiente"] > 0.004 and d["moneda"] == mon_d]

    resto = importe  # en moneda de la caja
    base_historica_total = 0.0
    aplicadas = []
    for doc, pendiente in candidatas:
        if resto <= 0.004:
            break
        pend_caja = r2(convertir(pendiente, doc["moneda"], mon_caja, tasa))
        if resto >= pend_caja - 0.004:
            parte, aplicado = pend_caja, pendiente
        else:
            parte, aplicado = resto, r2(convertir(resto, mon_caja, doc["moneda"], tasa))
        resto = r2(resto - parte)
        puente = cuenta_por_rol(conn, ("cxc_" if lado == "cobrar" else "cxp_") + doc["moneda"])
        base_hist = r2(convertir(aplicado, doc["moneda"], base, doc["tasa"]))
        base_historica_total += base_hist
        lineas.append({"cuenta_id": puente["id"], "importe": -signo * aplicado, "moneda": doc["moneda"],
                       "base": -signo * base_hist, "tercero_id": tercero_id, "documento_id": doc["id"]})
        aplicadas.append(doc)
    base_resto = 0.0
    if resto > 0.004:  # lo que sobra queda como anticipo / pago a cuenta, en la moneda de la deuda elegida
        mon_resto = moneda_deuda if (moneda_deuda in MONEDAS and not documento_id) else mon_caja
        puente = cuenta_por_rol(conn, ("cxc_" if lado == "cobrar" else "cxp_") + mon_resto)
        base_resto = r2(base_caja - base_historica_total) if not aplicadas else r2(convertir(resto, mon_caja, base, tasa))
        lineas.append({"cuenta_id": puente["id"], "importe": -signo * r2(convertir(resto, mon_caja, mon_resto, tasa)),
                       "moneda": mon_resto,
                       "base": -signo * base_resto, "tercero_id": tercero_id,
                       "descripcion": "Anticipo / pago a cuenta" if aplicadas or anticipo or not candidatas else None})
    dif = r2(signo * (base_caja - base_historica_total - base_resto))
    if abs(dif) >= 0.01:
        lineas.append({"cuenta_id": cuenta_por_rol(conn, "dif_cambio")["id"], "importe": -dif,
                       "moneda": base, "base": -dif, "descripcion": "Diferencia de cambio realizada"})
    if not concepto:
        accion = "Rebaja a " if origen.startswith("rebaja") else ("Cobro a " if tipo == "cobro" else "Pago a ")
        if aplicadas:
            nums = ", ".join(str(d["numero"] or d["id"]) for d in aplicadas)
            concepto = f"{accion}{nombre_t}: factura{'s' if len(aplicadas) > 1 else ''} {nums}"
        else:
            concepto = f"{accion}{nombre_t} (anticipo / pago a cuenta)"
    doc_asiento = aplicadas[0]["id"] if len(aplicadas) == 1 else None
    return crear_asiento(conn, fecha, concepto, lineas, origen=origen, referencia=referencia,
                         documento_id=doc_asiento, tasa=tasa, asiento_id=asiento_id)


def calculo_zelle(zelle_usd, pago_usd, zelle_cup, pago_cup, tasa):
    """Cuánto costó cada Zelle y el % de ganancia o pérdida, separado por moneda de pago.
    diferencia > 0: pagaste más de lo que recibiste (pérdida); < 0: recibiste más (ganancia).
    El % es sobre el Zelle recibido. Los CUP se pasan a USD con la tasa que se indica."""
    partes = {}
    if zelle_usd or pago_usd:
        d = pago_usd - zelle_usd
        partes["USD"] = {"zelle": r2(zelle_usd), "pagado": r2(pago_usd), "equivale": r2(pago_usd), "diferencia": r2(d),
                         "pct": round(d / zelle_usd * 100, 2) if zelle_usd else 0.0,
                         "precio": round(pago_usd / zelle_usd, 4) if zelle_usd else 0.0}
    if zelle_cup or pago_cup:
        eq = pago_cup / tasa if tasa else 0.0
        d = eq - zelle_cup
        partes["CUP"] = {"zelle": r2(zelle_cup), "pagado": r2(pago_cup), "equivale": r2(eq), "diferencia": r2(d),
                         "pct": round(d / zelle_cup * 100, 2) if zelle_cup else 0.0,
                         "precio": round(pago_cup / zelle_cup, 2) if zelle_cup else 0.0}
    zt = sum(p["zelle"] for p in partes.values())
    costo = sum(p["equivale"] for p in partes.values())
    return {"partes": partes, "zelle": r2(zt), "costo": r2(costo), "diferencia": r2(costo - zt),
            "pct": round((costo - zt) / zt * 100, 2) if zt else 0.0}


def cajas_negativas(conn):
    """Cajas o bancos con saldo negativo: es imposible tener menos de cero, así que avisa de un error."""
    out = []
    for c in cuentas(conn):
        if c["es_efectivo"] and not c["es_grupo"]:
            d, h, o = movimientos(conn).get(c["id"], (0, 0, 0))
            saldo = o if c["moneda"] else d - h
            if saldo < -0.004:
                out.append((c["nombre"], r2(saldo), c["moneda"] or moneda_base(conn)))
    return out


# ---------------------------------------------------------------- consultas de saldos

def _memo(conn, clave, calcular):
    """Recuerda resultados dentro de una misma pantalla (CONTEXTO.memo lo crea cada pedido).
    La clave lleva conn.total_changes: si se anota algo, el recuerdo deja de valer solo."""
    memo = getattr(CONTEXTO, "memo", None)
    if memo is None:
        return calcular()
    k = (id(conn), conn.total_changes) + clave
    if k not in memo:
        memo[k] = calcular()
    return memo[k]


def movimientos(conn, desde=None, hasta=None):
    if getattr(CONTEXTO, "memo", None) is None:
        return _movimientos(conn, desde, hasta)
    return _memo(conn, ("mov", desde, hasta), lambda: _movimientos_acumulados(conn, desde, hasta))


def _acumulados(conn):
    """Sumas por cuenta y por día, acumuladas (una sola consulta por pedido). Con ellas, los movimientos de
    cualquier período salen restando dos acumulados, sin volver a recorrer todas las líneas."""
    def calcular():
        t = {}
        for f in conn.execute("SELECT l.cuenta_id c, a.fecha f, SUM(l.debe) d, SUM(l.haber) h, SUM(l.importe_orig) o"
                              " FROM lineas l JOIN asientos a ON a.id = l.asiento_id WHERE a.anulado = 0"
                              " GROUP BY l.cuenta_id, a.fecha ORDER BY l.cuenta_id, a.fecha"):
            fechas, acum = t.setdefault(f["c"], ([], []))
            d0, h0, o0 = acum[-1] if acum else (0.0, 0.0, 0.0)
            fechas.append(f["f"])
            acum.append((d0 + (f["d"] or 0), h0 + (f["h"] or 0), o0 + (f["o"] or 0)))
        return t
    return _memo(conn, ("acumulados",), calcular)


def _movimientos_acumulados(conn, desde=None, hasta=None):
    import bisect
    out = {}
    for cid, (fechas, acum) in _acumulados(conn).items():
        j = len(fechas) if hasta is None else bisect.bisect_right(fechas, hasta)
        i = 0 if desde is None else bisect.bisect_left(fechas, desde)
        if j <= i:
            continue
        d1, h1, o1 = acum[j - 1]
        d0, h0, o0 = acum[i - 1] if i > 0 else (0.0, 0.0, 0.0)
        out[cid] = (d1 - d0, h1 - h0, o1 - o0)
    return out


def _movimientos(conn, desde=None, hasta=None):
    q = ("SELECT l.cuenta_id, SUM(l.debe) d, SUM(l.haber) h, SUM(l.importe_orig) o FROM lineas l"
         " JOIN asientos a ON a.id = l.asiento_id WHERE a.anulado = 0")
    p = []
    if desde:
        q += " AND a.fecha >= ?"
        p.append(desde)
    if hasta:
        q += " AND a.fecha <= ?"
        p.append(hasta)
    return {f["cuenta_id"]: (f["d"] or 0, f["h"] or 0, f["o"] or 0)
            for f in conn.execute(q + " GROUP BY l.cuenta_id", p)}


def resultado(conn, desde=None, hasta=None):
    return _memo(conn, ("res", desde, hasta), lambda: _resultado(conn, desde, hasta))


def _resultado(conn, desde=None, hasta=None):
    q = ("SELECT COALESCE(SUM(l.haber - l.debe), 0) FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
         " JOIN cuentas c ON c.id = l.cuenta_id WHERE a.anulado = 0 AND c.tipo IN ('ingreso','gasto')")
    p = []
    if desde:
        q += " AND a.fecha >= ?"
        p.append(desde)
    if hasta:
        q += " AND a.fecha <= ?"
        p.append(hasta)
    return r2(conn.execute(q, p).fetchone()[0])


def saldo_cuenta(conn, cuenta, hasta=None, desde=None):
    m = movimientos(conn, desde, hasta).get(cuenta["id"], (0, 0, 0))
    return r2(natural(cuenta["tipo"], m[0], m[1])), r2(m[2])


def dia_antes(fecha):
    return (datetime.strptime(fecha, "%Y-%m-%d").date() - timedelta(days=1)).isoformat()


def inicio_anio(fecha):
    return fecha[:4] + "-01-01"


# ---------------------------------------------------------------- períodos

def ultimo_dia(anio, mes):
    return date(anio, mes, calendar.monthrange(anio, mes)[1]).isoformat()


def rango_mes(anio, mes):
    return (date(anio, mes, 1).isoformat(), ultimo_dia(anio, mes), f"{MESES[mes - 1]} {anio}")


def rango_trimestre(anio, t):
    m1 = 3 * (t - 1) + 1
    return (date(anio, m1, 1).isoformat(), ultimo_dia(anio, m1 + 2), f"{t}.º trimestre {anio}")


def meses_entre(desde, hasta):
    d = datetime.strptime(desde, "%Y-%m-%d").date().replace(day=1)
    h = datetime.strptime(hasta, "%Y-%m-%d").date()
    out = []
    while d <= h:
        a, b, _ = rango_mes(d.year, d.month)
        out.append((max(a, desde), min(b, hasta), f"{MESES_CORTOS[d.month - 1]} {str(d.year)[2:]}"))
        d = date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    return out


def leer_periodo(args):
    """Lee el período elegido en la pantalla. Devuelve un dict con desde, hasta, etiqueta,
    columnas (para informes por rango) y fechas de corte (para el balance)."""
    t = date.today()
    modo = args.get("modo") or "mes"
    vista = args.get("vista") or "comparar"
    comparar_con = args.get("comparar_con") or "anterior"

    def entero(nombre, defecto, lo, hi):
        try:
            v = int(args.get(nombre) or defecto)
        except ValueError:
            v = defecto
        return min(max(v, lo), hi)

    anio = entero("anio", t.year, 1990, 2100)
    mes = entero("mes", t.month, 1, 12)
    trim = entero("trimestre", (t.month - 1) // 3 + 1, 1, 4)
    if modo == "anio":
        desde, hasta, etq = f"{anio}-01-01", f"{anio}-12-31", f"Año {anio}"
        ant = (f"{anio - 1}-01-01", f"{anio - 1}-12-31", f"Año {anio - 1}")
        ant_anio = ant
    elif modo == "trimestre":
        desde, hasta, etq = rango_trimestre(anio, trim)
        ant = rango_trimestre(anio - 1, 4) if trim == 1 else rango_trimestre(anio, trim - 1)
        ant_anio = rango_trimestre(anio - 1, trim)
    elif modo == "rango":
        desde = args.get("desde") or f"{t.year}-01-01"
        hasta = args.get("hasta") or t.isoformat()
        try:
            dd = datetime.strptime(desde, "%Y-%m-%d").date()
            hh = datetime.strptime(hasta, "%Y-%m-%d").date()
        except ValueError:
            dd, hh = date(t.year, 1, 1), t
        if hh < dd:
            dd, hh = hh, dd
        desde, hasta = dd.isoformat(), hh.isoformat()
        etq = f"{dd:%d/%m/%Y} al {hh:%d/%m/%Y}"
        largo = (hh - dd).days + 1
        a_h = dd - timedelta(days=1)
        a_d = a_h - timedelta(days=largo - 1)
        ant = (a_d.isoformat(), a_h.isoformat(), f"{a_d:%d/%m/%Y} al {a_h:%d/%m/%Y}")
        try:
            ad, ah = dd.replace(year=dd.year - 1), hh.replace(year=hh.year - 1)
        except ValueError:
            ad, ah = dd - timedelta(days=365), hh - timedelta(days=365)
        ant_anio = (ad.isoformat(), ah.isoformat(), f"{ad:%d/%m/%Y} al {ah:%d/%m/%Y}")
    else:
        modo = "mes"
        desde, hasta, etq = rango_mes(anio, mes)
        ant = rango_mes(anio - 1, 12) if mes == 1 else rango_mes(anio, mes - 1)
        ant_anio = rango_mes(anio - 1, mes)
    comparado = ant_anio if comparar_con == "anio_anterior" else ant
    if vista == "evolucion":
        if modo == "anio" and args.get("detalle") == "trimestres":
            columnas = [rango_trimestre(anio, q)[:2] + (f"T{q}",) for q in range(1, 5)]
        else:
            columnas = meses_entre(desde, hasta)
        if len(columnas) <= 1:
            vista = "simple"
    if vista == "simple":
        columnas = [(desde, hasta, etq)]
    elif vista == "comparar":
        columnas = [(desde, hasta, etq), comparado]
    return {"modo": modo, "vista": vista, "comparar_con": comparar_con, "anio": anio, "mes": mes,
            "trimestre": trim, "desde": desde, "hasta": hasta, "etiqueta": etq, "columnas": columnas,
            "anterior": comparado, "detalle": args.get("detalle") or "meses"}


# ---------------------------------------------------------------- estructura de informes

class Informe:
    def __init__(self, titulo, subtitulo="", columnas=None, formatos=None, nota=""):
        self.titulo = titulo
        self.subtitulo = subtitulo
        self.columnas = columnas or []
        self.formatos = formatos or ["n"] * len(self.columnas)
        self.filas = []
        self.nota = nota

    def fila(self, etiqueta, valores=None, estilo="normal", nivel=0, link=None, codigo="", fmt=None):
        self.filas.append({"etiqueta": etiqueta, "valores": valores or [], "estilo": estilo,
                           "nivel": nivel, "link": link, "codigo": codigo, "fmt": fmt})

    def con_variacion(self):
        """Añade columnas de variación cuando hay dos columnas a comparar."""
        self.columnas = self.columnas + ["Variación", "Var. %"]
        self.formatos = self.formatos + ["n", "p"]
        for f in self.filas:
            v = f["valores"]
            if len(v) >= 2 and isinstance(v[0], (int, float)) and isinstance(v[1], (int, float)):
                dif = r2(v[0] - v[1])
                f["valores"] = v + [dif, (dif / abs(v[1])) if abs(v[1]) > 0.004 else None]
            elif v:
                f["valores"] = v + [None, None]
        return self


def _hojas_por_grupo(lista):
    grupos = [c for c in lista if c["es_grupo"]]
    hijos = {}
    sueltas = []
    for c in lista:
        if not c["es_grupo"]:
            if c["padre_id"]:
                hijos.setdefault(c["padre_id"], []).append(c)
            else:
                sueltas.append(c)
    return grupos, hijos, sueltas


def _bloque(inf, todas, tipo, seccion, valores_de, ncol, ocultar_ceros=True, link=None, nivel_base=1):
    """Escribe grupos y cuentas de un tipo/sección. Devuelve el total por columna."""
    lista = [c for c in todas if c["tipo"] == tipo and c["seccion"] == seccion]
    grupos, hijos, sueltas = _hojas_por_grupo(lista)
    total = [0.0] * ncol
    bloques = [(g, hijos.get(g["id"], [])) for g in grupos]
    if sueltas:
        bloques.append((None, sueltas))
    for g, hs in bloques:
        filas_h = []
        sub = [0.0] * ncol
        for h in hs:
            v = valores_de(h)
            if ocultar_ceros and all(abs(x) < 0.005 for x in v):
                continue
            sub = [a + b for a, b in zip(sub, v)]
            filas_h.append((h, v))
        if not filas_h:
            continue
        if g:
            inf.fila(g["nombre"], [r2(x) for x in sub], "grupo", nivel_base, codigo=g["codigo"])
        for h, v in filas_h:
            inf.fila(h["nombre"], [r2(x) for x in v], "normal", nivel_base + (1 if g else 0),
                     link=link(h) if link else None, codigo=h["codigo"])
        total = [a + b for a, b in zip(total, sub)]
    return [r2(x) for x in total]


def _link_mayor(desde, hasta):
    return lambda c: f"/cuentas/{c['id']}?desde={desde}&hasta={hasta}"


def informe_resultados(conn, per, ocultar_ceros=True):
    cols = per["columnas"]
    movs = [movimientos(conn, d, h) for d, h, _ in cols]
    todas = cuentas(conn)
    n = len(cols)

    def val(c):
        return [natural(c["tipo"], *m.get(c["id"], (0, 0, 0))[:2]) for m in movs]

    link = _link_mayor(per["desde"], per["hasta"])
    base = moneda_base(conn)
    inf = Informe("Estado de resultados", f"{per['etiqueta']} · cifras en {base}", [c[2] for c in cols])
    inf.fila("Ingresos de operación", estilo="seccion")
    ing = _bloque(inf, todas, "ingreso", "operacion", val, n, ocultar_ceros, link)
    inf.fila("Total ingresos de operación", ing, "total")
    inf.fila("Costo de ventas", estilo="seccion")
    costo = _bloque(inf, todas, "gasto", "costo", val, n, ocultar_ceros, link)
    inf.fila("Total costo de ventas", costo, "total")
    bruta = [r2(a - b) for a, b in zip(ing, costo)]
    inf.fila("UTILIDAD BRUTA", bruta, "resultado")
    inf.fila("Gastos de operación", estilo="seccion")
    gop = _bloque(inf, todas, "gasto", "operacion", val, n, ocultar_ceros, link)
    inf.fila("Total gastos de operación", gop, "total")
    oper = [r2(a - b) for a, b in zip(bruta, gop)]
    inf.fila("RESULTADO DE OPERACIÓN", oper, "resultado")
    inf.fila("Otros ingresos", estilo="seccion")
    otros_i = _bloque(inf, todas, "ingreso", "otros", val, n, ocultar_ceros, link)
    inf.fila("Total otros ingresos", otros_i, "total")
    inf.fila("Gastos financieros y otros gastos", estilo="seccion")
    otros_g = _bloque(inf, todas, "gasto", "otros", val, n, ocultar_ceros, link)
    inf.fila("Total gastos financieros y otros", otros_g, "total")
    antes = [r2(a + b - c) for a, b, c in zip(oper, otros_i, otros_g)]
    inf.fila("RESULTADO ANTES DE IMPUESTOS", antes, "resultado")
    inf.fila("Impuesto sobre utilidades", estilo="seccion")
    imp = _bloque(inf, todas, "gasto", "impuesto", val, n, ocultar_ceros, link)
    neto = [r2(a - b) for a, b in zip(antes, imp)]
    inf.fila("RESULTADO NETO DEL PERÍODO", neto, "gran_total")
    margenes = Informe("Márgenes", "", inf.columnas, ["p"] * n)
    for nombre, serie in (("Margen bruto", bruta), ("Margen de operación", oper), ("Margen neto", neto)):
        margenes.fila(nombre, [(s / i) if abs(i) > 0.004 else None for s, i in zip(serie, ing)])
    if per["vista"] == "comparar":
        inf.con_variacion()
    elif n > 1:
        _agregar_total(inf)
    return inf, margenes


def _agregar_total(inf):
    inf.columnas = inf.columnas + ["Total"]
    inf.formatos = inf.formatos + ["n"]
    for f in inf.filas:
        if f["valores"]:
            f["valores"] = f["valores"] + [r2(sum(x for x in f["valores"] if isinstance(x, (int, float))))]


def informe_balance(conn, per, ocultar_ceros=True):
    if per["vista"] == "comparar":
        cortes = [(per["hasta"], per["etiqueta"]), (per["anterior"][1], per["anterior"][2])]
    else:
        cortes = [(h, e) for _, h, e in per["columnas"]]
    movs = [movimientos(conn, None, h) for h, _ in cortes]
    todas = cuentas(conn)
    n = len(cortes)
    base = moneda_base(conn)

    def val(c):
        return [natural(c["tipo"], *m.get(c["id"], (0, 0, 0))[:2]) for m in movs]

    link = lambda c: f"/cuentas/{c['id']}?hasta={per['hasta']}"
    inf = Informe("Estado de situación financiera (Balance general)",
                  f"Al cierre de: {', '.join(e for _, e in cortes)} · cifras en {base}",
                  [f"Al {datetime.strptime(h, '%Y-%m-%d'):%d/%m/%Y}" for h, _ in cortes])
    inf.fila("ACTIVO", estilo="seccion")
    inf.fila("Activo corriente", estilo="subseccion")
    ac = _bloque(inf, todas, "activo", "corriente", val, n, ocultar_ceros, link, 2)
    inf.fila("Total activo corriente", ac, "total")
    inf.fila("Activo no corriente", estilo="subseccion")
    anc = _bloque(inf, todas, "activo", "no_corriente", val, n, ocultar_ceros, link, 2)
    inf.fila("Total activo no corriente", anc, "total")
    activo = [r2(a + b) for a, b in zip(ac, anc)]
    inf.fila("TOTAL ACTIVO", activo, "gran_total")
    inf.fila("PASIVO", estilo="seccion")
    inf.fila("Pasivo corriente", estilo="subseccion")
    pc = _bloque(inf, todas, "pasivo", "corriente", val, n, ocultar_ceros, link, 2)
    inf.fila("Total pasivo corriente", pc, "total")
    inf.fila("Pasivo no corriente", estilo="subseccion")
    pnc = _bloque(inf, todas, "pasivo", "no_corriente", val, n, ocultar_ceros, link, 2)
    inf.fila("Total pasivo no corriente", pnc, "total")
    pasivo = [r2(a + b) for a, b in zip(pc, pnc)]
    inf.fila("TOTAL PASIVO", pasivo, "gran_total")
    inf.fila("PATRIMONIO", estilo="seccion")
    acum_rol = cuenta_por_rol(conn, "resultados_acum")["id"]
    previos = [resultado(conn, None, dia_antes(inicio_anio(h))) for h, _ in cortes]
    ejercicio = [resultado(conn, inicio_anio(h), h) for h, _ in cortes]

    def val_pat(c):
        v = val(c)
        if c["id"] == acum_rol:
            v = [a + b for a, b in zip(v, previos)]
        return v

    pat = _bloque(inf, todas, "patrimonio", "patrimonio", val_pat, n, ocultar_ceros, link, 1)
    inf.fila("Resultado del ejercicio (año en curso)", ejercicio, "normal", 1)
    patrimonio = [r2(a + b) for a, b in zip(pat, ejercicio)]
    inf.fila("TOTAL PATRIMONIO", patrimonio, "gran_total")
    tot = [r2(a + b) for a, b in zip(pasivo, patrimonio)]
    inf.fila("TOTAL PASIVO + PATRIMONIO", tot, "gran_total")
    descuadre = [r2(a - b) for a, b in zip(activo, tot)]
    if any(abs(x) > 0.009 for x in descuadre):
        inf.fila("⚠ Diferencia (debería ser 0)", descuadre, "alerta")
    if per["vista"] == "comparar":
        inf.con_variacion()
    datos = {"ac": ac, "anc": anc, "activo": activo, "pc": pc, "pnc": pnc, "pasivo": pasivo,
             "patrimonio": patrimonio, "cortes": cortes}
    return inf, datos


def _flujo_columna(conn, desde, hasta, todas_por_id, efectivo_ids, dif_id):
    """Método directo: cada movimiento de caja se reparte entre las cuentas de la contrapartida."""
    asientos = {}
    q = ("SELECT l.asiento_id, l.cuenta_id, l.debe - l.haber AS neto FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
         " WHERE a.anulado = 0 AND a.fecha >= ? AND a.fecha <= ?")
    for f in conn.execute(q, (desde, hasta)):
        asientos.setdefault(f["asiento_id"], []).append((f["cuenta_id"], f["neto"]))
    aportes = {}
    for lineas in asientos.values():
        caja = sum(n for c, n in lineas if c in efectivo_ids)
        if abs(caja) < 0.0001:
            continue
        otras = [(c, n) for c, n in lineas if c not in efectivo_ids]
        for c, n in otras:
            aportes[c] = aportes.get(c, 0) - n
    return aportes


def informe_flujo(conn, per):
    cols = per["columnas"]
    todas = cuentas(conn)
    por_id = {c["id"]: c for c in todas}
    efectivo_ids = {c["id"] for c in todas if c["es_efectivo"] and not c["es_grupo"]}
    dif_id = cuenta_por_rol(conn, "dif_cambio")["id"]
    base = moneda_base(conn)
    aportes = [_flujo_columna(conn, d, h, por_id, efectivo_ids, dif_id) for d, h, _ in cols]
    n = len(cols)

    def saldo_caja(hasta):
        m = movimientos(conn, None, hasta)
        return r2(sum(m.get(i, (0, 0, 0))[0] - m.get(i, (0, 0, 0))[1] for i in efectivo_ids))

    iniciales = [saldo_caja(dia_antes(d)) for d, _, _ in cols]
    finales = [saldo_caja(h) for _, h, _ in cols]
    inf = Informe("Estado de flujos de efectivo", f"{per['etiqueta']} · método directo · cifras en {base}",
                  [c[2] for c in cols])
    inf.fila("Efectivo al inicio del período", iniciales, "total")
    netos = []
    for clave, titulo in (("operacion", "Actividades de operación"), ("inversion", "Actividades de inversión"),
                          ("financiacion", "Actividades de financiación")):
        inf.fila(titulo, estilo="seccion")
        grupos = {}
        for i, ap in enumerate(aportes):
            for cid, v in ap.items():
                c = por_id[cid]
                if cid == dif_id or c["flujo"] != clave:
                    continue
                padre = por_id.get(c["padre_id"]) if c["padre_id"] else None
                nombre = padre["nombre"] if padre else c["nombre"]
                orden = padre["codigo"] if padre else c["codigo"]
                g = grupos.setdefault(nombre, {"orden": orden, "v": [0.0] * n, "cuentas": {}})
                g["v"][i] += v
                g["cuentas"].setdefault(c["nombre"], [0.0] * n)[i] += v
        total = [0.0] * n
        for nombre, g in sorted(grupos.items(), key=lambda x: x[1]["orden"]):
            if all(abs(x) < 0.005 for x in g["v"]):
                continue
            entra_sale = "cobros / entradas" if sum(g["v"]) >= 0 else "pagos / salidas"
            inf.fila(f"{nombre} ({entra_sale})", [r2(x) for x in g["v"]], "grupo", 1)
            if len(g["cuentas"]) > 1:
                for cn, cv in sorted(g["cuentas"].items()):
                    if any(abs(x) >= 0.005 for x in cv):
                        inf.fila(cn, [r2(x) for x in cv], "normal", 2)
            total = [a + b for a, b in zip(total, g["v"])]
        inf.fila(f"Flujo neto de {titulo.split(' de ')[1]}", [r2(x) for x in total], "total")
        netos.append([r2(x) for x in total])
    cambio = [r2(ap.get(dif_id, 0)) for ap in aportes]
    if any(abs(x) > 0.004 for x in cambio):
        inf.fila("Efecto de la variación de la tasa de cambio", cambio, "total")
    variacion = [r2(f - i) for f, i in zip(finales, iniciales)]
    inf.fila("AUMENTO (DISMINUCIÓN) NETO DEL EFECTIVO", variacion, "resultado")
    inf.fila("Efectivo al final del período", finales, "gran_total")
    explicado = [r2(sum(x)) for x in zip(*netos)] if netos else [0] * n
    explicado = [r2(a + b) for a, b in zip(explicado, cambio)]
    falta = [r2(v - e) for v, e in zip(variacion, explicado)]
    if any(abs(x) > 0.02 for x in falta):
        inf.fila("⚠ Diferencia sin explicar", falta, "alerta")
    if per["vista"] == "comparar":
        inf.con_variacion()
    return inf


def informe_patrimonio(conn, per):
    desde, hasta = per["desde"], per["hasta"]
    base = moneda_base(conn)
    todas = [c for c in cuentas(conn) if c["tipo"] == "patrimonio" and not c["es_grupo"]]
    ini = movimientos(conn, None, dia_antes(desde))
    mov = movimientos(conn, desde, hasta)
    fin = movimientos(conn, None, hasta)
    acum = cuenta_por_rol(conn, "resultados_acum")["id"]
    inf = Informe("Estado de cambios en el patrimonio", f"{per['etiqueta']} · cifras en {base}",
                  ["Saldo inicial", "Aumentos", "Disminuciones", "Saldo final"])
    tot = [0.0] * 4
    for c in todas:
        si = natural("patrimonio", *ini.get(c["id"], (0, 0, 0))[:2])
        d, h, _ = mov.get(c["id"], (0, 0, 0))
        sf = natural("patrimonio", *fin.get(c["id"], (0, 0, 0))[:2])
        aum, dis = h, d
        if c["id"] == acum:
            prev_i = resultado(conn, None, dia_antes(inicio_anio(desde)))
            prev_f = resultado(conn, None, dia_antes(inicio_anio(hasta)))
            si += prev_i
            sf += prev_f
            traspaso = prev_f - prev_i
            if traspaso >= 0:
                aum += traspaso
            else:
                dis -= traspaso
        if all(abs(x) < 0.005 for x in (si, aum, dis, sf)):
            continue
        v = [r2(si), r2(aum), r2(dis), r2(sf)]
        inf.fila(c["nombre"], v, link=f"/cuentas/{c['id']}?desde={desde}&hasta={hasta}")
        tot = [a + b for a, b in zip(tot, v)]
    re_i = resultado(conn, inicio_anio(desde), dia_antes(desde)) if desde[5:] != "01-01" else 0
    re_f = resultado(conn, inicio_anio(hasta), hasta)
    del_periodo = resultado(conn, desde, hasta)
    traspasado = r2(re_i + del_periodo - re_f)  # lo que pasó a resultados acumulados al cambiar de año
    aum = del_periodo if del_periodo > 0 else 0
    dis = (-del_periodo if del_periodo < 0 else 0) + traspasado
    v = [r2(re_i), r2(aum), r2(dis), r2(re_f)]
    inf.fila("Resultado del ejercicio", v)
    tot = [a + b for a, b in zip(tot, v)]
    inf.fila("TOTAL PATRIMONIO", [r2(x) for x in tot], "gran_total")
    inf.nota = ("Aumentos = aportes y ganancias; disminuciones = retiros y pérdidas. "
                "Al empezar un año nuevo, el resultado del año anterior pasa a Resultados acumulados.")
    return inf


def informe_por_tipo(conn, per, tipo, con_total=True):
    """Informe de gastos o de ingresos, agrupado y desglosado."""
    base = moneda_base(conn)
    if per["vista"] == "evolucion":
        cols = per["columnas"]
    else:
        cols = [(per["desde"], per["hasta"], per["etiqueta"])]
    movs = [movimientos(conn, d, h) for d, h, _ in cols]
    todas = cuentas(conn)
    n = len(cols)

    def val(c):
        return [natural(c["tipo"], *m.get(c["id"], (0, 0, 0))[:2]) for m in movs]

    link = _link_mayor(per["desde"], per["hasta"])
    nombre = "gastos" if tipo == "gasto" else "ingresos"
    inf = Informe(f"Informe de {nombre} por grupo y cuenta", f"{per['etiqueta']} · cifras en {base}",
                  [c[2] for c in cols])
    total = [0.0] * n
    for clave, titulo in SECCIONES[tipo]:
        if not any(c["tipo"] == tipo and c["seccion"] == clave for c in todas):
            continue
        pos = len(inf.filas)
        inf.fila(titulo, estilo="seccion")
        sub = _bloque(inf, todas, tipo, clave, val, n, True, link)
        if len(inf.filas) == pos + 1:
            inf.filas.pop()
            continue
        inf.fila(f"Total {titulo.lower()}", sub, "total")
        total = [a + b for a, b in zip(total, sub)]
    total = [r2(x) for x in total]
    inf.fila(f"TOTAL {nombre.upper()}", total, "gran_total")
    if not con_total:
        inf.fila("% cambio", _cambio(total), "pct", 1, fmt="p")
        return inf
    if n > 1:
        _agregar_total(inf)
    gran = inf.filas[-1]["valores"][-1] if inf.filas[-1]["valores"] else 0
    inf.columnas.append("% del total")
    inf.formatos = inf.formatos + ["p"]
    for f in inf.filas:
        if f["valores"]:
            f["valores"].append((f["valores"][-1] / gran) if abs(gran) > 0.004 else None)

    signo = "l.debe - l.haber" if tipo == "gasto" else "l.haber - l.debe"
    q = (f"SELECT COALESCE(t.nombre, '(sin indicar)') AS tercero, t.tipo AS tt, SUM({signo}) AS v, COUNT(*) AS n"
         " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas c ON c.id = l.cuenta_id"
         " LEFT JOIN terceros t ON t.id = l.tercero_id"
         " WHERE a.anulado = 0 AND c.tipo = ? AND a.fecha >= ? AND a.fecha <= ?"
         " GROUP BY l.tercero_id ORDER BY v DESC")
    quien = "proveedor / beneficiario" if tipo == "gasto" else "cliente / pagador"
    por_t = Informe(f"{nombre.capitalize()} por {quien}", per["etiqueta"],
                    ["Tipo", "Movimientos", "Importe", "% del total"], ["t", "e", "n", "p"])
    for f in conn.execute(q, (tipo, per["desde"], per["hasta"])):
        if abs(f["v"] or 0) < 0.005:
            continue
        por_t.fila(f["tercero"], [f["tt"] or "", f["n"], r2(f["v"]), (f["v"] / gran) if abs(gran) > 0.004 else None])

    q2 = ("SELECT l.moneda, SUM(l.importe_orig) o, SUM(l.debe - l.haber) v"
          " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas c ON c.id = l.cuenta_id"
          " WHERE a.anulado = 0 AND c.tipo = ? AND a.fecha >= ? AND a.fecha <= ? GROUP BY l.moneda")
    por_m = Informe(f"{nombre.capitalize()} según la moneda en que se hicieron", per["etiqueta"],
                    ["Importe en su moneda", f"Equivale en {base}", "% del total"], ["n", "n", "p"])
    s_ = 1 if tipo == "gasto" else -1
    for f in conn.execute(q2, (tipo, per["desde"], per["hasta"])):
        v = s_ * (f["v"] or 0)
        if abs(v) < 0.005 and abs(f["o"] or 0) < 0.005:
            continue
        por_m.fila(f"En {f['moneda']}", [r2(s_ * (f["o"] or 0)), r2(v), (v / gran) if abs(gran) > 0.004 else None])
    return inf, por_t, por_m


def informe_balanza(conn, per):
    desde, hasta = per["desde"], per["hasta"]
    base = moneda_base(conn)
    ini = movimientos(conn, None, dia_antes(desde))
    mov = movimientos(conn, desde, hasta)
    inf = Informe("Balanza de comprobación", f"{per['etiqueta']} · cifras en {base}",
                  ["Saldo inicial", "Debe", "Haber", "Saldo final"])
    td = th = 0
    for c in cuentas(conn):
        if c["es_grupo"]:
            continue
        di, hi, _ = ini.get(c["id"], (0, 0, 0))
        d, h, _ = mov.get(c["id"], (0, 0, 0))
        si = natural(c["tipo"], di, hi)
        sf = natural(c["tipo"], di + d, hi + h)
        if all(abs(x) < 0.005 for x in (si, d, h, sf)):
            continue
        td += d
        th += h
        inf.fila(f"{c['codigo']}  {c['nombre']}", [r2(si), r2(d), r2(h), r2(sf)],
                 link=f"/cuentas/{c['id']}?desde={desde}&hasta={hasta}")
    inf.fila("TOTALES", [None, r2(td), r2(th), None], "gran_total")
    if abs(td - th) > 0.009:
        inf.fila("⚠ Debe y haber no coinciden", [None, r2(td - th), None, None], "alerta")
    inf.nota = "Saldos con su signo natural: activos y gastos en positivo cuando son deudores; pasivos, patrimonio e ingresos en positivo cuando son acreedores."
    return inf


def saldos_terceros(conn, lado, hasta=None, tipo_tercero=None):
    """lado 'cobrar' (cuentas de activo por tercero) o 'pagar' (pasivo por tercero)."""
    hasta = hasta or hoy()
    tipo_c = "activo" if lado == "cobrar" else "pasivo"
    q = ("SELECT t.id tid, t.nombre, t.tipo tt, c.id cid, c.nombre cuenta, c.moneda cm,"
         " SUM(l.debe - l.haber) neto, SUM(l.importe_orig) orig"
         " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas c ON c.id = l.cuenta_id"
         " JOIN terceros t ON t.id = l.tercero_id"
         " WHERE a.anulado = 0 AND c.tipo = ? AND c.por_tercero = 1 AND c.es_efectivo = 0 AND a.fecha <= ?")
    p = [tipo_c, hasta]
    if tipo_tercero:
        q += " AND t.tipo = ?"
        p.append(tipo_tercero)
    q += " GROUP BY t.id, c.id ORDER BY t.nombre, c.codigo"
    signo = 1 if lado == "cobrar" else -1
    terceros = {}
    for f in conn.execute(q, p):
        saldo = r2(signo * f["neto"])
        if abs(saldo) < 0.005 and abs(f["orig"] or 0) < 0.005:
            continue
        t = terceros.setdefault(f["tid"], {"id": f["tid"], "nombre": f["nombre"], "tipo": f["tt"], "saldo": 0,
                                           "CUP": 0, "USD": 0, "cuentas": [], "tramos": [0] * 5})
        t["saldo"] += saldo
        if f["cm"]:
            t[f["cm"]] += signo * (f["orig"] or 0)
        t["cuentas"].append({"nombre": f["cuenta"], "saldo": saldo, "moneda": f["cm"],
                             "orig": r2(signo * (f["orig"] or 0))})
    base = moneda_base(conn)
    for d in documentos(conn, lado, solo_pendientes=True):
        if d["fecha"] > hasta or d["tercero_id"] not in terceros:
            continue
        pend_base = convertir(d["pendiente"], d["moneda"], base, d["tasa"])
        dias = (datetime.strptime(hasta, "%Y-%m-%d") - datetime.strptime(d["vencimiento"] or d["fecha"], "%Y-%m-%d")).days
        tramo = 0 if dias <= 0 else 1 if dias <= 30 else 2 if dias <= 60 else 3 if dias <= 90 else 4
        terceros[d["tercero_id"]]["tramos"][tramo] += pend_base
    lista = sorted(terceros.values(), key=lambda t: -abs(t["saldo"]))
    for t in lista:
        t["saldo"] = r2(t["saldo"])
        t["sin_factura"] = r2(t["saldo"] - sum(t["tramos"]))
        t["tramos"] = [r2(x) for x in t["tramos"]]
    return lista


def informe_terceros(conn, lado, hasta=None, tipo_tercero=None):
    base = moneda_base(conn)
    lista = saldos_terceros(conn, lado, hasta, tipo_tercero)
    titulo = "Cuentas por cobrar (lo que me deben)" if lado == "cobrar" else "Cuentas por pagar (lo que debo)"
    hasta = hasta or hoy()
    inf = Informe(titulo, f"Saldos al {datetime.strptime(hasta, '%Y-%m-%d'):%d/%m/%Y} · cifras en {base}"
                  + (f" · solo {tipo_tercero}" if tipo_tercero else ""),
                  ["Tipo", "En CUP", "En USD", f"Total {base}", "Por vencer", "Vencido 1-30 días",
                   "31-60 días", "61-90 días", "Más de 90", "Sin factura"],
                  ["t", "n", "n", "n", "n", "n", "n", "n", "n", "n"])
    tot = [0.0] * 9
    for t in lista:
        v = [t["CUP"], t["USD"], t["saldo"]] + t["tramos"] + [t["sin_factura"]]
        inf.fila(t["nombre"], [t["tipo"]] + [r2(x) for x in v], "grupo", 0, link=f"/terceros/{t['id']}")
        if len(t["cuentas"]) > 1:
            for c in t["cuentas"]:
                inf.fila(c["nombre"], ["", c["orig"] if c["moneda"] == "CUP" else None,
                                       c["orig"] if c["moneda"] == "USD" else None, c["saldo"]], "normal", 1)
        tot = [a + b for a, b in zip(tot, v)]
    inf.fila("TOTAL", [""] + [r2(x) for x in tot], "gran_total")
    inf.nota = ("Por vencer / vencido se calcula con las facturas pendientes (según su fecha de vencimiento). "
                "\"Sin factura\" son préstamos, anticipos u otros saldos anotados sin factura.")
    return inf, lista


def indicadores(conn, per):
    hasta = per["hasta"]
    _, d = informe_balance(conn, dict(per, vista="simple", columnas=[(per["desde"], hasta, per["etiqueta"])]))
    movs = movimientos(conn, per["desde"], hasta)
    todas = cuentas(conn)

    def suma(filtro):
        s = 0
        for c in todas:
            if not c["es_grupo"] and filtro(c):
                m = movs.get(c["id"], (0, 0, 0))
                s += natural(c["tipo"], m[0], m[1])
        return s

    al_cierre = movimientos(conn, None, hasta)

    def saldo(filtro):
        s = 0
        for c in todas:
            if not c["es_grupo"] and filtro(c):
                m = al_cierre.get(c["id"], (0, 0, 0))
                s += natural(c["tipo"], m[0], m[1])
        return s

    ventas = suma(lambda c: c["tipo"] == "ingreso" and c["seccion"] == "operacion")
    costo = suma(lambda c: c["tipo"] == "gasto" and c["seccion"] == "costo")
    gastos_todos = suma(lambda c: c["tipo"] == "gasto")
    neto = resultado(conn, per["desde"], hasta)
    oper = ventas - costo - suma(lambda c: c["tipo"] == "gasto" and c["seccion"] == "operacion")
    ac, pc, activo, pasivo, patr = d["ac"][0], d["pc"][0], d["activo"][0], d["pasivo"][0], d["patrimonio"][0]
    inventario = saldo(lambda c: c["codigo"].startswith("1.3"))
    efectivo = saldo(lambda c: c["es_efectivo"])
    cxc = saldo(lambda c: c["rol"] in ("cxc_CUP", "cxc_USD"))
    cxp = saldo(lambda c: c["rol"] in ("cxp_CUP", "cxp_USD"))
    dias = (datetime.strptime(hasta, "%Y-%m-%d") - datetime.strptime(per["desde"], "%Y-%m-%d")).days + 1

    def div(a, b):
        return (a / b) if abs(b) > 0.004 else None

    inf = Informe("Indicadores financieros", f"{per['etiqueta']}",
                  ["Valor", "Qué significa"], ["x", "t"])
    filas = [
        ("Liquidez", None, None, "seccion"),
        ("Liquidez corriente", ("r", div(ac, pc)), "Activo corriente ÷ pasivo corriente. Más de 1 = puedes pagar tus deudas de corto plazo.", None),
        ("Prueba ácida", ("r", div(ac - inventario, pc)), "Igual que la anterior pero sin contar inventario.", None),
        ("Efectivo sobre deudas a corto plazo", ("r", div(efectivo, pc)), "Cuánto del pasivo corriente cubre el dinero que ya tienes.", None),
        ("Capital de trabajo", ("n", ac - pc), "Activo corriente menos pasivo corriente.", None),
        ("Endeudamiento", None, None, "seccion"),
        ("Endeudamiento total", ("p", div(pasivo, activo)), "Qué parte de lo que tienes está financiada con deudas.", None),
        ("Deuda sobre patrimonio", ("r", div(pasivo, patr)), "Deudas ÷ lo que es tuyo. Más de 1 = debes más de lo que es tuyo.", None),
        ("Rentabilidad", None, None, "seccion"),
        ("Margen bruto", ("p", div(ventas - costo, ventas)), "Lo que queda de cada venta después del costo.", None),
        ("Margen de operación", ("p", div(oper, ventas)), "Lo que queda después de costo y gastos de operación.", None),
        ("Margen neto", ("p", div(neto, ventas)), "Ganancia final por cada peso/dólar vendido.", None),
        ("Rentabilidad sobre activos (ROA)", ("p", div(neto, activo)), "Ganancia del período ÷ total de activos.", None),
        ("Rentabilidad sobre patrimonio (ROE)", ("p", div(neto, patr)), "Ganancia del período ÷ patrimonio.", None),
        ("Actividad", None, None, "seccion"),
        ("Días promedio de cobro", ("d", div(cxc * dias, ventas)), "Cuántos días tardan en pagarte, en promedio.", None),
        ("Días promedio de pago", ("d", div(cxp * dias, costo + gastos_todos)), "Cuántos días tardas tú en pagar, en promedio.", None),
    ]
    for etq, valor, expl, estilo in filas:
        if estilo:
            inf.fila(etq, estilo="seccion")
        else:
            inf.fila(etq, [valor, expl])
    return inf


# ---------------------------------------------------------------- tasa de cambio: revaluación

def calcular_revaluacion(conn, fecha, tasa):
    base = moneda_base(conn)
    movs = movimientos(conn, None, fecha)
    out = []
    for c in cuentas(conn):
        if c["es_grupo"] or not c["moneda"] or c["moneda"] == base:
            continue
        d, h, o = movs.get(c["id"], (0, 0, 0))
        actual = r2(d - h)
        objetivo = r2(convertir(o, c["moneda"], base, tasa))
        dif = r2(objetivo - actual)
        if abs(dif) >= 0.01:
            out.append({"cuenta": c, "orig": r2(o), "actual": actual, "objetivo": objetivo, "dif": dif})
    return out


def registrar_revaluacion(conn, fecha, tasa):
    filas = calcular_revaluacion(conn, fecha, tasa)
    if not filas:
        raise ErrorContable("No hay nada que ajustar: los saldos ya están a esa tasa.")
    base = moneda_base(conn)
    dif_id = cuenta_por_rol(conn, "dif_cambio")["id"]
    lineas = []
    for f in filas:
        c = f["cuenta"]
        if c["por_tercero"]:
            # se reparte por tercero para que los saldos por persona sigan cuadrando
            q = ("SELECT l.tercero_id, SUM(l.debe - l.haber) b, SUM(l.importe_orig) o FROM lineas l"
                 " JOIN asientos a ON a.id = l.asiento_id WHERE a.anulado = 0 AND l.cuenta_id = ? AND a.fecha <= ?"
                 " GROUP BY l.tercero_id")
            for t in conn.execute(q, (c["id"], fecha)):
                dif = r2(convertir(t["o"] or 0, c["moneda"], base, tasa) - (t["b"] or 0))
                if abs(dif) >= 0.01:
                    lineas.append({"cuenta_id": c["id"], "importe": 0, "base": dif, "moneda": c["moneda"],
                                   "tercero_id": t["tercero_id"], "descripcion": "Ajuste por tasa de cambio"})
        else:
            lineas.append({"cuenta_id": c["id"], "importe": 0, "base": f["dif"], "moneda": c["moneda"],
                           "descripcion": "Ajuste por tasa de cambio"})
    total = r2(sum(l["base"] for l in lineas))
    lineas.append({"cuenta_id": dif_id, "importe": -total, "base": -total, "moneda": base,
                   "descripcion": "Ganancia (pérdida) por tasa de cambio"})
    return crear_asiento(conn, fecha, f"Ajuste de saldos en moneda extranjera a tasa {tasa:,.2f} CUP/USD",
                         lineas, origen="ajuste_cambio", tasa=tasa)


# ---------------------------------------------------------------- panel

def resumen_panel(conn):
    t = date.today()
    base = moneda_base(conn)
    desde, hasta, etq = rango_mes(t.year, t.month)
    todas = cuentas(conn)
    mov = movimientos(conn, desde, hasta)
    # ingresos = solo lo vendido (ingresos de operación); gastos = todo lo demás (costos, gastos, pérdidas por cambio…)
    ing = sum(natural("ingreso", *mov.get(c["id"], (0, 0, 0))[:2]) for c in todas
              if c["tipo"] == "ingreso" and c["seccion"] == "operacion")
    gas = ing - resultado(conn, desde, hasta)
    al_dia = movimientos(conn)
    cajas = []
    for c in todas:
        if c["es_efectivo"] and not c["es_grupo"] and c["activa"]:
            d, h, o = al_dia.get(c["id"], (0, 0, 0))
            cajas.append({"id": c["id"], "nombre": c["nombre"], "moneda": c["moneda"] or base,
                          "orig": r2(o) if c["moneda"] else r2(d - h), "base": r2(d - h)})
    cobrar = saldos_terceros(conn, "cobrar")
    pagar = saldos_terceros(conn, "pagar")
    vencidas_c = [d for d in documentos(conn, "cobrar", solo_pendientes=True) if d["vencida"]]
    vencidas_p = [d for d in documentos(conn, "pagar", solo_pendientes=True) if d["vencida"]]
    # últimos 12 meses
    meses = []
    y, m = t.year, t.month
    for _ in range(12):
        meses.append((y, m))
        y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    meses.reverse()
    q = ("SELECT substr(a.fecha,1,7) ym, c.tipo, SUM(CASE WHEN c.tipo='ingreso' THEN l.haber-l.debe ELSE l.debe-l.haber END) v"
         " FROM lineas l JOIN asientos a ON a.id=l.asiento_id JOIN cuentas c ON c.id=l.cuenta_id"
         " WHERE a.anulado=0 AND c.tipo IN ('ingreso','gasto') AND a.fecha >= ? GROUP BY ym, c.tipo")
    datos = {}
    for f in conn.execute(q, (f"{meses[0][0]}-{meses[0][1]:02d}-01",)):
        datos[(f["ym"], f["tipo"])] = f["v"] or 0
    grafico = [{"etq": f"{MESES_CORTOS[mm - 1]}", "anio": yy,
                "ing": r2(datos.get((f"{yy}-{mm:02d}", "ingreso"), 0)),
                "gas": r2(datos.get((f"{yy}-{mm:02d}", "gasto"), 0))} for yy, mm in meses]
    top = conn.execute(
        "SELECT c.id, c.nombre, SUM(l.debe-l.haber) v FROM lineas l JOIN asientos a ON a.id=l.asiento_id"
        " JOIN cuentas c ON c.id=l.cuenta_id WHERE a.anulado=0 AND c.tipo='gasto' AND a.fecha>=? AND a.fecha<=?"
        " GROUP BY c.id HAVING v > 0.004 ORDER BY v DESC LIMIT 6", (desde, hasta)).fetchall()
    return {"mes": etq, "ingresos": r2(ing), "gastos": r2(gas), "resultado": r2(ing - gas), "cajas": cajas,
            "efectivo": r2(sum(c["base"] for c in cajas)),
            "cobrar": r2(sum(x["saldo"] for x in cobrar)), "pagar": r2(sum(x["saldo"] for x in pagar)),
            "vencidas_c": vencidas_c, "vencidas_p": vencidas_p, "grafico": grafico,
            "top_gastos": [dict(x) for x in top], "anio": resultado(conn, f"{t.year}-01-01", t.isoformat()),
            "desde": desde, "hasta": hasta}


# ---------------------------------------------------------------- vista tipo "terminal" (columnas por período)

TRIM_CORTO = ["T1", "T2", "T3", "T4"]


def _fecha(x):
    return datetime.strptime(x, "%Y-%m-%d").date()


def columnas_terminal(conn, periodo="anual", n=6, hasta=None):
    """Columnas de la más antigua a la más reciente, como en TIKR.
    periodo: anual, trimestral, mensual o ltm (últimos 12 meses a cada cierre de trimestre)."""
    h = _fecha(hasta) if hasta else date.today()
    cols = []
    if periodo == "trimestral":
        y, q = h.year, (h.month - 1) // 3 + 1
        for _ in range(n):
            d, f, _e = rango_trimestre(y, q)
            cols.append((d, min(f, h.isoformat()), f"{TRIM_CORTO[q - 1]} {str(y)[2:]}"))
            y, q = (y - 1, 4) if q == 1 else (y, q - 1)
    elif periodo == "mensual":
        y, m = h.year, h.month
        for _ in range(n):
            d, f, _e = rango_mes(y, m)
            cols.append((d, min(f, h.isoformat()), f"{MESES_CORTOS[m - 1]} {str(y)[2:]}"))
            y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    elif periodo == "ltm":
        fin = h
        for i in range(n):
            try:
                ini = fin.replace(year=fin.year - 1) + timedelta(days=1)
            except ValueError:
                ini = fin - timedelta(days=364)
            cols.append((ini.isoformat(), fin.isoformat(), f"12m a {fin:%d/%m/%y}"))
            q_ini = date(fin.year, 3 * ((fin.month - 1) // 3) + 1, 1)
            fin = q_ini - timedelta(days=1)  # cierre del trimestre anterior
    else:
        for y in range(h.year, h.year - n, -1):
            fin = min(date(y, 12, 31), h)
            etq = str(y) if fin == date(y, 12, 31) else f"{y} (al {fin:%d/%m})"
            cols.append((f"{y}-01-01", fin.isoformat(), etq))
    cols.reverse()
    primera = conn.execute("SELECT MIN(fecha) FROM asientos").fetchone()[0]
    if primera:
        utiles = [c for c in cols if c[1] >= primera]
        cols = utiles or cols[-1:]
    else:
        cols = cols[-1:]
    return cols


def _cambio(serie):
    out = [None]
    for prev, cur in zip(serie, serie[1:]):
        out.append(((cur - prev) / abs(prev)) if abs(prev) > 0.004 else None)
    return out


def per_terminal(cols, etiqueta=""):
    return {"columnas": cols, "vista": "evolucion", "desde": cols[0][0], "hasta": cols[-1][1],
            "etiqueta": etiqueta or f"{cols[0][2]} a {cols[-1][2]}", "anterior": cols[0], "modo": "rango",
            "comparar_con": "anterior", "anio": int(cols[-1][1][:4]), "mes": int(cols[-1][1][5:7]),
            "trimestre": 1, "detalle": "meses"}


def informe_resultados_terminal(conn, cols, detalle=True):
    """Estado de resultados con años/trimestres/meses en columnas y filas de % cambio y % margen."""
    movs = [movimientos(conn, d, h) for d, h, _ in cols]
    todas = cuentas(conn)
    n = len(cols)
    base = moneda_base(conn)
    inf = Informe("Estado de resultados", f"Cifras en {base}", [c[2] for c in cols])
    grupos = {c["id"]: c for c in todas if c["es_grupo"]}

    def val(c, signo):
        return [signo * natural(c["tipo"], *m.get(c["id"], (0, 0, 0))[:2]) for m in movs]

    def seccion(tipo, sec, signo):
        hojas = [c for c in todas if c["tipo"] == tipo and c["seccion"] == sec and not c["es_grupo"]]
        total = [0.0] * n
        orden = []
        por_grupo = {}
        for c in hojas:
            v = val(c, signo)
            if all(abs(x) < 0.005 for x in v):
                continue
            g = c["padre_id"] or 0
            if g not in por_grupo:
                por_grupo[g] = []
                orden.append(g)
            por_grupo[g].append((c, v))
            total = [a + b for a, b in zip(total, v)]
        for g in sorted(orden, key=lambda x: grupos[x]["codigo"] if x in grupos else ""):
            filas = por_grupo[g]
            sub = [r2(sum(v[i] for _, v in filas)) for i in range(n)]
            if g in grupos:
                inf.fila(grupos[g]["nombre"], sub, "grupo" if detalle else "normal", 0, codigo=grupos[g]["codigo"])
            if detalle or g not in grupos:
                for c, v in filas:
                    inf.fila(c["nombre"], [r2(x) for x in v], "normal", 1 if g in grupos else 0,
                             link=f"/cuentas/{c['id']}?desde={cols[0][0]}&hasta={cols[-1][1]}", codigo=c["codigo"])
        return [r2(x) for x in total]

    def pct(etq, serie):
        inf.fila(etq, serie, "pct", 1, fmt="p")

    def margen(serie):
        return [(s / i) if abs(i) > 0.004 else None for s, i in zip(serie, ing)]

    ing = seccion("ingreso", "operacion", 1)
    inf.fila("Total ingresos de operación", ing, "total")
    pct("% cambio", _cambio(ing))
    costo = seccion("gasto", "costo", -1)
    if any(abs(x) > 0.004 for x in costo):
        inf.fila("Total costo de ventas", costo, "total")
    bruta = [r2(a + b) for a, b in zip(ing, costo)]
    inf.fila("Utilidad bruta", bruta, "resultado")
    pct("% cambio", _cambio(bruta))
    pct("% margen bruto", margen(bruta))
    gop = seccion("gasto", "operacion", -1)
    inf.fila("Total gastos de operación", gop, "total")
    oper = [r2(a + b) for a, b in zip(bruta, gop)]
    inf.fila("Resultado de operación", oper, "resultado")
    pct("% cambio", _cambio(oper))
    pct("% margen de operación", margen(oper))
    oi = seccion("ingreso", "otros", 1)
    og = seccion("gasto", "otros", -1)
    otros = [r2(a + b) for a, b in zip(oi, og)]
    if any(abs(x) > 0.004 for x in otros + oi + og):
        inf.fila("Total otros ingresos y gastos", otros, "total")
    antes = [r2(a + b) for a, b in zip(oper, otros)]
    inf.fila("Resultado antes de impuestos", antes, "resultado")
    pct("% margen antes de impuestos", margen(antes))
    imp = seccion("gasto", "impuesto", -1)
    neto = [r2(a + b) for a, b in zip(antes, imp)]
    inf.fila("Resultado neto", neto, "gran_total")
    pct("% cambio", _cambio(neto))
    pct("% margen neto", margen(neto))
    return inf, {"neto": neto, "ingresos": ing}


def indicadores_terminal(conn, cols):
    filas = None
    valores = []
    for d, h, e in cols:
        p = {"desde": d, "hasta": h, "etiqueta": e, "vista": "simple", "columnas": [(d, h, e)], "anterior": (d, h, e)}
        inf = indicadores(conn, p)
        filas = inf.filas
        valores.append([f["valores"][0] if f["valores"] else None for f in inf.filas])
    out = Informe("Indicadores financieros", "Al cierre de cada período", [c[2] for c in cols], ["x"] * len(cols))
    for i, f in enumerate(filas or []):
        if f["estilo"] == "seccion":
            out.fila(f["etiqueta"], estilo="seccion")
        else:
            out.fila(f["etiqueta"], [v[i] for v in valores], codigo=f["valores"][1] if len(f["valores"]) > 1 else "")
    return out


# ---------------------------------------------------------------- estado de cuenta (formato de la hoja de Gabriel)

LADO_CARGOS = ("factura_cobrar", "factura_pagar", "rebaja_cobrar", "rebaja_pagar")


def _lineas_tercero(conn, lado, tercero_id=None, hasta=None):
    q = ("SELECT l.*, a.fecha, a.numero anum, a.concepto, a.referencia, a.origen, a.id aid, a.documento_id adoc"
         " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cu ON cu.id = l.cuenta_id"
         " WHERE a.anulado = 0 AND cu.por_tercero = 1 AND cu.es_efectivo = 0 AND cu.tipo = ?"
         " AND abs(l.importe_orig) > 0.0000001 AND l.tercero_id IS NOT NULL")
    p = ["activo" if lado == "cobrar" else "pasivo"]
    if tercero_id:
        q += " AND l.tercero_id = ?"
        p.append(tercero_id)
    if hasta:
        q += " AND a.fecha <= ?"
        p.append(hasta)
    return conn.execute(q + " ORDER BY a.fecha, a.numero, l.id", p).fetchall()


def estado_cuenta(conn, tercero_id, lado, desde=None, hasta=None):
    """Cargos (facturas, rebajas en negativo) a la izquierda y pagos a la derecha, separados por moneda."""
    signo = 1 if lado == "cobrar" else -1
    cargos, pagos = [], {}
    tot = {m: {"cargos": 0.0, "pagos": 0.0, "anterior": 0.0} for m in MONEDAS}
    docs = {d["id"]: d for d in documentos(conn, lado, tercero_id)}
    lineas_t = _lineas_tercero(conn, lado, tercero_id, hasta)
    cajas_de = {}  # en qué caja entró o salió el dinero de cada movimiento (una sola consulta)
    ids = sorted({l["aid"] for l in lineas_t})
    for i in range(0, len(ids), 500):
        trozo = ids[i:i + 500]
        for x in conn.execute("SELECT l.asiento_id, l.importe_orig, l.moneda, cu.nombre FROM lineas l JOIN cuentas cu"
                              " ON cu.id = l.cuenta_id WHERE cu.es_efectivo = 1 AND l.asiento_id IN (%s) ORDER BY l.id"
                              % ",".join("?" * len(trozo)), trozo):
            cajas_de.setdefault(x["asiento_id"], x)
    for l in lineas_t:
        v = signo * l["importe_orig"]
        m = l["moneda"]
        if desde and l["fecha"] < desde:
            tot[m]["anterior"] += v
            continue
        es_cargo = l["origen"] in LADO_CARGOS or (v > 0 and l["origen"] not in ("cobro", "pago"))
        if es_cargo:
            d = docs.get(l["documento_id"]) if l["origen"].startswith("factura") else None
            previo = cargos[-1] if cargos else None
            if (l["origen"].startswith("rebaja") and previo and previo["aid"] == l["aid"]
                    and previo["moneda"] == m):  # una rebaja repartida en varias facturas va en una sola línea
                previo["importe"] = r2(previo["importe"] + v)
            else:
                cargos.append({"fecha": l["fecha"], "aid": l["aid"], "moneda": m, "importe": r2(v),
                               "texto": (f"{d['numero']} · " if d and d["numero"] else "") + (d["concepto"] if d else l["concepto"]),
                               "doc": d, "rebaja": l["origen"].startswith("rebaja")})
            tot[m]["cargos"] += v
        else:
            clave = (l["aid"], m)
            if clave not in pagos:
                nota = l["referencia"] or ""
                otra = cajas_de.get(l["aid"])
                if otra and otra["moneda"] != m:
                    recibido = f"{abs(otra['importe_orig']):,.2f} {otra['moneda']}"
                    nota = f"{nota} · recibido {recibido}" if nota else \
                        f"En {'MN' if otra['moneda'] == 'CUP' else 'USD'}: {recibido}"
                elif otra:
                    nota = (nota + " · " if nota else "") + otra["nombre"]
                pagos[clave] = {"fecha": l["fecha"], "aid": l["aid"], "moneda": m, "importe": 0.0,
                                "texto": l["concepto"], "nota": nota}
            pagos[clave]["importe"] += -v
            tot[m]["pagos"] += -v
    for m in MONEDAS:
        t = tot[m]
        t["cargos"], t["pagos"], t["anterior"] = r2(t["cargos"]), r2(t["pagos"]), r2(t["anterior"])
        t["total_cargos"] = r2(t["anterior"] + t["cargos"])
        t["pendiente"] = r2(t["total_cargos"] - t["pagos"])
    lista_pagos = list(pagos.values())
    for p in lista_pagos:
        p["importe"] = r2(p["importe"])
    return {"cargos": cargos, "pagos": lista_pagos, "tot": tot, "desde": desde,
            "vencidas": [d for d in docs.values() if d["vencida"]]}


def resumen_lado(conn, lado, todos=False):
    """Una fila por persona con lo pendiente en USD y en CUP."""
    signo = 1 if lado == "cobrar" else -1
    filas = {}
    for l in _lineas_tercero(conn, lado):
        f = filas.setdefault(l["tercero_id"], {"id": l["tercero_id"], "USD": 0.0, "CUP": 0.0, "ultimo": l["fecha"]})
        f[l["moneda"]] += signo * l["importe_orig"]
        f["ultimo"] = max(f["ultimo"], l["fecha"])
    vencidas = {}
    for d in documentos(conn, lado, solo_pendientes=True):
        if d["vencida"]:
            vencidas[d["tercero_id"]] = vencidas.get(d["tercero_id"], 0) + 1
    out = []
    for f in filas.values():
        f["USD"], f["CUP"] = r2(f["USD"]), r2(f["CUP"])
        if not todos and abs(f["USD"]) < 0.005 and abs(f["CUP"]) < 0.005:
            continue
        t = conn.execute("SELECT nombre, tipo FROM terceros WHERE id = ?", (f["id"],)).fetchone()
        f.update(nombre=t["nombre"], tipo=t["tipo"], vencidas=vencidas.get(f["id"], 0))
        out.append(f)
    out.sort(key=lambda x: x["nombre"].lower())
    totales = {m: r2(sum(f[m] for f in out)) for m in MONEDAS}
    return out, totales
