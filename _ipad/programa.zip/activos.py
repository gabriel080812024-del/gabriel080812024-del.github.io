"""Activos fijos (camión, equipos, mobiliario…) y su depreciación mensual en línea recta.

- Cada activo se deprecia desde el mes siguiente a su fecha, en partes iguales: (costo − valor final) ÷ meses de vida.
  Si se cambia la vida o el valor final, lo que queda se reparte en los meses que faltan.
- Cada mes se anota:  Debe Depreciación de activos (gasto)  /  Haber Depreciación acumulada (resta del activo).
- Al venderlo o darlo de baja:  Debe Caja (precio) + Debe Depreciación acumulada  /  Haber el activo (costo),
  y la diferencia va a Ganancia o pérdida en venta de activos."""
from datetime import date, datetime

import contab as C
from contab import ErrorContable, r2


def _ym(fecha):
    return fecha[:7]


def _siguiente(ym, n=1):
    y, m = int(ym[:4]), int(ym[5:7]) + n
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    return f"{y:04d}-{m:02d}"


def mes_anterior_a_hoy():
    return _siguiente(date.today().isoformat()[:7], -1)


def nombre_mes(ym):
    return f"{C.MESES[int(ym[5:7]) - 1]} {ym[:4]}"


def cuentas_activo(conn):
    return [dict(r) for r in conn.execute(
        "SELECT * FROM cuentas WHERE codigo LIKE '1.5.%' AND es_grupo = 0 AND activa = 1 AND COALESCE(rol, '') != 'dep_acumulada'"
        " ORDER BY codigo")]


def lista(conn, incluir_bajas=True):
    q = "SELECT a.*, c.nombre cuenta FROM activos a JOIN cuentas c ON c.id = a.cuenta_id"
    if not incluir_bajas:
        q += " WHERE a.baja_fecha IS NULL"
    out = []
    for a in conn.execute(q + " ORDER BY a.baja_fecha IS NOT NULL, a.fecha, a.id"):
        out.append(resumen(conn, dict(a)))
    return out


def calendario(conn, a):
    """Mes a mes: [{mes, importe, acumulada, valor, registrado, asiento_id}] desde el mes siguiente a la fecha."""
    hechos = {r["mes"]: dict(r) for r in conn.execute("SELECT * FROM depreciaciones WHERE activo_id = ?", (a["id"],))}
    total = r2(a["costo"] - a["residual"])
    filas, acum, mes, cuota = [], 0.0, _siguiente(_ym(a["fecha"])), None
    fin_baja = _ym(a["baja_fecha"]) if a.get("baja_fecha") else None
    for i in range(a["vida_meses"]):
        if fin_baja and mes >= fin_baja:
            break
        restan = a["vida_meses"] - i
        if mes in hechos:
            imp, cuota = hechos[mes]["importe"], None
        else:
            if cuota is None:  # la cuota fija se calcula sobre lo que falta y los meses que quedan
                cuota = r2((total - acum) / restan)
            imp = min(cuota, r2(total - acum)) if restan > 1 else r2(total - acum)  # el último mes cuadra el redondeo
        acum = r2(acum + imp)
        filas.append({"mes": mes, "importe": imp, "acumulada": acum, "valor": r2(a["costo"] - acum),
                      "registrado": mes in hechos, "asiento_id": hechos.get(mes, {}).get("asiento_id")})
        mes = _siguiente(mes)
    return filas


def resumen(conn, a):
    cal = calendario(conn, a)
    hechas = [f for f in cal if f["registrado"]]
    acum = r2(sum(f["importe"] for f in hechas))
    a.update(acumulada=acum, valor=r2(a["costo"] - acum),
             cuota=r2((a["costo"] - a["residual"]) / a["vida_meses"]) if a["vida_meses"] else 0.0,
             pct=round(acum / (a["costo"] - a["residual"]) * 100) if a["costo"] - a["residual"] > 0.004 else 100,
             pendientes=[f for f in cal if not f["registrado"] and f["mes"] <= mes_anterior_a_hoy()],
             termina=cal[-1]["mes"] if cal else None, calendario=cal)
    a["estado"] = ("Vendido / de baja" if a.get("baja_fecha") else "Depreciado del todo" if a["valor"] <= a["residual"] + 0.004
                   else "Depreciándose")
    return a


def pendientes(conn, hasta=None, activo_id=None):
    """{mes: [(activo, importe)]} de la depreciación que falta anotar hasta 'hasta' (por defecto, el mes pasado)."""
    hasta = hasta or mes_anterior_a_hoy()
    out = {}
    for a in lista(conn):
        if activo_id and a["id"] != activo_id:
            continue
        for f in a["calendario"]:
            if not f["registrado"] and f["mes"] <= hasta:
                out.setdefault(f["mes"], []).append((a, f["importe"]))
    return dict(sorted(out.items()))


def registrar_pendientes(conn, hasta=None, activo_id=None):
    """Anota la depreciación que falta, un movimiento por mes (último día del mes). Los meses cerrados se saltan."""
    gasto = C.cuenta_por_rol(conn, "gasto_depreciacion")["id"]
    acum = C.cuenta_por_rol(conn, "dep_acumulada")["id"]
    hechos, saltados = [], []
    for mes, items in pendientes(conn, hasta, activo_id).items():
        fecha = C.ultimo_dia(int(mes[:4]), int(mes[5:7]))
        try:
            C.comprobar_abierto(conn, fecha)
        except ErrorContable:
            saltados.append(mes)
            continue
        lineas = []
        for a, imp in items:
            if imp <= 0.004:
                continue
            lineas.append({"cuenta_id": gasto, "importe": imp, "descripcion": a["nombre"]})
            lineas.append({"cuenta_id": acum, "importe": -imp, "descripcion": a["nombre"]})
        if not lineas:
            continue
        aid = C.crear_asiento(conn, fecha, f"Depreciación de {nombre_mes(mes).lower()}", lineas, "depreciacion")
        for a, imp in items:
            conn.execute("INSERT INTO depreciaciones (activo_id, mes, importe, asiento_id) VALUES (?, ?, ?, ?)", (a["id"], mes, imp, aid))
        hechos.append((mes, r2(sum(imp for _, imp in items))))
    return hechos, saltados


def guardar(conn, nombre, cuenta_id, fecha, costo, vida_meses, residual=0.0, nota=None, apertura=False, activo_id=None):
    nombre = " ".join((nombre or "").split())[:100]
    if not nombre:
        raise ErrorContable("Escribe qué es (por ejemplo: Camión Hino blanco).")
    if not conn.execute("SELECT 1 FROM cuentas WHERE id = ? AND codigo LIKE '1.5.%' AND es_grupo = 0", (cuenta_id,)).fetchone():
        raise ErrorContable("Elige el tipo de activo (Vehículos, Equipos, Mobiliario…).")
    if costo is None or costo <= 0:
        raise ErrorContable("Escribe lo que costó (mayor que cero).")
    residual = residual or 0.0
    if residual < 0 or residual >= costo:
        raise ErrorContable("El valor al final tiene que ser menor que lo que costó (puede ser 0).")
    if not vida_meses or not 1 <= vida_meses <= 600:
        raise ErrorContable("Escribe cuántos años dura (entre 1 mes y 50 años).")
    if activo_id:
        viejo = conn.execute("SELECT * FROM activos WHERE id = ?", (activo_id,)).fetchone()
        if not viejo:
            raise ErrorContable("Ese activo no existe.")
        hay = conn.execute("SELECT COUNT(*) FROM depreciaciones WHERE activo_id = ?", (activo_id,)).fetchone()[0]
        if hay and (abs(viejo["costo"] - costo) > 0.004 or viejo["fecha"] != fecha or viejo["cuenta_id"] != cuenta_id):
            raise ErrorContable("Este activo ya tiene depreciación anotada: no se pueden cambiar el costo, la fecha ni el tipo "
                                "(sí el nombre, los años de vida y el valor final).")
        if hay:
            acum = conn.execute("SELECT COALESCE(SUM(importe), 0) FROM depreciaciones WHERE activo_id = ?", (activo_id,)).fetchone()[0]
            ultimo = conn.execute("SELECT MAX(mes) FROM depreciaciones WHERE activo_id = ?", (activo_id,)).fetchone()[0]
            if _siguiente(_ym(fecha), vida_meses) < ultimo:
                raise ErrorContable(f"Ya tiene depreciación anotada hasta {nombre_mes(ultimo).lower()}: la vida no puede terminar antes.")
            if acum > costo - residual + 0.004:
                raise ErrorContable("Con ese valor final ya estaría depreciado de más.")
        conn.execute("UPDATE activos SET nombre = ?, cuenta_id = ?, fecha = ?, costo = ?, residual = ?, vida_meses = ?, nota = ? WHERE id = ?",
                     (nombre, cuenta_id, fecha, r2(costo), r2(residual), vida_meses, (nota or "").strip()[:300] or None, activo_id))
        return activo_id
    if apertura:  # todavía no estaba en la contabilidad: se anota como algo que ya se tenía
        C.crear_asiento(conn, fecha, f"{nombre} (ya lo tenía)", [
            {"cuenta_id": cuenta_id, "importe": r2(costo)},
            {"cuenta_id": C.cuenta_por_rol(conn, "apertura")["id"], "importe": -r2(costo)}], "saldo_inicial")
    return conn.execute("INSERT INTO activos (nombre, cuenta_id, fecha, costo, residual, vida_meses, nota, creado) VALUES (?,?,?,?,?,?,?,?)",
                        (nombre, cuenta_id, fecha, r2(costo), r2(residual), vida_meses, (nota or "").strip()[:300] or None,
                         datetime.now().isoformat(timespec="seconds"))).lastrowid


def eliminar(conn, activo_id):
    a = conn.execute("SELECT * FROM activos WHERE id = ?", (activo_id,)).fetchone()
    if not a:
        raise ErrorContable("Ese activo no existe.")
    if a["baja_asiento_id"] or conn.execute("SELECT 1 FROM depreciaciones WHERE activo_id = ?", (activo_id,)).fetchone():
        raise ErrorContable("Tiene depreciación o venta anotadas: elimina primero esos movimientos (en su ficha).")
    conn.execute("DELETE FROM activos WHERE id = ?", (activo_id,))


def dar_de_baja(conn, activo_id, fecha, precio, caja_id, tasa, nota=None):
    """Venta (precio > 0) o baja (precio 0: se rompió, se perdió). Antes se pone al día la depreciación hasta el mes anterior."""
    a = conn.execute("SELECT * FROM activos WHERE id = ?", (activo_id,)).fetchone()
    if not a:
        raise ErrorContable("Ese activo no existe.")
    if a["baja_fecha"]:
        raise ErrorContable("Este activo ya está vendido o dado de baja.")
    if fecha < a["fecha"]:
        raise ErrorContable("La venta no puede ser antes de la compra.")
    precio = precio or 0.0
    if precio < 0:
        raise ErrorContable("El precio no puede ser negativo.")
    registrar_pendientes(conn, _siguiente(_ym(fecha), -1), activo_id)
    acum = conn.execute("SELECT COALESCE(SUM(importe), 0) FROM depreciaciones WHERE activo_id = ? AND mes < ?",
                        (activo_id, _ym(fecha))).fetchone()[0]
    base = C.moneda_base(conn)
    lineas = []
    if precio > 0:
        caja = conn.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1", (caja_id,)).fetchone()
        if not caja:
            raise ErrorContable("Elige en qué caja entró el dinero de la venta.")
        mon = caja["moneda"] or base
        b = r2(C.convertir(precio, mon, base, tasa))
        lineas.append({"cuenta_id": caja["id"], "importe": precio, "moneda": mon, "base": b})
    else:
        b = 0.0
    if acum > 0.004:
        lineas.append({"cuenta_id": C.cuenta_por_rol(conn, "dep_acumulada")["id"], "importe": r2(acum), "descripcion": a["nombre"]})
    lineas.append({"cuenta_id": a["cuenta_id"], "importe": -r2(a["costo"]), "descripcion": a["nombre"]})
    dif = r2(b + acum - a["costo"])
    if abs(dif) >= 0.01:
        lineas.append({"cuenta_id": C.cuenta_por_rol(conn, "venta_activos")["id"], "importe": -dif, "moneda": base, "base": -dif,
                       "descripcion": ("Ganancia" if dif > 0 else "Pérdida") + f" al {'vender' if precio > 0 else 'dar de baja'} {a['nombre']}"})
    que = "Venta" if precio > 0 else "Baja"
    aid = C.crear_asiento(conn, fecha, f"{que} de {a['nombre']}" + (f" ({nota})" if nota else ""), lineas, "baja_activo", tasa=tasa)
    conn.execute("UPDATE activos SET baja_fecha = ?, baja_precio = ?, baja_asiento_id = ? WHERE id = ?", (fecha, b, aid, activo_id))
    return aid, dif
