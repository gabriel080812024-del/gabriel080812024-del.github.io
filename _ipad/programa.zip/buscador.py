"""Buscador de todo el programa: pantallas y acciones, contactos, facturas, movimientos, cuentas, productos,
contenedores, activos y la ayuda. No distingue mayúsculas ni acentos ("credito" encuentra "Crédito");
si se escriben varias palabras, tienen que estar todas."""
import re
import unicodedata
from pathlib import Path
from urllib.parse import quote

AQUI = Path(__file__).resolve().parent

# (título, enlace, icono, palabras que también lo encuentran)
PANTALLAS = [
    ("Inicio", "/", "inicio", "panel resumen para revisar"),
    ("Movimientos", "/diario", "lista", "diario asientos historial buscar"),
    ("Caja y bancos", "/caja", "caja", "efectivo dinero saldo banco arqueo contar"),
    ("Inventario", "/inventario", "inventario", "mercancia existencia almacen sacos productos kardex"),
    ("Estados financieros", "/estados", "grafico", "balance resultados ganancia perdida flujo efectivo indicadores"),
    ("Me deben (por cobrar)", "/facturas?tipo=cobrar", "cobrar", "clientes deudas cuentas por cobrar fiado vencidas"),
    ("Debo (por pagar)", "/facturas?tipo=pagar", "pagar", "proveedores deudas cuentas por pagar"),
    ("Contactos", "/terceros", "personas", "clientes proveedores personas terceros"),
    ("Anotar un ingreso cobrado", "/registrar/ingreso", "ingreso", "venta servicio cobre entrada dinero"),
    ("Anotar un gasto o compra pagada", "/registrar/gasto", "gasto", "pague corriente luz alquiler salario combustible equipo"),
    ("Factura por cobrar", "/registrar/cobrar", "cobrar", "vendi fiado credito cliente"),
    ("Factura por pagar", "/registrar/pagar", "pagar", "compre fiado credito proveedor"),
    ("Cobro de una deuda", "/registrar/cobro", "cobro", "me pagaron abono anticipo adelanto cliente"),
    ("Pago de una deuda", "/registrar/pago", "pago", "pague abono anticipo adelanto proveedor"),
    ("Transferencia o cambio de moneda", "/registrar/transferencia", "cambio", "cambiar dolares usd cup pesos banco mover dinero"),
    ("Comprar Zelle", "/zelle", "cambio", "zelle exterior porciento comision"),
    ("Préstamo, aporte o retiro", "/registrar/movimiento", "banco", "prestamo aporte retiro dueno capital"),
    ("Compra de mercancía", "/inventario/compra", "inventario", "entro mercancia contenedor lote harina"),
    ("Venta de mercancía", "/inventario/venta", "inventario", "vendi sacos salida"),
    ("Flete, aduana o costo extra", "/inventario/costo", "inventario", "flete aduana nacionalizacion transporte descarga"),
    ("Merma o sobrante", "/inventario/ajuste", "inventario", "rompio perdio mojado sobra falta conteo"),
    ("Contenedores", "/contenedores", "inventario", "contenedor lote rentabilidad margen"),
    ("Informes del período", "/informes", "informe", "informe mensual trimestral anual imprimir"),
    ("Flujo de caja", "/flujo-caja", "tendencia", "alcanza dinero proximas semanas prevision"),
    ("Metas del mes", "/metas", "meta", "objetivo tope presupuesto ventas gastos"),
    ("Plan de cuentas", "/cuentas", "libro", "cuentas catalogo"),
    ("Asiento manual", "/asiento/nuevo", "lapiz", "debe haber contadora"),
    ("Tasa de cambio", "/tasas", "cambio", "tasa dolar cup del dia"),
    ("Ajuste por tasa de cambio", "/ajuste-cambio", "cambio", "revaluacion diferencia cambio fin de mes"),
    ("Activos y depreciación", "/activos", "camion", "activo fijo camion vehiculo equipo computadora depreciacion vender baja"),
    ("Saldos iniciales", "/saldos-iniciales", "bandera", "apertura empezar inicio"),
    ("Cierre de mes", "/cierre", "candado", "cerrar bloquear mes reabrir"),
    ("Copias de seguridad", "/copias", "copia", "copia respaldo backup descargar restaurar traer ipad"),
    ("Ver en el iPhone", "/movil", "movil", "iphone visor movil exportar"),
    ("Configuración", "/configuracion", "ajustes", "empresa moneda logo pie documentos"),
    ("Mi cuenta y contraseña", "/mi-cuenta", "personas", "contrasena clave usuario"),
    ("Usuarios del programa", "/usuarios", "personas", "usuarios permisos contadora"),
    ("Seguridad y bitácora", "/seguridad", "candado", "bitacora quien cambio registro"),
    ("Tutoriales y ayuda", "/ayuda", "ayuda", "ayuda tutorial guia como"),
]


VACIAS = {"como", "de", "del", "la", "el", "los", "las", "un", "una", "que", "en", "mi", "me", "a", "y", "o", "para", "por",
          "lo", "se", "con", "al", "hago", "anoto", "anotar", "donde", "quiero", "esta", "es"}


def norm(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def _like(w):
    return "%" + w.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def _cond(expr, palabras):
    return " AND ".join(f"sa({expr}) LIKE ? ESCAPE '\\'" for _ in palabras), [_like(w) for w in palabras]


_AYUDA = []


def _ayuda():
    """Títulos de las recetas de la guía y de las secciones del tutorial (se leen una vez)."""
    if not _AYUDA:
        for archivo, nombre in (("guia.html", "Guía"), ("tutorial.html", "Tutorial")):
            p = AQUI / "static" / "ayuda" / archivo
            if not p.exists():
                continue
            for m in re.finditer(r"<h3[^>]*>(.*?)</h3>", p.read_text(encoding="utf-8"), re.S):
                num = re.search(r'class="num">(\d+)<', m.group(1))
                titulo = re.sub(r"<[^>]+>", "", re.sub(r'<span class="num">\d+</span>', "", m.group(1))).strip()
                if titulo:
                    _AYUDA.append((titulo, f"/static/ayuda/{archivo}#:~:text={quote(titulo[:60])}",
                                   f"{nombre}{' · receta ' + num.group(1) if num else ''}"))
    return _AYUDA


def _numero(q):
    """'1500', '1,500.50' o '1500,5' → número; cualquier otra cosa → None."""
    s = q.strip().replace(" ", "").replace("$", "")
    if not s or not re.fullmatch(r"[\d.,]+", s) or not re.search(r"\d", s):
        return None
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    elif "," in s:
        partes = s.split(",")
        s = s.replace(",", ".") if len(partes) == 2 and len(partes[1]) <= 2 else s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return None


def buscar(conn, q, limite=6):
    q = " ".join((q or "").split())[:80]
    palabras = norm(q).split()
    utiles = [w for w in palabras if w not in VACIAS]
    palabras = utiles or palabras  # "como cobro" busca "cobro"
    if not palabras:
        return {"q": q, "grupos": [], "total": 0}
    conn.create_function("sa", 1, norm)
    grupos = []

    def grupo(titulo, items, mas=None):
        if items:
            grupos.append({"titulo": titulo, "items": items[:limite], "mas": mas if len(items) > limite or mas else None,
                           "n": len(items)})

    # pantallas y acciones
    grupo("Ir a", [{"t": t, "u": u, "i": i, "s": ""} for t, u, i, k in PANTALLAS
                   if all(w in norm(t + " " + k) for w in palabras)])

    # contactos
    c, p = _cond("t.nombre || ' ' || COALESCE(t.documento, '') || ' ' || COALESCE(t.telefono, '') || ' ' || COALESCE(t.email, '') || ' ' || COALESCE(t.notas, '')", palabras)
    grupo("Contactos", [{"t": r["nombre"], "u": f"/terceros/{r['id']}", "i": "personas",
                         "s": " · ".join(x for x in (r["tipo"], r["telefono"]) if x)}
                        for r in conn.execute(f"SELECT * FROM terceros t WHERE {c} ORDER BY t.activo DESC, t.nombre LIMIT 30", p)])

    # facturas
    c, p = _cond("COALESCE(d.numero, '') || ' ' || d.concepto || ' ' || t.nombre", palabras)
    grupo("Facturas", [{"t": f"{r['numero'] or 'Sin número'} · {r['nombre']}", "u": f"/facturas/{r['id']}", "i": "cobrar" if r["tipo"] == "cobrar" else "pagar",
                        "s": f"{'Me debe' if r['tipo'] == 'cobrar' else 'Debo'} · {r['fecha'][8:10]}/{r['fecha'][5:7]}/{r['fecha'][:4]} · {r['importe']:,.2f} {r['moneda']} · {r['concepto']}"
                             + (" · anulada" if r["anulado"] else "")}
                       for r in conn.execute(f"SELECT d.*, t.nombre FROM documentos d JOIN terceros t ON t.id = d.tercero_id WHERE {c}"
                                             " ORDER BY d.anulado, d.fecha DESC LIMIT 30", p)])

    # movimientos (concepto, referencia, número, descripciones de las líneas, personas; o el importe si es un número)
    texto = ("a.concepto || ' ' || COALESCE(a.referencia, '') || ' #' || a.numero || ' ' || COALESCE((SELECT group_concat("
             "COALESCE(l.descripcion, '') || ' ' || COALESCE(t.nombre, ''), ' ') FROM lineas l LEFT JOIN terceros t ON t.id = l.tercero_id"
             " WHERE l.asiento_id = a.id), '')")
    c, p = _cond(texto, palabras)
    num = _numero(q)
    if num is not None:
        c = f"(({c}) OR EXISTS (SELECT 1 FROM lineas l WHERE l.asiento_id = a.id AND (ABS(ABS(l.importe_orig) - ?) < 0.005 OR ABS(l.debe - ?) < 0.005)))"
        p += [num, num]
    filas = conn.execute(f"SELECT a.*, (SELECT SUM(debe) FROM lineas WHERE asiento_id = a.id) total FROM asientos a WHERE {c}"
                         " ORDER BY a.anulado, a.fecha DESC, a.id DESC LIMIT 60", p).fetchall()
    grupo("Movimientos", [{"t": r["concepto"], "u": f"/asientos/{r['id']}", "i": "lista",
                           "s": f"#{r['numero']} · {r['fecha'][8:10]}/{r['fecha'][5:7]}/{r['fecha'][:4]} · {(r['total'] or 0):,.2f}"
                                + (f" · {r['referencia']}" if r["referencia"] else "") + (" · anulado" if r["anulado"] else "")}
                          for r in filas],
          mas=f"/diario?q={quote(q)}&desde=1990-01-01" if len(filas) > limite else None)

    # cuentas
    c, p = _cond("cu.codigo || ' ' || cu.nombre", palabras)
    grupo("Cuentas", [{"t": f"{r['codigo']} {r['nombre']}", "u": f"/cuentas/{r['id']}", "i": "libro", "s": "Grupo" if r["es_grupo"] else r["tipo"].capitalize()}
                      for r in conn.execute(f"SELECT * FROM cuentas cu WHERE {c} ORDER BY cu.activa DESC, cu.codigo LIMIT 30", p)])

    # productos, contenedores y activos
    c, p = _cond("pr.nombre || ' ' || COALESCE(pr.categoria, '') || ' ' || COALESCE(pr.notas, '')", palabras)
    items = [{"t": r["nombre"], "u": f"/inventario/{r['id']}", "i": "inventario", "s": f"Producto · {r['unidad']}"}
             for r in conn.execute(f"SELECT * FROM productos pr WHERE {c} ORDER BY pr.activo DESC, pr.nombre LIMIT 20", p)]
    c, p = _cond("k.nombre || ' ' || COALESCE(k.nota, '')", palabras)
    items += [{"t": r["nombre"], "u": f"/contenedores/{r['id']}", "i": "inventario", "s": "Contenedor" + (f" · {r['nota']}" if r["nota"] else "")}
              for r in conn.execute(f"SELECT * FROM contenedores k WHERE {c} ORDER BY k.id DESC LIMIT 20", p)]
    c, p = _cond("ac.nombre || ' ' || COALESCE(ac.nota, '')", palabras)
    items += [{"t": r["nombre"], "u": f"/activos/{r['id']}", "i": "camion", "s": f"Activo · {r['costo']:,.2f}" + (" · vendido o de baja" if r["baja_fecha"] else "")}
              for r in conn.execute(f"SELECT * FROM activos ac WHERE {c} ORDER BY ac.id DESC LIMIT 20", p)]
    grupo("Mercancía y activos", items)

    # ayuda
    grupo("Ayuda", [{"t": t, "u": u, "i": "ayuda", "s": s} for t, u, s in _ayuda() if all(w in norm(t) for w in palabras)])

    return {"q": q, "grupos": grupos, "total": sum(g["n"] for g in grupos)}
