"""Mi Contabilidad: programa contable local (Flask + SQLite)."""
import os
import re
from datetime import date, datetime, timedelta
from pathlib import Path

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import contab as C
import db
from exportar import a_excel

import hashlib
import threading
import time


def _version():
    """Huella del código: cambia cada vez que se modifica el programa."""
    h = hashlib.sha1()
    base = Path(__file__).resolve().parent
    for p in sorted(list(base.glob("*.py")) + list(base.glob("templates/*")) + list(base.glob("static/*"))):
        h.update(f"{p.name}{p.stat().st_mtime_ns}".encode())
    return h.hexdigest()[:12]


VERSION = _version()
APAGAR = threading.Event()
ULTIMO_LATIDO = [None]  # time.monotonic() del último aviso de la ventana

import boveda

app = Flask(__name__)
if boveda.estado() != "bloqueada":
    db.iniciar()
app.secret_key = db.clave_secreta()
app.config.update(MAX_CONTENT_LENGTH=500 * 1024 * 1024, SESSION_COOKIE_SAMESITE="Strict", SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_NAME="mc_sesion")
INACTIVIDAD = 60 * 60          # 1 hora sin usar el programa: se cierra la sesión y se cifran los datos
MAX_INTENTOS = 5               # 5 fallos seguidos bloquean; cada nuevo bloqueo dura el doble (1, 2, 4… minutos)
INTENTOS = {}                  # clave -> [fallos, bloqueado_hasta, bloqueos]
ACTIVAS = {}                   # sesiones abiertas: id -> último uso
PENDIENTES = {}                # entradas a medias esperando el código del teléfono
EVENTOS_PENDIENTES = []        # cosas que anotar en la bitácora cuando se pueda (datos cifrados)
LIBRES = {"static", "entrar", "crear_usuario", "recuperar", "verificar", "restaurar_copia", "favicon", "api_latido", "api_estado",
          "api_apagar"}
HOSTS_PERMITIDOS = None        # se completa con el puerto real


# ---------------------------------------------------------------- utilidades

def conn():
    if "conn" not in g:
        g.conn = db.conectar()
    return g.conn


@app.teardown_appcontext
def cerrar(exc):
    C.CONTEXTO.memo = None  # lo recordado solo vale dentro de un pedido
    c = g.pop("conn", None)
    if c is not None:
        if exc is None:
            c.commit()
        c.close()


def numero(texto, defecto=None):
    """Lee números escritos como 1234.5, 1,234.50 o 1234,5."""
    s = (texto or "").strip().replace(" ", "").replace("$", "")
    if not s:
        return defecto
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    elif "," in s:
        partes = s.split(",")
        s = s.replace(",", ".") if len(partes) == 2 and len(partes[1]) <= 2 else s.replace(",", "")
    try:
        v = float(s)
    except ValueError:
        raise C.ErrorContable(f"'{texto}' no es un número válido.")
    if v != v or abs(v) >= 1e12:
        raise C.ErrorContable(f"'{texto}' no es un número válido.")
    return v


def entero(texto):
    try:
        v = int(texto)
    except (TypeError, ValueError):
        return None
    return v if -2**62 < v < 2**62 else None  # SQLite no acepta números más grandes


def fecha_form(nombre="fecha"):
    f = (request.form.get(nombre) or "").strip()
    try:
        d = datetime.strptime(f, "%Y-%m-%d").date()
    except ValueError:
        raise C.ErrorContable("La fecha no es válida.")
    if d.year < 1990 or d.year > 2100:
        raise C.ErrorContable("Revisa el año de la fecha.")
    if nombre == "fecha" and d > date.today() and not g.get("aviso_fecha"):
        g.aviso_fecha = True
        flash(f"Ojo: anotaste una fecha futura ({d:%d/%m/%Y}). No contará en los saldos de hoy hasta ese día. "
              "Si fue un error, modifica el movimiento.", "error")
    return f


def tasa_form(fecha):
    t = numero(request.form.get("tasa"))
    if t is not None and t <= 0:
        raise C.ErrorContable("La tasa de cambio tiene que ser mayor que cero.")
    if t is None:
        t = C.tasa_del_dia(conn(), fecha)
    else:
        C.guardar_tasa_si_falta(conn(), fecha, t)
    return t


def fmt_dinero(v, dec=2):
    if v is None or v == "":
        return ""
    if isinstance(v, str):
        return v
    if abs(v) < 0.005:
        return "–"
    s = f"{abs(v):,.{dec}f}"
    return f"({s})" if v < 0 else s


def fmt_valor(v, fmt):
    if isinstance(v, tuple):
        fmt, v = v
    if v is None or v == "":
        return ""
    if fmt == "p":
        return f"{v * 100:,.1f} %"
    if fmt == "r":
        return f"{v:,.2f}"
    if fmt == "d":
        return f"{v:,.0f} días"
    if fmt == "e":
        return f"{v:,}"
    if fmt == "t" or isinstance(v, str):
        return v
    escala = g.get("escala", 1) if g else 1
    if escala != 1 and isinstance(v, (int, float)):
        return fmt_dinero(v / escala, 1)
    return fmt_dinero(v)


def fmt_fecha(f):
    try:
        return datetime.strptime(f, "%Y-%m-%d").strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return f or ""


def es_neg(v):
    if isinstance(v, tuple):
        v = v[1]
    return isinstance(v, (int, float)) and v < -0.004


app.jinja_env.filters.update(dinero=fmt_dinero, valor=fmt_valor, fecha=fmt_fecha, es_neg=es_neg)


def pagina_padre():
    """A dónde lleva "Atrás" si no hay una página anterior (por ejemplo, al abrir el programa)."""
    ruta = request.path
    if ruta.startswith("/estado-cuenta/"):
        return "/facturas?tipo=" + ruta.split("/")[2]
    for prefijo, padre in (("/caja/", "/caja"), ("/inventario/", "/inventario"), ("/asientos/", "/diario"), ("/facturas/", "/facturas"), ("/cuentas/", "/cuentas"),
                           ("/terceros/", "/terceros"), ("/informes/", "/informes"), ("/ajuste-cambio", "/tasas")):
        if ruta.startswith(prefijo):
            return padre
    return "/"


@app.context_processor
def globales():
    try:
        empresa, base_ = C.nombre_empresa(conn()), C.moneda_base(conn())
    except db.BovedaCerrada:  # datos cifrados y nadie dentro: no se muestra nada de la empresa
        empresa, base_ = "Mi Contabilidad", "USD"
    letras = re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñ0-9]", empresa)
    return {"empresa": empresa, "base": base_, "hoy": C.hoy(), "padre": pagina_padre(),
            "iniciales": "".join(letras[:2]).upper() or "MC",
            "MESES": C.MESES, "C": C, "anio_actual": date.today().year}


@app.before_request
def filtro_de_red():
    """Solo se aceptan pedidos hechos a esta computadora por la propia ventana del programa
    (protege contra páginas web maliciosas que intenten usar el programa por detrás)."""
    host = (request.host or "").lower()
    nombre = host.rsplit(":", 1)[0]
    if nombre not in ("127.0.0.1", "localhost", "[::1]"):
        abort(403)
    if request.method == "POST":
        origen = request.headers.get("Origin") or request.headers.get("Referer") or ""
        if origen and origen.split("/")[2:3] != [request.host]:
            abort(403)


@app.after_request
def cabeceras_de_seguridad(r):
    r.headers["X-Frame-Options"] = "SAMEORIGIN" if db.IPAD else "DENY"  # en el iPad va dentro del marco de la app
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Referrer-Policy"] = "same-origin"
    r.headers["Content-Security-Policy"] = ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
                                            "img-src 'self' data:; frame-ancestors " + ("'self'" if db.IPAD else "'none'") +
                                            "; form-action 'self'; base-uri 'none'")
    if not request.path.startswith("/static"):
        r.headers["Cache-Control"] = "no-store"  # que Chrome no guarde copias de las pantallas en el disco
    return r


def _cerrar_sesion_actual():
    sid = session.get("sid")
    session.clear()
    if sid:
        ACTIVAS.pop(sid, None)
    _cerrar_boveda_si_nadie()


def _cerrar_boveda_si_nadie():
    ahora = time.time()
    for sid, visto in list(ACTIVAS.items()):
        if ahora - visto > INACTIVIDAD:
            ACTIVAS.pop(sid, None)
    if not ACTIVAS and boveda.abierta():
        c = g.pop("conn", None)
        if c is not None:
            c.commit()
            c.close()
        boveda.cerrar()


@app.before_request
def control_de_acceso():
    """Nadie entra sin usuario y contraseña (salvo las páginas de entrar y lo que usa el lanzador)."""
    C.CONTEXTO.usuario = None
    C.CONTEXTO.anticipo = None
    C.CONTEXTO.memo = {}  # cálculos recordados solo durante este pedido
    if request.endpoint in LIBRES or request.endpoint is None:
        return None
    destino = request.full_path if request.method == "GET" and not request.path.startswith("/api/") else None
    a_entrar = url_for("entrar", siguiente=destino) if destino and destino != "/?" else url_for("entrar")
    if boveda.estado() == "bloqueada":
        session.pop("uid", None)
        return redirect(a_entrar)
    c = conn()
    if not c.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone():
        return redirect(url_for("crear_usuario"))
    u = None
    sid = session.get("sid")
    if session.get("uid") and sid in ACTIVAS:
        u = c.execute("SELECT * FROM usuarios WHERE id = ? AND activo = 1", (session["uid"],)).fetchone()
    if not u:
        session.clear()
        return redirect(a_entrar)
    if time.time() - ACTIVAS.get(sid, 0) > INACTIVIDAD:
        evento("Sesión cerrada por inactividad", usuario=u["nombre"])
        _cerrar_sesion_actual()
        flash("Tu sesión se cerró porque el programa estuvo más de 1 hora sin usarse. Vuelve a entrar.", "ok")
        return redirect(a_entrar)
    ACTIVAS[sid] = time.time()
    boveda.ULTIMO_USO[0] = time.monotonic()
    g.usuario = u
    C.CONTEXTO.usuario = u["nombre"]
    if request.endpoint != "bienvenida" and not db.get_config(c, "empresa"):
        return redirect(url_for("bienvenida"))
    return None


def errores(f):
    """Muestra los errores contables como mensaje y vuelve al formulario."""
    from functools import wraps

    @wraps(f)
    def envoltura(*a, **k):
        try:
            return f(*a, **k)
        except C.ErrorContable as e:
            conn().rollback()
            flash(str(e), "error")
            if request.method == "POST":
                return render_or_back()
            return redirect(url_for("panel"))
    return envoltura


CON_FORMULARIO = {"mi_cuenta", "usuarios", "registrar", "asiento_nuevo", "saldos_iniciales", "cuenta_editar", "tercero_editar", "tasas",
                  "ajuste_cambio", "inv_accion", "producto_editar", "caja_detalle", "zelle"}


def render_or_back():
    """Vuelve a mostrar el formulario con lo que se escribió, o regresa a la página anterior."""
    if request.endpoint not in CON_FORMULARIO:
        return redirect(request.referrer or url_for("panel"))
    vista = app.view_functions[request.endpoint]
    request.environ["mc.repetir"] = True
    try:
        return vista.__wrapped__(**request.view_args)
    except C.ErrorContable as e:  # el formulario tampoco se puede mostrar con esos datos
        flash(str(e), "error")
        return redirect(request.referrer or url_for("panel"))


def repitiendo():
    return request.environ.get("mc.repetir", False)


def opciones_cuentas(filtro):
    todas = C.cuentas(conn(), solo_activas=True)
    grupos = {c["id"]: c for c in todas if c["es_grupo"]}
    out = []
    for c in todas:
        if not c["es_grupo"] and filtro(c):
            out.append(dict(c, grupo=grupos.get(c["padre_id"], {}).get("nombre", "")))
    return out


def cajas():
    return opciones_cuentas(lambda c: c["es_efectivo"])


def nombres_terceros():
    return [t["nombre"] for t in conn().execute("SELECT nombre FROM terceros WHERE activo = 1 ORDER BY nombre")]


# ---------------------------------------------------------------- seguridad: usuarios, contraseñas y bóveda

METODO_CLAVE = "pbkdf2:sha256:600000"
CLAVES_COMUNES = {"123456", "1234567", "12345678", "123456789", "1234567890", "password", "contraseña", "qwerty",
                  "abc123", "111111", "000000", "admin", "cuba", "habana", "marea", "fresca"}


def cifrar(texto):
    return generate_password_hash(texto, method=METODO_CLAVE)


def codigo_recuperacion():
    import secrets
    letras = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # sin 0/O ni 1/I para no confundirlas
    return "-".join("".join(secrets.choice(letras) for _ in range(4)) for _ in range(4))


def normalizar_codigo(codigo):
    c = re.sub(r"[^A-Z0-9]", "", (codigo or "").upper())
    return "-".join(c[i:i + 4] for i in range(0, len(c), 4))


def validar_usuario_y_clave(usuario, clave, repetir, nueva=True):
    usuario = (usuario or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9._-]{3,30}", usuario):
        raise C.ErrorContable("El usuario debe tener de 3 a 30 letras o números, sin espacios ni tildes (ej.: gabriel).")
    clave = clave or ""
    if clave != (repetir or ""):
        raise C.ErrorContable("Las dos contraseñas no son iguales.")
    if nueva:
        if len(clave) < 10:
            raise C.ErrorContable("La contraseña tiene que tener al menos 10 caracteres (puede ser una frase).")
        if not (re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]", clave) and re.search(r"\d", clave)):
            raise C.ErrorContable("La contraseña tiene que tener letras y números.")
        if clave.lower() in CLAVES_COMUNES or usuario in clave.lower() or len(set(clave)) < 5:
            raise C.ErrorContable("Esa contraseña es muy fácil de adivinar. Usa otra.")
    if len(clave) > 200:
        raise C.ErrorContable("La contraseña es demasiado larga.")
    return usuario


def evento(texto, detalle=None, usuario=None):
    """Bitácora de seguridad (quién entró, intentos fallidos, cambios de usuarios, borrados…)."""
    quien = usuario or (g.usuario["nombre"] if g.get("usuario") else None)
    fila = (datetime.now().isoformat(timespec="seconds"), quien, texto, (detalle or "")[:300] or None)
    try:
        c = conn()
        for p in EVENTOS_PENDIENTES:
            c.execute("INSERT INTO bitacora (fecha, usuario, evento, detalle) VALUES (?,?,?,?)", p)
        EVENTOS_PENDIENTES.clear()
        c.execute("INSERT INTO bitacora (fecha, usuario, evento, detalle) VALUES (?,?,?,?)", fila)
        c.commit()
    except db.BovedaCerrada:
        EVENTOS_PENDIENTES.append(fila)  # se anota en cuanto alguien abra los datos


def bloqueado(clave):
    fallos, hasta, bloqueos = INTENTOS.get(clave, [0, 0, 0])
    return max(0, int(hasta - time.time()) + 1) if time.time() < hasta else 0


def fallo(clave):
    fallos, hasta, bloqueos = INTENTOS.get(clave, [0, 0, 0])
    fallos += 1
    if fallos >= MAX_INTENTOS:
        bloqueos += 1
        INTENTOS[clave] = [0, time.time() + 60 * 2 ** (bloqueos - 1), bloqueos]
        return True
    INTENTOS[clave] = [fallos, 0, bloqueos]
    return False


def iniciar_sesion(u):
    import secrets
    session.clear()
    sid = secrets.token_urlsafe(24)
    session["uid"] = u["id"]
    session["sid"] = sid
    ACTIVAS[sid] = time.time()
    conn().execute("UPDATE usuarios SET ultimo_acceso = ? WHERE id = ?",
                   (datetime.now().isoformat(timespec="seconds"), u["id"]))
    conn().commit()
    g.usuario = u


def abrir_datos(llave):
    """Descifra los datos (si estaban cerrados) y deja todo listo para trabajar."""
    if not boveda.abierta():
        boveda.abrir(llave)
        db.iniciar()
        try:
            db.copia_diaria()
        except Exception as exc:
            print("No se pudo hacer la copia diaria:", exc)


def completar_entrada(usuario, llave, siguiente):
    abrir_datos(llave)
    u = conn().execute("SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)).fetchone()
    if not u:
        evento("Entrada rechazada: usuario desactivado", usuario=usuario)
        _cerrar_boveda_si_nadie()
        flash("Ese usuario está desactivado.", "error")
        return redirect(url_for("entrar"))
    INTENTOS.pop(usuario, None)
    iniciar_sesion(u)
    evento("Entró al programa", usuario=u["nombre"])
    return redirect(siguiente)


def usuario_actual():
    return g.get("usuario")


@app.context_processor
def datos_usuario():
    return {"usuario_actual": g.get("usuario"), "boveda_estado": boveda.estado(), "ipad": db.IPAD}


def _siguiente():
    s_ = request.values.get("siguiente") or ""
    return s_ if s_.startswith("/") and not s_.startswith("//") else "/"


@app.route("/crear-usuario", methods=["GET", "POST"])
def crear_usuario():
    """Solo la primera vez: crea el usuario administrador y cifra los datos."""
    if boveda.activa():
        return redirect(url_for("entrar"))
    c = conn()
    if c.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone():
        return redirect(url_for("entrar"))
    if request.method == "POST":
        try:
            nombre = " ".join((request.form.get("nombre") or "").split())[:60]
            if not nombre:
                raise C.ErrorContable("Escribe tu nombre.")
            usuario = validar_usuario_y_clave(request.form.get("usuario"), request.form.get("clave"),
                                              request.form.get("repetir"))
        except C.ErrorContable as e:
            flash(str(e), "error")
            return render_template("seguridad.html", modo="crear", f=request.form)
        codigo = codigo_recuperacion()
        uid = c.execute("INSERT INTO usuarios (usuario, nombre, clave, recuperacion, es_admin, creado) VALUES (?,?,?,?,1,?)",
                        (usuario, nombre, cifrar(request.form["clave"]), cifrar(codigo),
                         datetime.now().isoformat(timespec="seconds"))).lastrowid
        c.commit()
        boveda.activar(usuario, request.form["clave"], codigo)
        iniciar_sesion(c.execute("SELECT * FROM usuarios WHERE id = ?", (uid,)).fetchone())
        evento("Usuario administrador creado y datos cifrados", usuario=nombre)
        return render_template("seguridad.html", modo="codigo", codigo=codigo, nombre=nombre)
    return render_template("seguridad.html", modo="crear", f={})


@app.route("/entrar", methods=["GET", "POST"])
def entrar():
    siguiente = _siguiente()
    if not boveda.activa() and not conn().execute("SELECT 1 FROM usuarios LIMIT 1").fetchone():
        return redirect(url_for("crear_usuario"))
    if request.method == "POST":
        usuario = (request.form.get("usuario") or "").strip().lower()[:30]
        clave = request.form.get("clave") or ""
        espera = bloqueado(usuario)
        if espera:
            flash(f"Demasiados intentos. Espera {espera} segundos y vuelve a probar.", "error")
            return render_template("seguridad.html", modo="entrar", f={"usuario": usuario}, siguiente=siguiente)
        if boveda.activa():
            llave = boveda.probar_clave(usuario, clave)
            if llave:
                totp = boveda.totp_de(usuario, llave)
                if totp:
                    import secrets
                    token = secrets.token_urlsafe(24)
                    PENDIENTES[token] = {"usuario": usuario, "llave": llave, "hasta": time.time() + 300, "fallos": 0}
                    session.clear()
                    session["pendiente"] = token
                    return redirect(url_for("verificar", siguiente=siguiente))
                return completar_entrada(usuario, llave, siguiente)
        else:
            # datos todavía sin cifrar (usuario creado antes): al entrar bien, se cifran
            u = conn().execute("SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)).fetchone()
            if u and check_password_hash(u["clave"], clave):
                codigo = codigo_recuperacion()
                conn().execute("UPDATE usuarios SET recuperacion = ? WHERE id = ?", (cifrar(codigo), u["id"]))
                conn().commit()
                boveda.activar(usuario, clave, codigo)
                iniciar_sesion(u)
                evento("Datos cifrados con AES-256", usuario=u["nombre"])
                return render_template("seguridad.html", modo="codigo", codigo=codigo, nombre=u["nombre"],
                                       recuperado=True, recien_cifrado=True)
        bloquea = fallo(usuario)
        evento("Contraseña incorrecta", f"usuario: {usuario}", usuario="(desconocido)")
        flash("Usuario o contraseña incorrectos." + (" Por seguridad, espera antes de volver a probar." if bloquea else ""),
              "error")
        return render_template("seguridad.html", modo="entrar", f={"usuario": usuario}, siguiente=siguiente)
    return render_template("seguridad.html", modo="entrar", f={}, siguiente=siguiente)


@app.route("/verificar", methods=["GET", "POST"])
def verificar():
    """Segundo paso: el código de 6 números del teléfono."""
    token = session.get("pendiente")
    p_ = PENDIENTES.get(token) if token else None
    if not p_ or time.time() > p_["hasta"]:
        PENDIENTES.pop(token, None)
        session.clear()
        flash("Vuelve a escribir tu usuario y contraseña.", "error")
        return redirect(url_for("entrar"))
    if request.method == "POST":
        totp = boveda.totp_de(p_["usuario"], p_["llave"])
        paso = boveda.comprobar_totp(totp["secreto"], request.form.get("codigo"), totp.get("ultimo"))
        if paso is None:
            p_["fallos"] += 1
            evento("Código del teléfono incorrecto", usuario=p_["usuario"])
            if p_["fallos"] >= MAX_INTENTOS:
                PENDIENTES.pop(token, None)
                session.clear()
                fallo(p_["usuario"])
                flash("Demasiados códigos incorrectos. Empieza de nuevo.", "error")
                return redirect(url_for("entrar"))
            flash("Código incorrecto o ya usado. Mira el código nuevo en el teléfono.", "error")
            return render_template("seguridad.html", modo="verificar", siguiente=_siguiente())
        totp["ultimo"] = paso
        boveda.guardar_totp(p_["usuario"], totp, p_["llave"])
        PENDIENTES.pop(token, None)
        return completar_entrada(p_["usuario"], p_["llave"], _siguiente())
    return render_template("seguridad.html", modo="verificar", siguiente=_siguiente())


@app.route("/salir", methods=["POST"])
def salir():
    if g.get("usuario") or session.get("uid"):
        try:
            evento("Cerró la sesión")
        except Exception:
            pass
    _cerrar_sesion_actual()
    flash("Sesión cerrada." + (" Los datos quedaron cifrados." if boveda.activa() and not boveda.abierta() else ""), "ok")
    return redirect(url_for("entrar"))


@app.route("/recuperar", methods=["GET", "POST"])
def recuperar():
    """Olvidé mi contraseña: con el código de recuperación se pone una nueva (y se quita la verificación del teléfono)."""
    if request.method == "POST":
        usuario = (request.form.get("usuario") or "").strip().lower()[:30]
        espera = bloqueado("rec:" + usuario)
        if espera:
            flash(f"Demasiados intentos. Espera {espera} segundos.", "error")
            return render_template("seguridad.html", modo="recuperar", f={"usuario": usuario})
        codigo = normalizar_codigo(request.form.get("codigo"))
        try:
            validar_usuario_y_clave(usuario, request.form.get("clave"), request.form.get("repetir"))
        except C.ErrorContable as e:
            flash(str(e), "error")
            return render_template("seguridad.html", modo="recuperar", f={"usuario": usuario})
        llave = boveda.probar_codigo(usuario, codigo) if boveda.activa() else None
        u = None
        if llave:
            abrir_datos(llave)
            u = conn().execute("SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)).fetchone()
        elif not boveda.activa():
            u = conn().execute("SELECT * FROM usuarios WHERE usuario = ? AND activo = 1", (usuario,)).fetchone()
            if not (u and u["recuperacion"] and check_password_hash(u["recuperacion"], codigo)):
                u = None
        if not u:
            fallo("rec:" + usuario)
            evento("Código de recuperación incorrecto", f"usuario: {usuario}", usuario="(desconocido)")
            if llave:
                _cerrar_boveda_si_nadie()
            flash("El usuario o el código de recuperación no son correctos.", "error")
            return render_template("seguridad.html", modo="recuperar", f={"usuario": usuario})
        nuevo = codigo_recuperacion()
        clave = request.form["clave"]
        conn().execute("UPDATE usuarios SET clave = ?, recuperacion = ? WHERE id = ?", (cifrar(clave), cifrar(nuevo), u["id"]))
        conn().commit()
        if boveda.activa():
            boveda.poner_llave(usuario, clave=clave, codigo=nuevo)
            boveda.guardar_totp(usuario, None)
        else:
            boveda.activar(usuario, clave, nuevo)
        INTENTOS.pop("rec:" + usuario, None)
        iniciar_sesion(u)
        evento("Contraseña cambiada con el código de recuperación (verificación del teléfono desactivada)")
        return render_template("seguridad.html", modo="codigo", codigo=nuevo, nombre=u["nombre"], recuperado=True)
    return render_template("seguridad.html", modo="recuperar", f={})


def _clave_correcta(u, clave):
    if boveda.activa():
        return boveda.probar_clave(u["usuario"], clave) is not None
    return check_password_hash(u["clave"], clave)


@app.route("/mi-cuenta", methods=["GET", "POST"])
@errores
def mi_cuenta():
    c = conn()
    u = usuario_actual()
    totp = boveda.totp_de(u["usuario"]) if boveda.abierta() else None
    if request.method == "POST" and not repitiendo():
        accion = request.form.get("accion")
        if accion == "totp_confirmar":
            secreto = session.get("totp_nuevo")
            paso = boveda.comprobar_totp(secreto, request.form.get("codigo")) if secreto else None
            if paso is None:
                raise C.ErrorContable("Ese código no coincide. Escribe el que aparece ahora en la app del teléfono.")
            boveda.guardar_totp(u["usuario"], {"secreto": secreto, "ultimo": paso})
            session.pop("totp_nuevo", None)
            evento("Activó la verificación en dos pasos")
            flash("Verificación en dos pasos activada ✓. Desde ahora, para entrar te pedirá el código del teléfono.", "ok")
            return redirect(url_for("mi_cuenta"))
        if not _clave_correcta(u, request.form.get("actual") or ""):
            evento("Contraseña actual incorrecta en Mi cuenta")
            raise C.ErrorContable("La contraseña actual no es correcta.")
        if accion == "codigo":
            nuevo = codigo_recuperacion()
            c.execute("UPDATE usuarios SET recuperacion = ? WHERE id = ?", (cifrar(nuevo), u["id"]))
            c.commit()
            boveda.poner_llave(u["usuario"], codigo=nuevo)
            evento("Creó un código de recuperación nuevo")
            return render_template("seguridad.html", modo="codigo", codigo=nuevo, nombre=u["nombre"], recuperado=True)
        if accion == "totp_iniciar":
            session["totp_nuevo"] = boveda.nuevo_secreto_totp()
            return redirect(url_for("mi_cuenta", paso="totp"))
        if accion == "totp_quitar":
            boveda.guardar_totp(u["usuario"], None)
            evento("Desactivó la verificación en dos pasos")
            flash("Verificación en dos pasos desactivada.", "ok")
            return redirect(url_for("mi_cuenta"))
        validar_usuario_y_clave(u["usuario"], request.form.get("clave"), request.form.get("repetir"))
        c.execute("UPDATE usuarios SET clave = ? WHERE id = ?", (cifrar(request.form["clave"]), u["id"]))
        c.commit()
        boveda.poner_llave(u["usuario"], clave=request.form["clave"])
        evento("Cambió su contraseña")
        flash("Contraseña cambiada ✓", "ok")
        return redirect(url_for("mi_cuenta"))
    qr = secreto_nuevo = None
    if request.args.get("paso") == "totp" and session.get("totp_nuevo"):
        secreto_nuevo = session["totp_nuevo"]
        qr = boveda.qr_svg(boveda.uri_totp(secreto_nuevo, u["usuario"], C.nombre_empresa(c)))
    return render_template("usuarios.html", modo="mi_cuenta", totp=totp, qr=qr, secreto_nuevo=secreto_nuevo)


@app.route("/usuarios", methods=["GET", "POST"])
@errores
def usuarios():
    c = conn()
    yo = usuario_actual()
    if not yo["es_admin"]:
        flash("Solo un administrador puede manejar los usuarios.", "error")
        return redirect(url_for("panel"))
    if request.method == "POST" and not repitiendo():
        accion = request.form.get("accion")
        if accion == "nuevo":
            nombre = " ".join((request.form.get("nombre") or "").split())[:60]
            if not nombre:
                raise C.ErrorContable("Escribe el nombre de la persona.")
            usuario = validar_usuario_y_clave(request.form.get("usuario"), request.form.get("clave"),
                                              request.form.get("repetir"))
            if c.execute("SELECT 1 FROM usuarios WHERE usuario = ?", (usuario,)).fetchone():
                raise C.ErrorContable("Ya existe ese usuario.")
            codigo = codigo_recuperacion()
            c.execute("INSERT INTO usuarios (usuario, nombre, clave, recuperacion, es_admin, creado) VALUES (?,?,?,?,?,?)",
                      (usuario, nombre, cifrar(request.form["clave"]), cifrar(codigo),
                       1 if request.form.get("es_admin") else 0, datetime.now().isoformat(timespec="seconds")))
            c.commit()
            if boveda.activa():
                boveda.poner_llave(usuario, clave=request.form["clave"], codigo=codigo)
            evento("Creó un usuario", f"{usuario} ({nombre}){' administrador' if request.form.get('es_admin') else ''}")
            flash(f"Usuario {usuario} creado ✓. Su código de recuperación es {codigo} (dáselo para que lo guarde).", "ok")
        else:
            uid = entero(request.form.get("uid"))
            otro = c.execute("SELECT * FROM usuarios WHERE id = ?", (uid,)).fetchone()
            if not otro:
                raise C.ErrorContable("Ese usuario no existe.")
            admins = c.execute("SELECT COUNT(*) FROM usuarios WHERE es_admin = 1 AND activo = 1").fetchone()[0]
            if accion == "activo":
                if otro["id"] == yo["id"]:
                    raise C.ErrorContable("No puedes desactivarte a ti mismo.")
                if otro["activo"] and otro["es_admin"] and admins <= 1:
                    raise C.ErrorContable("Tiene que quedar al menos un administrador activo.")
                c.execute("UPDATE usuarios SET activo = 1 - activo WHERE id = ?", (uid,))
                if otro["activo"]:
                    boveda.quitar_llave(otro["usuario"])  # su contraseña ya no abre los datos
                    evento("Desactivó un usuario", otro["usuario"])
                    flash("Usuario desactivado: ya no puede entrar ni su contraseña abre los datos.", "ok")
                else:
                    evento("Activó un usuario", otro["usuario"])
                    flash(f"Usuario activado. Ponle una contraseña nueva a {otro['usuario']} para que pueda entrar.", "ok")
            elif accion == "admin":
                if otro["es_admin"] and admins <= 1:
                    raise C.ErrorContable("Tiene que quedar al menos un administrador.")
                c.execute("UPDATE usuarios SET es_admin = 1 - es_admin WHERE id = ?", (uid,))
                evento("Cambió permisos de administrador", otro["usuario"])
                flash("Permisos cambiados.", "ok")
            elif accion == "clave":
                validar_usuario_y_clave(otro["usuario"], request.form.get("clave"), request.form.get("clave"))
                codigo = codigo_recuperacion()
                c.execute("UPDATE usuarios SET clave = ?, recuperacion = ? WHERE id = ?",
                          (cifrar(request.form["clave"]), cifrar(codigo), uid))
                if boveda.activa():
                    boveda.poner_llave(otro["usuario"], clave=request.form["clave"], codigo=codigo)
                    boveda.guardar_totp(otro["usuario"], None)
                evento("Puso contraseña nueva a otro usuario", otro["usuario"])
                flash(f"Nueva contraseña puesta a {otro['usuario']} ✓. Su nuevo código de recuperación es {codigo}.", "ok")
            c.commit()
        return redirect(url_for("usuarios"))
    lista = [dict(x) for x in c.execute("SELECT * FROM usuarios ORDER BY activo DESC, nombre")]
    con_llave = boveda.usuarios_con_llave()
    for x in lista:
        x["dos_pasos"] = bool(boveda.abierta() and boveda.totp_de(x["usuario"]))
        x["puede_entrar"] = (x["usuario"] in con_llave) if boveda.activa() else True
    return render_template("usuarios.html", modo="usuarios", lista=lista, f=request.form if repitiendo() else {})


@app.route("/seguridad")
def seguridad():
    u = usuario_actual()
    if not u["es_admin"]:
        flash("Solo un administrador puede ver la seguridad.", "error")
        return redirect(url_for("panel"))
    import subprocess
    try:
        fv = ("On: el iPad cifra su almacenamiento si tiene código de desbloqueo" if db.IPAD else
              subprocess.run(["fdesetup", "status"], capture_output=True, text=True, timeout=5).stdout.strip())
    except Exception:
        fv = "No se pudo comprobar"
    c = conn()
    filas = c.execute("SELECT * FROM bitacora ORDER BY id DESC LIMIT 400").fetchall()
    cifrado = boveda.ruta_cifrada()
    info = {"cifrado": boveda.activa(), "filevault": "On" in fv, "filevault_txt": fv,
            "ultimo": datetime.fromtimestamp(cifrado.stat().st_mtime).strftime("%d/%m/%Y %H:%M") if cifrado.exists() else None,
            "copias": len(db.lista_copias()), "copias_cifradas": sum(1 for p in db.lista_copias() if p.name.endswith(".cifrado")),
            "usuarios": c.execute("SELECT COUNT(*) FROM usuarios WHERE activo = 1").fetchone()[0],
            "dos_pasos": sum(1 for x in c.execute("SELECT usuario FROM usuarios WHERE activo = 1") if boveda.totp_de(x[0])),
            "inactividad": INACTIVIDAD // 60}
    return render_template("seguridad_panel.html", filas=filas, info=info)


# ---------------------------------------------------------------- inicio

@app.route("/bienvenida", methods=["GET", "POST"])
def bienvenida():
    c = conn()
    if request.method == "POST":
        empresa = (request.form.get("empresa") or "").strip()
        if not empresa:
            flash("Escribe el nombre del negocio.", "error")
            return render_template("bienvenida.html")
        db.set_config(c, "empresa", empresa)
        db.set_config(c, "moneda_base", "CUP" if request.form.get("moneda_base") == "CUP" else "USD")
        db.set_config(c, "responsable", (request.form.get("responsable") or "").strip())
        try:
            t = numero(request.form.get("tasa"))
        except C.ErrorContable:
            t = None
        if t and t > 0:
            C.guardar_tasa_si_falta(c, C.hoy(), t)
        c.commit()
        flash("¡Listo! Ahora anota cuánto dinero tienes hoy en cada caja o banco.", "ok")
        return redirect(url_for("saldos_iniciales"))
    return render_template("bienvenida.html")


def para_revisar(c, r, productos_, filas_c, filas_p):
    """Lo pendiente del negocio, ordenado por importancia: (nivel, texto, enlace, botón)."""
    items = []
    for nombre_c, saldo_c, mon_c in C.cajas_negativas(c):
        items.append(("alta", f"{nombre_c} está en negativo ({saldo_c:,.2f} {mon_c}): falta su saldo inicial o hay un error.", "/caja", "Ver caja"))
    vc, vp = r["vencidas_c"], r["vencidas_p"]
    if vc:
        items.append(("alta", f"{len(vc)} factura{'s' if len(vc) > 1 else ''} vencida{'s' if len(vc) > 1 else ''} que te deben "
                      f"({', '.join(sorted({d['tercero'] for d in vc})[:3])}{'…' if len({d['tercero'] for d in vc}) > 3 else ''}).",
                      "/facturas?tipo=cobrar", "Cobrar"))
    if vp:
        items.append(("media", f"{len(vp)} factura{'s' if len(vp) > 1 else ''} vencida{'s' if len(vp) > 1 else ''} que debes pagar.",
                      "/facturas?tipo=pagar", "Ver"))
    ultima_ext = db.get_config(c, "ultima_copia_externa")
    if c.execute("SELECT 1 FROM asientos LIMIT 1").fetchone() and (
            not ultima_ext or (datetime.now() - datetime.fromisoformat(ultima_ext)).days >= 7):
        items.append(("alta", ("Hace más de 7 días que no haces" if ultima_ext else "Todavía no has hecho") +
                      f" una copia de seguridad fuera {'del iPad' if db.IPAD else 'de la Mac'}.", "/copias", "Hacer copia"))
    hoy_ = date.today()
    fin_prev = (hoy_.replace(day=1) - timedelta(days=1))
    ch = C.cerrado_hasta(c)
    if not ch or ch < fin_prev.isoformat():
        tasa_fin = C.tasa_del_dia(c, fin_prev.isoformat())
        if tasa_fin and C.calcular_revaluacion(c, fin_prev.isoformat(), tasa_fin):
            items.append(("media", f"Falta el ajuste por tasa de {C.MESES[fin_prev.month - 1].lower()} (lo que está en CUP a la tasa del último día).",
                          "/tasas", "Ajustar"))
        hay_mes = c.execute("SELECT 1 FROM asientos WHERE fecha BETWEEN ? AND ? LIMIT 1",
                            (fin_prev.replace(day=1).isoformat(), fin_prev.isoformat())).fetchone()
        if hay_mes and hoy_.day >= 3:
            items.append(("info", f"{C.MESES[fin_prev.month - 1]} ya terminó: cuando lo revises, ciérralo para que no cambie.",
                          f"/cierre?anio={fin_prev.year}&mes={fin_prev.month}", "Cerrar mes"))
    bajos = [p["nombre"] for p in productos_ if p["bajo"]]
    if bajos:
        items.append(("media", f"Poca existencia: {', '.join(bajos[:3])}{'…' if len(bajos) > 3 else ''}.", "/inventario", "Ver"))
    adel_p = [f["nombre"] for f in filas_p if f["USD"] < -0.005 or f["CUP"] < -0.005]
    adel_c = [f["nombre"] for f in filas_c if f["USD"] < -0.005 or f["CUP"] < -0.005]
    if adel_p:
        items.append(("info", f"Adelantos pagados esperando mercancía o factura: {', '.join(adel_p[:3])}{'…' if len(adel_p) > 3 else ''}.",
                      "/facturas?tipo=pagar", "Ver"))
    if adel_c:
        items.append(("info", f"Clientes con adelanto a su favor: {', '.join(adel_c[:3])}{'…' if len(adel_c) > 3 else ''}.",
                      "/facturas?tipo=cobrar", "Ver"))
    orden = {"alta": 0, "media": 1, "info": 2}
    return sorted(items, key=lambda x: orden[x[0]])


@app.route("/")
def panel():
    c = conn()
    periodo = request.args.get("periodo") if request.args.get("periodo") in ("anual", "trimestral", "mensual") else "anual"
    cols = C.columnas_terminal(c, periodo, {"anual": 4, "trimestral": 4, "mensual": 6}[periodo])
    tikr, _ = C.informe_resultados_terminal(c, cols, detalle=False)
    import inventario as INV_
    productos_ = sorted(INV_.productos(c, solo_activos=True), key=lambda p: (-p["bajo"], -p["valor"]))
    filas_c, me_deben = C.resumen_lado(c, "cobrar")
    filas_p, debo = C.resumen_lado(c, "pagar")
    r = C.resumen_panel(c)
    return render_template("panel.html", r=r, tasa=C.tasa_del_dia(c), tikr=tikr, periodo=periodo,
                           revisar=para_revisar(c, r, productos_, filas_c, filas_p),
                           me_deben=me_deben, debo=debo, productos=productos_,
                           valor_inv=C.r2(sum(p["valor"] for p in productos_)),
                           saludo=(g.usuario["nombre"].split(" ")[0].capitalize() if g.get("usuario") else
                                   db.get_config(c, "responsable", "") or C.nombre_empresa(c)))


def aviso_duplicado(aid):
    """Si se acaba de anotar algo igual a otro movimiento (mismo día, tipo, importe y concepto), avisar."""
    c = conn()
    a = c.execute("SELECT id, fecha, origen, concepto FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a or a["origen"] in ("saldo_inicial", "ajuste_cambio", "costo_venta"):
        return
    total = c.execute("SELECT ROUND(SUM(debe), 2) FROM lineas WHERE asiento_id = ?", (aid,)).fetchone()[0]
    otro = c.execute(
        "SELECT a.numero FROM asientos a WHERE a.id != ? AND a.anulado = 0 AND a.fecha = ? AND a.origen = ?"
        " AND COALESCE(a.concepto, '') = COALESCE(?, '')"
        " AND (SELECT ROUND(SUM(debe), 2) FROM lineas WHERE asiento_id = a.id) = ? ORDER BY a.id DESC LIMIT 1",
        (aid, a["fecha"], a["origen"], a["concepto"], total)).fetchone()
    if otro:
        flash(f"Ojo: ya había un movimiento igual (n.º {otro['numero']}: mismo día, tipo, importe y concepto). "
              "Si lo anotaste dos veces, búscalo en Movimientos y elimina uno.", "error")


def aviso_anticipo():
    """Si al guardar una factura se le unió solo un adelanto, avisarlo."""
    a = getattr(C.CONTEXTO, "anticipo", None)
    if a:
        flash(f"Esta persona tenía un adelanto: se aplicaron {a[0]:,.2f} {a[1]} a esta factura automáticamente.", "ok")
        C.CONTEXTO.anticipo = None


# ---------------------------------------------------------------- registros rápidos

FORMULARIOS = {
    "ingreso": ("Registrar un ingreso cobrado", "Dinero que entró por una venta o servicio y ya cobraste."),
    "gasto": ("Registrar un gasto o compra pagada", "Dinero que salió y ya pagaste (gastos, compras, equipos)."),
    "cobrar": ("Nueva factura por cobrar", "Vendiste o prestaste un servicio y te van a pagar después."),
    "pagar": ("Nueva factura por pagar", "Compraste o recibiste un servicio y vas a pagar después."),
    "cobro": ("Registrar un cobro", "Alguien te pagó algo que te debía."),
    "pago": ("Registrar un pago a un acreedor", "Pagaste algo que debías a un proveedor, persona o institución."),
    "transferencia": ("Transferencia o cambio de moneda", "Pasar dinero entre cajas/bancos, o cambiar USD por CUP."),
    "movimiento": ("Otro movimiento de dinero", "Aporte o retiro del dueño, préstamo recibido o dado, inversión..."),
    "rebaja_cobrar": ("Rebaja o devolución de un cliente",
                      "Le rebajas a un cliente lo que te debe (descuento, mercancía devuelta, error de factura). No entra dinero."),
    "rebaja_pagar": ("Rebaja o devolución de un proveedor",
                     "Un proveedor te rebaja lo que le debes (descuento, devolviste mercancía). No sale dinero."),
}
REBAJAS = ("rebaja_cobrar", "rebaja_pagar")


def categorias(tipo):
    if tipo in ("ingreso", "cobrar", "rebaja_cobrar"):
        return opciones_cuentas(lambda c: (c["tipo"] == "ingreso" and c["rol"] != "dif_cambio")
                                or (tipo != "ingreso" and c["rol"] == "apertura"))
    if tipo in ("gasto", "pagar", "rebaja_pagar"):
        return opciones_cuentas(lambda c: c["tipo"] == "gasto" or (
            c["tipo"] == "activo" and not c["es_efectivo"] and not c["por_tercero"] and c["rol"] != "inventario")
            or (tipo != "gasto" and c["rol"] == "apertura"))
    if tipo == "movimiento":
        return opciones_cuentas(lambda c: c["tipo"] in ("activo", "pasivo", "patrimonio") and c["rol"] != "inventario"
                                and not c["es_efectivo"] and not (c["rol"] or "").startswith(("cxc_", "cxp_")))
    return []


@app.route("/registrar/<tipo>", methods=["GET", "POST"])
@errores
def registrar(tipo):
    if tipo not in FORMULARIOS:
        abort(404)
    c = conn()
    if request.method == "POST" and not repitiendo():
        fecha = fecha_form()
        tasa = tasa_form(fecha)
        editar = entero(request.form.get("editar"))
        original = asiento_editable(editar, tipo) if editar else None
        if editar and tipo not in ("cobrar", "pagar"):
            c.execute("DELETE FROM lineas WHERE asiento_id = ?", (editar,))  # se rehace abajo
        concepto = (request.form.get("concepto") or "").strip()
        referencia = request.form.get("referencia")
        defecto_t = {"ingreso": "Cliente", "cobrar": "Cliente", "cobro": "Cliente", "rebaja_cobrar": "Cliente"}.get(tipo, "Proveedor")
        if tipo == "movimiento":
            defecto_t = "Persona"
        tercero_id = C.tercero_por_nombre(c, request.form.get("tercero"), defecto_t)
        importe = numero(request.form.get("importe"), 0)
        if importe <= 0:
            raise C.ErrorContable("Escribe un importe mayor que cero.")
        base = C.moneda_base(c)
        caja = None
        apertura = tipo in ("cobro", "pago") and request.form.get("caja") == "apertura"
        if tipo not in ("cobrar", "pagar") + REBAJAS and not apertura:
            caja = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0",
                             (entero(request.form.get("caja")),)).fetchone()
            if not caja:
                raise C.ErrorContable("Elige la caja o banco.")
        mon = (caja["moneda"] or base) if caja else request.form.get("moneda_deuda" if apertura else "moneda")
        validas = {x["id"] for x in categorias(tipo)}
        cat = entero(request.form.get("categoria"))
        if tipo in ("ingreso", "gasto", "cobrar", "pagar", "movimiento") + REBAJAS and cat not in validas:
            raise C.ErrorContable("Elige la cuenta / categoría.")
        if tipo == "ingreso":
            aid = C.crear_asiento(c, fecha, concepto, [
                {"cuenta_id": caja["id"], "importe": importe, "moneda": mon, "tercero_id": tercero_id},
                {"cuenta_id": cat, "importe": -importe, "moneda": mon, "tercero_id": tercero_id},
            ], "ingreso", referencia, tasa=tasa, asiento_id=editar)
        elif tipo == "gasto":
            aid = C.crear_asiento(c, fecha, concepto, [
                {"cuenta_id": cat, "importe": importe, "moneda": mon, "tercero_id": tercero_id},
                {"cuenta_id": caja["id"], "importe": -importe, "moneda": mon, "tercero_id": tercero_id},
            ], "gasto", referencia, tasa=tasa, asiento_id=editar)
        elif tipo in ("cobrar", "pagar"):
            if mon not in C.MONEDAS:
                raise C.ErrorContable("Elige la moneda de la factura.")
            if not concepto:
                raise C.ErrorContable("Escribe el concepto de la factura.")
            venc = (request.form.get("vencimiento") or "").strip() or None
            if venc:
                venc = fecha_form("vencimiento")
            did = C.registrar_documento(c, tipo, tercero_id, fecha, venc, (request.form.get("numero") or "").strip(),
                                        concepto, cat, mon, importe, tasa,
                                        documento_id=original["documento_id"] if original else None)
            aid = c.execute("SELECT asiento_id FROM documentos WHERE id = ?", (did,)).fetchone()[0]
        elif tipo in ("cobro", "pago"):
            elegido = request.form.get("documento") or ""
            doc_id = entero(elegido)
            cuenta_deuda = entero(elegido[2:]) if elegido.startswith("c:") else None
            extra = {}
            if apertura:  # cobro o pago de antes de usar el programa: no toca las cajas de hoy
                extra = {"contra_id": C.cuenta_por_rol(c, "apertura")["id"], "moneda_contra": mon, "origen": tipo}
            aid = C.registrar_cobro_pago(c, tipo, fecha, tercero_id, doc_id, caja["id"] if caja else None, importe,
                                         tasa, concepto, referencia, cuenta_deuda, asiento_id=editar,
                                         anticipo=elegido == "anticipo", moneda_deuda=request.form.get("moneda_deuda"),
                                         **extra)
        elif tipo in REBAJAS:
            if mon not in C.MONEDAS:
                raise C.ErrorContable("Elige la moneda.")
            if not tercero_id:
                raise C.ErrorContable("Escribe a quién se le hace la rebaja.")
            elegido = request.form.get("documento") or ""
            aid = C.registrar_cobro_pago(c, "cobro" if tipo == "rebaja_cobrar" else "pago", fecha, tercero_id,
                                         entero(elegido), None, importe, tasa, concepto, referencia,
                                         asiento_id=editar, anticipo=elegido == "anticipo",
                                         contra_id=cat, moneda_contra=mon, origen=tipo)
        elif tipo == "transferencia":
            destino = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0",
                                (entero(request.form.get("destino")),)).fetchone()
            if not destino or destino["id"] == caja["id"]:
                raise C.ErrorContable("Elige una caja de destino distinta a la de origen.")
            mon_d = destino["moneda"] or base
            recibido = numero(request.form.get("importe_destino"))
            if recibido is None:
                recibido = C.convertir(importe, mon, mon_d, tasa)
            if recibido <= 0:
                raise C.ErrorContable("El importe recibido tiene que ser mayor que cero.")
            b_sal = C.r2(C.convertir(importe, mon, base, tasa))
            b_ent = C.r2(C.convertir(recibido, mon_d, base, tasa))
            lineas = [{"cuenta_id": caja["id"], "importe": -importe, "moneda": mon, "base": -b_sal},
                      {"cuenta_id": destino["id"], "importe": recibido, "moneda": mon_d, "base": b_ent}]
            if abs(b_sal - b_ent) >= 0.01:
                lineas.append({"cuenta_id": C.cuenta_por_rol(c, "dif_cambio")["id"], "importe": b_ent - b_sal,
                               "base": b_sal - b_ent, "moneda": base,
                               "descripcion": "Diferencia entre la tasa del cambio y la tasa del día"})
                lineas[-1]["importe"] = lineas[-1]["base"]
            aid = C.crear_asiento(c, fecha, concepto or f"Transferencia de {caja['nombre']} a {destino['nombre']}",
                                  lineas, "transferencia", referencia, tasa=tasa, asiento_id=editar)
        else:  # movimiento
            signo = 1 if request.form.get("direccion") == "entra" else -1
            aid = C.crear_asiento(c, fecha, concepto, [
                {"cuenta_id": caja["id"], "importe": signo * importe, "moneda": mon, "tercero_id": tercero_id},
                {"cuenta_id": cat, "importe": -signo * importe, "moneda": mon, "tercero_id": tercero_id},
            ], "movimiento", referencia, tasa=tasa, asiento_id=editar)
        c.commit()
        aviso_anticipo()
        if not editar:
            aviso_duplicado(aid)
        tocadas = {r["nombre"] for r in c.execute("SELECT cu.nombre FROM lineas l JOIN cuentas cu ON cu.id = l.cuenta_id"
                                                  " WHERE l.asiento_id = ? AND cu.es_efectivo = 1", (aid,))}
        for nombre_c, saldo_c, mon_c in C.cajas_negativas(c):
            if nombre_c in tocadas:
                flash(f"Atención: {nombre_c} queda en {saldo_c:,.2f} {mon_c}. No se puede tener menos de cero: "
                      "revisa el importe o anota primero el saldo inicial de esa caja.", "error")
        if editar:
            flash("Cambios guardados ✓", "ok")
            return redirect(url_for("asiento", aid=aid))
        numero_a = c.execute("SELECT numero FROM asientos WHERE id = ?", (aid,)).fetchone()[0]
        flash(f"Guardado ✓ (asiento n.º {numero_a}). Puedes anotar otro.", "ok")
        return redirect(url_for("registrar", tipo=tipo, fecha=fecha, caja=request.form.get("caja") or ""))
    titulo, ayuda = FORMULARIOS[tipo]
    f = request.form if repitiendo() else request.args
    editar = entero(f.get("editar"))
    if editar and not repitiendo():
        asiento_editable(editar, tipo)
        f = datos_para_editar(editar)
    if editar:
        titulo = "Modificar: " + titulo[0].lower() + titulo[1:]
    hay_productos = c.execute("SELECT 1 FROM productos WHERE activo = 1 LIMIT 1").fetchone() is not None
    return render_template("registrar.html", tipo=tipo, titulo=titulo, ayuda=ayuda, cats=categorias(tipo),
                           hay_productos=hay_productos,
                           cajas=cajas(), terceros=nombres_terceros(), f=f, editar=editar,
                           tipos_t=C.TIPOS_TERCERO)


# ---------------------------------------------------------------- compra de Zelle

def _texto_pct(p):
    if abs(p["diferencia"]) < 0.005:
        return "sin ganancia ni pérdida"
    return f"{'pérdida' if p['diferencia'] > 0 else 'ganancia'} de {abs(p['diferencia']):,.2f} USD ({abs(p['pct']):.2f} %)"


def datos_zelle(aid):
    """Rellena la pantalla de Zelle con lo que tenía el movimiento guardado."""
    c = conn()
    a = c.execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    ls = c.execute("SELECT l.*, cu.es_efectivo, cu.rol, t.nombre tercero FROM lineas l JOIN cuentas cu ON cu.id = l.cuenta_id"
                   " LEFT JOIN terceros t ON t.id = l.tercero_id WHERE l.asiento_id = ? ORDER BY l.id", (aid,)).fetchall()
    f = {"editar": aid, "fecha": a["fecha"], "tasa": a["tasa"] or "", "concepto": a["concepto"],
         "referencia": a["referencia"] or "", "tercero": next((l["tercero"] for l in ls if l["tercero"]), "")}
    dif = {"USD": 0.0, "CUP": 0.0}
    for l in ls:
        if l["rol"] in ("zelle_ganancia", "zelle_perdida"):
            parte = "CUP" if (l["descripcion"] or "").startswith("Parte CUP") else "USD"
            dif[parte] += l["debe"] - l["haber"]
        elif l["es_efectivo"] and l["importe_orig"] > 0:
            f["destino"] = l["cuenta_id"]
        elif l["es_efectivo"] and l["moneda"] == "CUP":
            f.update(caja_cup=l["cuenta_id"], pago_cup=abs(l["importe_orig"]))
            f["_base_cup"] = l["haber"] - l["debe"]
        elif l["es_efectivo"]:
            f.update(caja_usd=l["cuenta_id"], pago_usd=abs(l["importe_orig"]))
            f["_base_usd"] = l["haber"] - l["debe"]
    if "_base_usd" in f:
        f["zelle_usd"] = C.r2(f.pop("_base_usd") - dif["USD"])
    if "_base_cup" in f:
        f["zelle_cup"] = C.r2(f.pop("_base_cup") - dif["CUP"])
    return f


@app.route("/zelle", methods=["GET", "POST"])
@errores
def zelle():
    """Comprar Zelle pagando en USD, en CUP o una parte en cada uno: calcula el costo (o la ganancia) del cambio."""
    c = conn()
    base = C.moneda_base(c)
    todas = cajas()
    cajas_usd = [x for x in todas if (x["moneda"] or base) == "USD"]
    cajas_cup = [x for x in todas if (x["moneda"] or base) == "CUP"]
    if request.method == "POST" and not repitiendo():
        fecha = fecha_form()
        editar = entero(request.form.get("editar"))
        if editar:
            asiento_editable(editar, "zelle")
            c.execute("DELETE FROM lineas WHERE asiento_id = ?", (editar,))
        destino = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0",
                            (entero(request.form.get("destino")),)).fetchone()
        if not destino or (destino["moneda"] or base) != "USD":
            raise C.ErrorContable("Elige la cuenta Zelle (en USD) donde entra el dinero.")
        zu, pu = numero(request.form.get("zelle_usd"), 0), numero(request.form.get("pago_usd"), 0)
        zc, pc = numero(request.form.get("zelle_cup"), 0), numero(request.form.get("pago_cup"), 0)
        if min(zu, pu, zc, pc) < 0:
            raise C.ErrorContable("Los importes no pueden ser negativos.")
        if bool(zu) != bool(pu):
            raise C.ErrorContable("En la parte en USD escribe las dos cosas: cuánto Zelle recibes y cuántos USD pagas.")
        if bool(zc) != bool(pc):
            raise C.ErrorContable("En la parte en CUP escribe las dos cosas: cuánto Zelle recibes y cuántos CUP pagas.")
        if not zu and not zc:
            raise C.ErrorContable("Escribe al menos una parte: lo que pagas en USD, en CUP o en los dos.")
        tasa = numero(request.form.get("tasa"))
        if zc and (not tasa or tasa <= 0):
            raise C.ErrorContable("Escribe la tasa (CUP por 1 USD) para calcular la parte en CUP.")
        if not tasa:
            tasa = tasa_form(fecha)
        caja_u = caja_c = None
        if zu:
            caja_u = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0",
                               (entero(request.form.get("caja_usd")),)).fetchone()
            if not caja_u or (caja_u["moneda"] or base) != "USD" or caja_u["id"] == destino["id"]:
                raise C.ErrorContable("Elige de qué caja en USD salen los dólares (distinta de la cuenta Zelle).")
        if zc:
            caja_c = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_efectivo = 1 AND es_grupo = 0",
                               (entero(request.form.get("caja_cup")),)).fetchone()
            if not caja_c or (caja_c["moneda"] or base) != "CUP":
                raise C.ErrorContable("Elige de qué caja en CUP salen los pesos.")
        calc = C.calculo_zelle(zu, pu, zc, pc, tasa)
        tercero_id = C.tercero_por_nombre(c, request.form.get("tercero"), "Proveedor")
        a_base = lambda v, m: C.r2(C.convertir(v, m, base, tasa))
        lineas = [{"cuenta_id": destino["id"], "importe": calc["zelle"], "moneda": "USD",
                   "base": a_base(zu, "USD") + a_base(zc, "USD"), "tercero_id": tercero_id,
                   "descripcion": f"Zelle recibido: {calc['zelle']:,.2f}"}]
        ganancia, perdida = C.cuenta_por_rol(c, "zelle_ganancia"), C.cuenta_por_rol(c, "zelle_perdida")
        for mon, caja_x, z, pagado in (("USD", caja_u, zu, pu), ("CUP", caja_c, zc, pc)):
            if not z:
                continue
            b_pag, b_z = a_base(pagado, mon), a_base(z, "USD")
            lineas.append({"cuenta_id": caja_x["id"], "importe": -pagado, "moneda": mon, "base": -b_pag, "tercero_id": tercero_id})
            d = C.r2(b_pag - b_z)
            if abs(d) >= 0.01:
                p = calc["partes"][mon]
                texto = (f"Parte {mon}: {pagado:,.2f} {mon}" + (f" (= {p['equivale']:,.2f} USD a {tasa:g})" if mon == "CUP" else "")
                         + f" por {z:,.2f} Zelle: {_texto_pct(p)}")
                lineas.append({"cuenta_id": (perdida if d > 0 else ganancia)["id"], "importe": d, "moneda": base,
                               "base": d, "descripcion": texto})
        concepto = (request.form.get("concepto") or "").strip() or f"Compra de {calc['zelle']:,.2f} Zelle"
        aid = C.crear_asiento(c, fecha, concepto, lineas, "zelle", request.form.get("referencia"), tasa=tasa,
                              asiento_id=editar)
        c.commit()
        if not editar:
            aviso_duplicado(aid)
        partes = " · ".join(f"parte {m}: {_texto_pct(p)}" for m, p in calc["partes"].items())
        flash(f"Guardado ✓ Compraste {calc['zelle']:,.2f} Zelle. {partes[:1].upper() + partes[1:]}."
              + (f" Total: {_texto_pct(calc)}." if len(calc["partes"]) > 1 else ""), "ok")
        return redirect(url_for("asiento", aid=aid))
    f = request.form if repitiendo() else request.args
    editar = entero(f.get("editar"))
    if editar and not repitiendo():
        asiento_editable(editar, "zelle")
        f = datos_zelle(editar)
    zelles = [x for x in cajas_usd if "zelle" in x["nombre"].lower()]
    return render_template("zelle.html", f=f, editar=editar, cajas_usd=cajas_usd, cajas_cup=cajas_cup,
                           destino_def=(zelles[0]["id"] if zelles else None), terceros=nombres_terceros())


FORM_DE_ORIGEN = {"ingreso": "ingreso", "gasto": "gasto", "factura_cobrar": "cobrar", "factura_pagar": "pagar",
                  "cobro": "cobro", "pago": "pago", "transferencia": "transferencia", "movimiento": "movimiento",
                  "manual": "manual", "saldo_inicial": "manual", "rebaja_cobrar": "rebaja_cobrar",
                  "rebaja_pagar": "rebaja_pagar", "zelle": "zelle"}


def asiento_editable(aid, tipo):
    a = conn().execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a:
        raise C.ErrorContable("Ese movimiento ya no existe.")
    if a["anulado"]:
        raise C.ErrorContable("Ese movimiento está anulado; no se puede modificar (puedes eliminarlo).")
    if a["origen"] == "ajuste_cambio":
        raise C.ErrorContable("Un ajuste por tasa de cambio no se modifica: elimínalo y vuelve a calcularlo.")
    import inventario
    if a["origen"] in inventario.ORIGENES_INV or inventario.movs_de_asiento(conn(), aid):
        raise C.ErrorContable("Este movimiento es del inventario: para cambiarlo, elimínalo y anótalo de nuevo "
                              "desde Inventario (así la existencia queda bien).")
    if FORM_DE_ORIGEN.get(a["origen"]) != tipo:
        raise C.ErrorContable("Ese movimiento no es de este tipo.")
    return a


def datos_para_editar(aid):
    """Rellena el formulario con lo que tenía el movimiento."""
    c = conn()
    a = c.execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    ls = c.execute("SELECT l.*, cu.es_efectivo, cu.rol, cu.por_tercero, t.nombre tercero FROM lineas l JOIN cuentas cu ON cu.id = l.cuenta_id"
                   " LEFT JOIN terceros t ON t.id = l.tercero_id WHERE l.asiento_id = ? ORDER BY l.id", (aid,)).fetchall()
    f = {"editar": aid, "fecha": a["fecha"], "tasa": a["tasa"] or "", "concepto": a["concepto"],
         "referencia": a["referencia"] or "", "tercero": next((l["tercero"] for l in ls if l["tercero"]), "")}
    cajas_l = [l for l in ls if l["es_efectivo"]]
    otras = [l for l in ls if not l["es_efectivo"] and l["rol"] != "dif_cambio"]
    origen = a["origen"]
    if origen in ("factura_cobrar", "factura_pagar"):
        d = c.execute("SELECT * FROM documentos WHERE id = ?", (a["documento_id"],)).fetchone()
        f.update(numero=d["numero"] or "", vencimiento=d["vencimiento"] or "", categoria=d["cuenta_id"],
                 moneda=d["moneda"], importe=d["importe"], tasa=d["tasa"], concepto=d["concepto"], fecha=d["fecha"])
    elif origen in REBAJAS:
        contra = next((l for l in ls if not l["por_tercero"] and l["rol"] != "dif_cambio"), None)
        if contra:
            f.update(categoria=contra["cuenta_id"], moneda=contra["moneda"], importe=abs(contra["importe_orig"]))
        docs = {l["documento_id"] for l in ls if l["documento_id"]}
        f["documento"] = docs.pop() if len(docs) == 1 else ("" if docs else "anticipo")
    elif origen == "transferencia":
        sale = next((l for l in cajas_l if l["importe_orig"] < 0), None)
        entra = next((l for l in cajas_l if l["importe_orig"] > 0), None)
        f.update(caja=sale["cuenta_id"] if sale else "", importe=abs(sale["importe_orig"]) if sale else "",
                 destino=entra["cuenta_id"] if entra else "", importe_destino=entra["importe_orig"] if entra else "")
    else:
        caja = cajas_l[0] if cajas_l else None
        if caja:
            f.update(caja=caja["cuenta_id"], importe=abs(caja["importe_orig"]))
        if otras:
            f["categoria"] = otras[0]["cuenta_id"]
        if origen == "movimiento" and caja:
            f["direccion"] = "entra" if caja["importe_orig"] > 0 else "sale"
        if origen in ("cobro", "pago"):
            ap = next((l for l in ls if l["rol"] == "apertura"), None)
            if ap and not caja:
                f.update(caja="apertura", importe=abs(ap["importe_orig"]))
            deuda = next((l for l in ls if l["por_tercero"] and not l["es_efectivo"]), None)
            if deuda:
                f["moneda_deuda"] = deuda["moneda"]
            docs = {l["documento_id"] for l in ls if l["documento_id"]}
            if len(docs) == 1:
                f["documento"] = docs.pop()
            elif docs:
                f["documento"] = ""  # repartido entre varias facturas: automático
            elif otras and not (otras[0]["rol"] or "").startswith(("cxc_", "cxp_")):
                f["documento"] = f"c:{otras[0]['cuenta_id']}"
            else:
                f["documento"] = "anticipo"
    return f


@app.route("/asientos/<int:aid>/editar")
@errores
def editar_asiento(aid):
    a = conn().execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a:
        abort(404)
    tipo = FORM_DE_ORIGEN.get(a["origen"], "manual")
    asiento_editable(aid, tipo)
    if tipo == "manual":
        return redirect(url_for("asiento_nuevo", editar=aid))
    if tipo == "zelle":
        return redirect(url_for("zelle", editar=aid))
    return redirect(url_for("registrar", tipo=tipo, editar=aid))


@app.route("/asientos/<int:aid>/eliminar", methods=["POST"])
@errores
def eliminar(aid):
    a = conn().execute("SELECT numero, concepto FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a:
        abort(404)
    C.eliminar_asiento(conn(), aid)
    conn().commit()
    evento("Eliminó un movimiento", f"n.º {a['numero']}: {a['concepto']}")
    flash(f"Movimiento n.º {a['numero']} eliminado.", "ok")
    destino = request.form.get("volver") or ""
    return redirect(destino if destino.startswith("/") and not destino.startswith("//") else url_for("diario"))


@app.route("/asiento/nuevo", methods=["GET", "POST"])
@errores
def asiento_nuevo():
    c = conn()
    if request.method == "POST" and not repitiendo():
        fecha = fecha_form()
        tasa = tasa_form(fecha)
        editar = entero(request.form.get("editar"))
        origen = "manual"
        if editar:
            origen = asiento_editable(editar, "manual")["origen"]
        lineas = []
        cuentas_f = request.form.getlist("cuenta[]")
        for i, cid in enumerate(cuentas_f):
            if not cid:
                continue
            debe = numero(request.form.getlist("debe[]")[i], 0)
            haber = numero(request.form.getlist("haber[]")[i], 0)
            if debe < 0 or haber < 0:
                raise C.ErrorContable("No uses números negativos: pon el importe en Debe o en Haber.")
            if debe and haber:
                raise C.ErrorContable("Cada línea va en Debe o en Haber, no en las dos.")
            nombre_t = request.form.getlist("tercero[]")[i]
            lineas.append({"cuenta_id": entero(cid), "importe": debe - haber,
                           "moneda": request.form.getlist("moneda[]")[i],
                           "tercero_id": C.tercero_por_nombre(c, nombre_t, "Otro"),
                           "descripcion": request.form.getlist("descripcion[]")[i] or None})
        aid = C.crear_asiento(c, fecha, request.form.get("concepto"), lineas, origen,
                              request.form.get("referencia"), tasa=tasa, asiento_id=editar)
        c.commit()
        flash("Cambios guardados ✓" if editar else "Asiento guardado ✓", "ok")
        return redirect(url_for("asiento", aid=aid))
    hojas = opciones_cuentas(lambda x: True)
    filas = []
    if repitiendo():
        for i, cid in enumerate(request.form.getlist("cuenta[]")):
            filas.append({k: request.form.getlist(k + "[]")[i] for k in ("cuenta", "tercero", "moneda", "debe", "haber", "descripcion")})
    f = request.form if repitiendo() else {}
    editar = entero(request.form.get("editar") if repitiendo() else request.args.get("editar"))
    if editar and not repitiendo():
        a = asiento_editable(editar, "manual")
        f = {"editar": editar, "fecha": a["fecha"], "tasa": a["tasa"] or "", "concepto": a["concepto"],
             "referencia": a["referencia"] or ""}
        for l in c.execute("SELECT l.*, t.nombre tercero FROM lineas l LEFT JOIN terceros t ON t.id = l.tercero_id"
                           " WHERE l.asiento_id = ? ORDER BY l.id", (editar,)):
            v = abs(l["importe_orig"])
            filas.append({"cuenta": l["cuenta_id"], "tercero": l["tercero"] or "", "moneda": l["moneda"],
                          "debe": v if l["importe_orig"] > 0 else "", "haber": v if l["importe_orig"] < 0 else "",
                          "descripcion": l["descripcion"] or ""})
    return render_template("asiento_nuevo.html", cuentas=hojas, terceros=nombres_terceros(),
                           f=f, filas=filas, editar=editar)


@app.route("/saldos-iniciales", methods=["GET", "POST"])
@errores
def saldos_iniciales():
    c = conn()
    lista = cajas()
    if request.method == "POST" and not repitiendo():
        fecha = fecha_form()
        tasa = tasa_form(fecha)
        base = C.moneda_base(c)
        lineas = []
        for caja in lista:
            v = numero(request.form.get(f"caja_{caja['id']}"), 0)
            if v:
                mon = caja["moneda"] or base
                lineas.append({"cuenta_id": caja["id"], "importe": v, "moneda": mon,
                               "base": C.r2(C.convertir(v, mon, base, tasa))})
        if not lineas:
            flash("No escribiste ningún saldo. Puedes hacerlo más tarde desde Configuración.", "ok")
            return redirect(url_for("panel"))
        total = C.r2(sum(l["base"] for l in lineas))
        lineas.append({"cuenta_id": C.cuenta_por_rol(c, "capital")["id"], "importe": -total, "base": -total,
                       "moneda": base})
        C.crear_asiento(c, fecha, "Saldos iniciales de efectivo", lineas, "saldo_inicial", tasa=tasa)
        c.commit()
        flash("Saldos iniciales guardados ✓", "ok")
        return redirect(url_for("panel"))
    ya = c.execute("SELECT COUNT(*) FROM asientos WHERE origen = 'saldo_inicial' AND anulado = 0").fetchone()[0]
    return render_template("saldos_iniciales.html", cajas=lista, ya=ya, tasa=C.tasa_del_dia(c))


# ---------------------------------------------------------------- diario, asientos, facturas

@app.route("/diario")
def diario():
    c = conn()
    desde = request.args.get("desde") or f"{date.today().year}-01-01"
    hasta = request.args.get("hasta") or C.hoy()
    texto = (request.args.get("q") or "").strip()
    origen = request.args.get("origen") or ""
    q = ("SELECT DISTINCT a.* FROM asientos a LEFT JOIN lineas l ON l.asiento_id = a.id"
         " LEFT JOIN terceros t ON t.id = l.tercero_id LEFT JOIN cuentas cu ON cu.id = l.cuenta_id"
         " WHERE a.fecha >= ? AND a.fecha <= ?")
    p = [desde, hasta]
    if texto:
        q += " AND (a.concepto LIKE ? OR a.referencia LIKE ? OR t.nombre LIKE ? OR cu.nombre LIKE ? OR a.numero = ?)"
        like = f"%{texto}%"
        p += [like, like, like, like, entero(texto) or -1]
    if origen:
        q += " AND a.origen = ?"
        p.append(origen)
    if not request.args.get("anulados"):
        q += " AND a.anulado = 0"
    asientos = [dict(a) for a in c.execute(q + " ORDER BY a.fecha DESC, a.numero DESC LIMIT 400", p)]
    for a in asientos:
        a["lineas"] = lineas_de(a["id"])
    return render_template("diario.html", asientos=asientos, desde=desde, hasta=hasta, q=texto, origen=origen)


def lineas_de(aid):
    return [dict(x) for x in conn().execute(
        "SELECT l.*, c.codigo, c.nombre cuenta, t.nombre tercero FROM lineas l JOIN cuentas c ON c.id = l.cuenta_id"
        " LEFT JOIN terceros t ON t.id = l.tercero_id WHERE l.asiento_id = ? ORDER BY l.debe = 0, l.id", (aid,))]


@app.route("/asientos/<int:aid>")
def asiento(aid):
    a = conn().execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a:
        abort(404)
    return render_template("asiento.html", a=a, lineas=lineas_de(aid), repetible=repetible(a))


def repetible(a):
    import inventario
    return (not a["anulado"] and FORM_DE_ORIGEN.get(a["origen"]) not in (None, "manual")
            and a["origen"] not in inventario.ORIGENES_INV and not inventario.movs_de_asiento(conn(), a["id"]))


@app.route("/asientos/<int:aid>/repetir")
@errores
def repetir(aid):
    """Abre el mismo formulario relleno con lo de ese movimiento y la fecha de hoy (alquiler, salarios, corriente…)."""
    a = conn().execute("SELECT * FROM asientos WHERE id = ?", (aid,)).fetchone()
    if not a:
        abort(404)
    if not repetible(a):
        raise C.ErrorContable("Este movimiento no se puede repetir así: anótalo de nuevo desde Anotar.")
    f = datos_zelle(aid) if a["origen"] == "zelle" else datos_para_editar(aid)
    f = {k: v for k, v in f.items() if v not in (None, "") and k not in ("editar", "numero", "vencimiento", "tasa")}
    f["fecha"] = C.hoy()
    if f.get("documento") not in (None, "anticipo") and not str(f.get("documento", "")).startswith("c:"):
        f["documento"] = ""  # la factura de entonces ya está pagada: automático
    from urllib.parse import urlencode
    destino = "/zelle" if a["origen"] == "zelle" else f"/registrar/{FORM_DE_ORIGEN[a['origen']]}"
    flash(f"Repitiendo el movimiento n.º {a['numero']} con fecha de hoy: revisa el importe y guarda.", "ok")
    return redirect(destino + "?" + urlencode(f))


@app.route("/asientos/<int:aid>/anular", methods=["POST"])
@errores
def anular(aid):
    C.anular_asiento(conn(), aid, (request.form.get("motivo") or "").strip())
    conn().commit()
    flash("Movimiento anulado. Ya no cuenta en ningún informe.", "ok")
    return redirect(url_for("asiento", aid=aid))


@app.route("/facturas")
def facturas():
    tipo = "pagar" if request.args.get("tipo") == "pagar" else "cobrar"
    vista = request.args.get("vista") or "personas"
    estado = request.args.get("estado") or "pendientes"
    if vista == "personas":
        filas, totales = C.resumen_lado(conn(), tipo, todos=estado == "todas")
        return render_template("cuentas_lado.html", tipo=tipo, filas=filas, totales=totales, estado=estado)
    docs = C.documentos(conn(), tipo, solo_pendientes=(estado == "pendientes"))
    docs.reverse()
    return render_template("facturas.html", docs=docs, tipo=tipo, estado=estado)


@app.route("/estado-cuenta/<lado>/<int:tid>")
def estado_cuenta(lado, tid):
    if lado not in ("cobrar", "pagar"):
        abort(404)
    c = conn()
    t = c.execute("SELECT * FROM terceros WHERE id = ?", (tid,)).fetchone()
    if not t:
        abort(404)
    desde = request.args.get("desde") or None
    if desde:
        try:
            datetime.strptime(desde, "%Y-%m-%d")
        except ValueError:
            desde = None
    ec = C.estado_cuenta(c, tid, lado, desde)
    if request.args.get("formato") == "xlsx":
        from exportar import estado_cuenta_excel
        return send_file(estado_cuenta_excel(ec, t["nombre"], lado, C.nombre_empresa(c)), as_attachment=True,
                         download_name=f"Estado de cuenta {t['nombre']}.xlsx",
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    return render_template("estado_cuenta.html", t=t, lado=lado, ec=ec, desde=desde or "")


@app.route("/facturas/<int:did>")
def factura(did):
    d = conn().execute("SELECT * FROM documentos WHERE id = ?", (did,)).fetchone()
    if not d:
        abort(404)
    lista = [x for x in C.documentos(conn(), d["tipo"], d["tercero_id"]) if x["id"] == did]
    info = lista[0] if lista else dict(d, pendiente=0, pagado=0, estado="Anulada", tercero="", cuenta="", vencida=False)
    if d["anulado"]:
        info["estado"] = "Anulada"
    t = conn().execute("SELECT * FROM terceros WHERE id = ?", (d["tercero_id"],)).fetchone()
    movs = [dict(x) for x in conn().execute(
        "SELECT a.*, l.importe_orig, l.moneda FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " WHERE l.documento_id = ? ORDER BY a.fecha, a.id", (did,))]
    return render_template("factura.html", d=info, t=t, movs=movs)


@app.route("/facturas/<int:did>/anular", methods=["POST"])
@errores
def anular_factura(did):
    C.anular_documento(conn(), did, (request.form.get("motivo") or "").strip())
    conn().commit()
    flash("Factura anulada.", "ok")
    return redirect(url_for("factura", did=did))


# ---------------------------------------------------------------- cuentas

@app.route("/cuentas")
def cuentas():
    c = conn()
    todas = C.cuentas(c)
    mov = C.movimientos(c)
    saldos = {}
    for x in todas:
        d, h, o = mov.get(x["id"], (0, 0, 0))
        saldos[x["id"]] = (C.r2(C.natural(x["tipo"], d, h)), C.r2(o))
    for x in todas:
        if x["es_grupo"]:
            saldos[x["id"]] = (C.r2(sum(saldos[h["id"]][0] for h in todas if h["padre_id"] == x["id"])), None)
    return render_template("cuentas.html", cuentas=todas, saldos=saldos)


@app.route("/cuentas/nueva", methods=["GET", "POST"])
@app.route("/cuentas/<int:cid>/editar", methods=["GET", "POST"])
@errores
def cuenta_editar(cid=None):
    c = conn()
    actual = dict(c.execute("SELECT * FROM cuentas WHERE id = ?", (cid,)).fetchone() or {}) if cid else {}
    if cid and not actual:
        abort(404)
    grupos = [x for x in C.cuentas(c) if x["es_grupo"]]
    if request.method == "POST" and not repitiendo():
        f = request.form
        nombre = (f.get("nombre") or "").strip()
        codigo = (f.get("codigo") or "").strip()
        if not nombre or not codigo:
            raise C.ErrorContable("Escribe el código y el nombre.")
        if not re.fullmatch(r"[0-9A-Za-z.\-]+", codigo):
            raise C.ErrorContable("El código solo puede tener números, letras, puntos y guiones.")
        es_grupo = 1 if (f.get("es_grupo") == "1" if not cid else actual["es_grupo"]) else 0
        moneda = f.get("moneda") if f.get("moneda") in C.MONEDAS else None
        if es_grupo:
            padre = None
            tipo = f.get("tipo")
            if tipo not in C.SECCIONES:
                raise C.ErrorContable("Elige el tipo.")
            seccion = f.get("seccion_" + tipo)
            if seccion not in dict(C.SECCIONES[tipo]):
                raise C.ErrorContable("Elige la sección.")
            moneda = None
        else:
            padre = c.execute("SELECT * FROM cuentas WHERE id = ? AND es_grupo = 1", (entero(f.get("padre")),)).fetchone()
            if not padre:
                raise C.ErrorContable("Elige el grupo al que pertenece la cuenta.")
            tipo, seccion, padre = padre["tipo"], padre["seccion"], padre["id"]
        flujo = f.get("flujo") if f.get("flujo") in C.FLUJOS else "operacion"
        efectivo = 1 if f.get("es_efectivo") and tipo == "activo" and not es_grupo else 0
        por_t = 1 if f.get("por_tercero") and tipo in ("activo", "pasivo") and not efectivo else 0
        activa = 1 if f.get("activa", "1") == "1" else 0
        if cid:
            usos = c.execute("SELECT COUNT(*) FROM lineas WHERE cuenta_id = ?", (cid,)).fetchone()[0]
            if usos and (moneda or None) != (actual["moneda"] or None):
                raise C.ErrorContable("No se puede cambiar la moneda de una cuenta que ya tiene movimientos.")
            if actual["rol"] and not activa:
                raise C.ErrorContable("Esta cuenta la usa el sistema; no se puede desactivar.")
            if actual["rol"] and (moneda or None) != (actual["moneda"] or None):
                raise C.ErrorContable("Esta cuenta la usa el sistema; no se puede cambiar su moneda.")
            if actual["rol"] and (tipo != actual["tipo"]):
                raise C.ErrorContable("Esta cuenta la usa el sistema; no se puede cambiar de tipo.")
            if not actual["rol"] and actual["por_tercero"] and not por_t and usos:
                pass
            try:
                c.execute("UPDATE cuentas SET codigo=?, nombre=?, tipo=?, seccion=?, padre_id=?, moneda=?, es_efectivo=?,"
                          " por_tercero=?, flujo=?, activa=? WHERE id=?",
                          (codigo, nombre, tipo, seccion, padre, moneda, efectivo, por_t, flujo, activa, cid))
            except Exception:
                raise C.ErrorContable("Ya existe otra cuenta con ese código.")
            if es_grupo:
                hijos_con_rol = c.execute("SELECT COUNT(*) FROM cuentas WHERE padre_id = ? AND rol IS NOT NULL AND tipo != ?",
                                          (cid, tipo)).fetchone()[0]
                if hijos_con_rol:
                    raise C.ErrorContable("Este grupo tiene cuentas del sistema; no se puede cambiar de tipo.")
                c.execute("UPDATE cuentas SET tipo = ?, seccion = ? WHERE padre_id = ?", (tipo, seccion, cid))
        else:
            try:
                cid = c.execute("INSERT INTO cuentas (codigo, nombre, tipo, seccion, padre_id, es_grupo, moneda,"
                                " es_efectivo, por_tercero, flujo, activa) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                                (codigo, nombre, tipo, seccion, padre, es_grupo, moneda, efectivo, por_t, flujo,
                                 activa)).lastrowid
            except Exception:
                raise C.ErrorContable("Ya existe una cuenta con ese código.")
        c.commit()
        flash("Cuenta guardada ✓", "ok")
        return redirect(url_for("cuentas") + f"#c{cid}")
    sugerido = ""
    if not cid and request.args.get("padre"):
        p = c.execute("SELECT codigo FROM cuentas WHERE id = ?", (entero(request.args.get("padre")),)).fetchone()
        if p:
            hijos = [x["codigo"] for x in c.execute("SELECT codigo FROM cuentas WHERE codigo LIKE ?", (p["codigo"] + ".%",))]
            nums = [int(h.rsplit(".", 1)[1]) for h in hijos if h.rsplit(".", 1)[1].isdigit()]
            sugerido = f"{p['codigo']}.{(max(nums) + 1 if nums else 1):02d}"
    datos = request.form if repitiendo() else actual
    return render_template("cuenta_form.html", c=actual, d=datos, grupos=grupos, sugerido=sugerido,
                           padre=entero(request.args.get("padre")), es_grupo_nuevo=request.args.get("grupo") == "1")


@app.route("/cuentas/<int:cid>")
def cuenta(cid):
    c = conn()
    cu = c.execute("SELECT * FROM cuentas WHERE id = ?", (cid,)).fetchone()
    if not cu:
        abort(404)
    desde = request.args.get("desde") or f"{date.today().year}-01-01"
    hasta = request.args.get("hasta") or C.hoy()
    ids = [cid] + [x["id"] for x in c.execute("SELECT id FROM cuentas WHERE padre_id = ?", (cid,))]
    marcas = ",".join("?" * len(ids))
    ini = c.execute(f"SELECT COALESCE(SUM(l.debe),0), COALESCE(SUM(l.haber),0), COALESCE(SUM(l.importe_orig),0)"
                    f" FROM lineas l JOIN asientos a ON a.id = l.asiento_id WHERE a.anulado = 0 AND l.cuenta_id IN ({marcas})"
                    f" AND a.fecha < ?", ids + [desde]).fetchone()
    saldo = C.natural(cu["tipo"], ini[0], ini[1])
    saldo_o = ini[2] if cu["tipo"] in ("activo", "gasto") else -ini[2]
    filas = []
    for x in c.execute(f"SELECT l.*, a.fecha, a.numero, a.concepto, a.id aid, t.nombre tercero, cc.nombre cuenta"
                       f" FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cc ON cc.id = l.cuenta_id"
                       f" LEFT JOIN terceros t ON t.id = l.tercero_id"
                       f" WHERE a.anulado = 0 AND l.cuenta_id IN ({marcas}) AND a.fecha >= ? AND a.fecha <= ?"
                       f" ORDER BY a.fecha, a.numero, l.id", ids + [desde, hasta]):
        x = dict(x)
        saldo += C.natural(cu["tipo"], x["debe"], x["haber"])
        saldo_o += x["importe_orig"] if cu["tipo"] in ("activo", "gasto") else -x["importe_orig"]
        x["saldo"] = C.r2(saldo)
        x["saldo_o"] = C.r2(saldo_o)
        filas.append(x)
    inicial = (C.r2(C.natural(cu["tipo"], ini[0], ini[1])), C.r2(ini[2] if cu["tipo"] in ("activo", "gasto") else -ini[2]))
    return render_template("cuenta.html", cu=cu, filas=filas, desde=desde, hasta=hasta, inicial=inicial,
                           grupo=bool(cu["es_grupo"]))


# ---------------------------------------------------------------- terceros

@app.route("/terceros")
def terceros():
    c = conn()
    tipo = request.args.get("tipo") or ""
    q = "SELECT * FROM terceros"
    p = []
    if tipo:
        q += " WHERE tipo = ?"
        p.append(tipo)
    lista = [dict(t) for t in c.execute(q + " ORDER BY activo DESC, nombre", p)]
    cobrar = {t["id"]: t["saldo"] for t in C.saldos_terceros(c, "cobrar")}
    pagar = {t["id"]: t["saldo"] for t in C.saldos_terceros(c, "pagar")}
    for t in lista:
        t["cobrar"] = cobrar.get(t["id"], 0)
        t["pagar"] = pagar.get(t["id"], 0)
    return render_template("terceros.html", lista=lista, tipo=tipo)


@app.route("/terceros/nuevo", methods=["GET", "POST"])
@app.route("/terceros/<int:tid>/editar", methods=["GET", "POST"])
@errores
def tercero_editar(tid=None):
    c = conn()
    actual = dict(c.execute("SELECT * FROM terceros WHERE id = ?", (tid,)).fetchone() or {}) if tid else {}
    if tid and not actual:
        abort(404)
    if request.method == "POST" and not repitiendo():
        f = request.form
        nombre = " ".join((f.get("nombre") or "").split())
        if not nombre:
            raise C.ErrorContable("Escribe el nombre.")
        otro = c.execute("SELECT id FROM terceros WHERE lower(nombre) = lower(?) AND id != ?", (nombre, tid or 0)).fetchone()
        if otro:
            raise C.ErrorContable("Ya existe alguien con ese nombre.")
        valores = (nombre, f.get("tipo") if f.get("tipo") in C.TIPOS_TERCERO else "Otro",
                   f.get("documento"), f.get("telefono"), f.get("email"), f.get("direccion"), f.get("notas"),
                   1 if f.get("activo", "1") == "1" else 0)
        if tid:
            c.execute("UPDATE terceros SET nombre=?, tipo=?, documento=?, telefono=?, email=?, direccion=?, notas=?,"
                      " activo=? WHERE id=?", valores + (tid,))
        else:
            tid = c.execute("INSERT INTO terceros (nombre, tipo, documento, telefono, email, direccion, notas, activo)"
                            " VALUES (?,?,?,?,?,?,?,?)", valores).lastrowid
        c.commit()
        flash("Guardado ✓", "ok")
        return redirect(url_for("tercero", tid=tid))
    return render_template("tercero_form.html", t=actual, d=request.form if repitiendo() else actual)


@app.route("/terceros/<int:tid>")
def tercero(tid):
    c = conn()
    t = c.execute("SELECT * FROM terceros WHERE id = ?", (tid,)).fetchone()
    if not t:
        abort(404)
    docs = C.documentos(c, tercero_id=tid)
    docs.reverse()
    movs = []
    saldos = {}
    for x in c.execute(
            "SELECT l.*, a.fecha, a.numero, a.concepto, a.id aid, cu.nombre cuenta, cu.tipo ctipo, cu.moneda cmon"
            " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cu ON cu.id = l.cuenta_id"
            " WHERE a.anulado = 0 AND l.tercero_id = ? AND cu.por_tercero = 1 ORDER BY a.fecha, a.numero, l.id", (tid,)):
        x = dict(x)
        clave = x["cuenta"]
        s = saldos.get(clave, 0) + (x["debe"] - x["haber"]) * (1 if x["ctipo"] == "activo" else -1)
        saldos[clave] = s
        x["saldo"] = C.r2(s)
        movs.append(x)
    movs.reverse()
    anio = date.today().year
    totales = c.execute(
        "SELECT cu.tipo, SUM(CASE WHEN cu.tipo='gasto' THEN l.debe-l.haber ELSE l.haber-l.debe END) v"
        " FROM lineas l JOIN asientos a ON a.id = l.asiento_id JOIN cuentas cu ON cu.id = l.cuenta_id"
        " WHERE a.anulado = 0 AND l.tercero_id = ? AND cu.tipo IN ('ingreso','gasto') AND a.fecha >= ?"
        " GROUP BY cu.tipo", (tid, f"{anio}-01-01")).fetchall()
    estados = []
    for lado in ("cobrar", "pagar"):
        ec = C.estado_cuenta(c, tid, lado)
        if ec["cargos"] or ec["pagos"]:
            estados.append((lado, ec))
    return render_template("tercero.html", t=t, docs=docs, movs=movs[:300], estados=estados,
                           saldos={k: C.r2(v) for k, v in saldos.items() if abs(v) >= 0.005},
                           totales={x["tipo"]: C.r2(x["v"]) for x in totales}, anio=anio)


# ---------------------------------------------------------------- informes

INFORMES = {
    "completo": "Informe financiero del período (todo junto)",
    "resultados": "Estado de resultados (ganancias y pérdidas)",
    "balance": "Balance general (situación financiera)",
    "flujo": "Flujo de efectivo",
    "patrimonio": "Cambios en el patrimonio",
    "gastos": "Informe de gastos agrupados y desglosados",
    "ingresos": "Informe de ingresos agrupados y desglosados",
    "pagar": "Cuentas por pagar por proveedor / persona / institución",
    "cobrar": "Cuentas por cobrar por cliente / persona / institución",
    "indicadores": "Indicadores financieros",
    "balanza": "Balanza de comprobación",
}


PESTANAS = [("resultados", "Resultados"), ("balance", "Balance"), ("flujo", "Flujo de efectivo"),
            ("indicadores", "Indicadores"), ("gastos", "Gastos"), ("ingresos", "Ingresos")]
PERIODOS = [("anual", "Anual", 5), ("trimestral", "Trimestral", 8), ("mensual", "Mensual", 12),
            ("ltm", "Últimos 12 meses", 5)]


@app.route("/estados")
def estados():
    """Estados financieros estilo terminal (TIKR): períodos en columnas."""
    c = conn()
    a = request.args
    tab = a.get("tab") if a.get("tab") in dict(PESTANAS) else "resultados"
    periodo = a.get("periodo") if a.get("periodo") in [p[0] for p in PERIODOS] else "anual"
    n = entero(a.get("n")) or dict((p[0], p[2]) for p in PERIODOS)[periodo]
    n = min(max(n, 1), 24)
    hasta = a.get("hasta") or C.hoy()
    try:
        datetime.strptime(hasta, "%Y-%m-%d")
    except ValueError:
        hasta = C.hoy()
    g.escala = 1000 if a.get("unidades") == "miles" else 1
    detalle = a.get("detalle", "1") != "0"
    cols = C.columnas_terminal(c, periodo, n, hasta)
    per = C.per_terminal(cols)
    res, datos = C.informe_resultados_terminal(c, cols, detalle)
    if tab == "resultados":
        tablas = [res]
    elif tab == "balance":
        inf = C.informe_balance(c, per)[0]
        inf.columnas = [x[2] for x in cols]
        inf.titulo, inf.subtitulo = "Balance general", "Saldos al cierre de cada período"
        tablas = [inf]
    elif tab == "flujo":
        tablas = [C.informe_flujo(c, per)]
    elif tab == "indicadores":
        tablas = [C.indicadores_terminal(c, cols)]
    else:
        tablas = [C.informe_por_tipo(c, per, "gasto" if tab == "gastos" else "ingreso", con_total=False)]
    if a.get("formato") == "xlsx":
        g.escala = 1
        return send_file(a_excel(tablas, C.nombre_empresa(c)), as_attachment=True,
                         download_name=f"{tab}_{periodo}_{cols[0][0]}_{cols[-1][1]}.xlsx",
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    neto = datos["neto"]
    cambio = C._cambio(neto)[-1] if len(neto) > 1 else None
    return render_template("estados.html", tablas=tablas, tab=tab, periodo=periodo, n=n, hasta=hasta,
                           detalle=detalle, unidades=a.get("unidades") or "", cols=cols, PESTANAS=PESTANAS,
                           PERIODOS=PERIODOS, nombre_periodo=dict((p[0], p[1]) for p in PERIODOS)[periodo], neto=neto[-1], cambio=cambio, tasa=C.tasa_del_dia(c, hasta),
                           args=a.to_dict())


@app.route("/informes")
def informes():
    return render_template("informes.html", informes=INFORMES)


def comentario(conn_, per, resultados):
    """Unas frases en palabras simples sobre el período."""
    filas = {f["etiqueta"]: f["valores"] for f in resultados.filas}
    ing = filas.get("Total ingresos de operación", [0, 0])
    neto = filas.get("RESULTADO NETO DEL PERÍODO", [0, 0])
    base = C.moneda_base(conn_)
    frases = []
    if ing and len(ing) >= 2 and isinstance(ing[1], (int, float)):
        if abs(ing[1]) > 0.004:
            cambio = (ing[0] - ing[1]) / abs(ing[1]) * 100
            frases.append(f"Los ingresos de operación fueron {fmt_dinero(ing[0])} {base}, "
                          f"{'un ' + format(abs(cambio), '.1f') + ' % más' if cambio >= 0 else 'un ' + format(abs(cambio), '.1f') + ' % menos'}"
                          f" que en {per['anterior'][2]}.")
        else:
            frases.append(f"Los ingresos de operación fueron {fmt_dinero(ing[0])} {base}.")
    if neto:
        if neto[0] >= 0:
            frases.append(f"El negocio ganó {fmt_dinero(neto[0])} {base} en el período.")
        else:
            frases.append(f"El negocio perdió {fmt_dinero(-neto[0])} {base} en el período.")
    return frases


@app.route("/informes/<nombre>")
def informe(nombre):
    if nombre not in INFORMES:
        abort(404)
    c = conn()
    args = request.args.to_dict()
    if nombre in ("gastos", "ingresos") and "vista" not in args:
        args["vista"] = "evolucion" if args.get("modo") in ("anio", "trimestre") else "simple"
    if nombre in ("patrimonio", "indicadores", "balanza", "completo"):
        args.setdefault("vista", "comparar")
    per = C.leer_periodo(args)
    ocultar = request.args.get("ceros") != "1"
    tablas = []
    extra = {}
    if nombre == "resultados":
        inf, marg = C.informe_resultados(c, per, ocultar)
        tablas = [inf, marg]
    elif nombre == "balance":
        tablas = [C.informe_balance(c, per, ocultar)[0]]
    elif nombre == "flujo":
        tablas = [C.informe_flujo(c, per)]
    elif nombre == "patrimonio":
        tablas = [C.informe_patrimonio(c, per)]
    elif nombre in ("gastos", "ingresos"):
        tablas = list(C.informe_por_tipo(c, per, "gasto" if nombre == "gastos" else "ingreso"))
    elif nombre in ("pagar", "cobrar"):
        inf, lista = C.informe_terceros(c, nombre, per["hasta"], request.args.get("tipo_tercero") or None)
        tablas = [inf]
        extra["pendientes"] = [d for d in C.documentos(c, nombre, solo_pendientes=True) if d["fecha"] <= per["hasta"]]
    elif nombre == "indicadores":
        tablas = [C.indicadores(c, per)]
    elif nombre == "balanza":
        tablas = [C.informe_balanza(c, per)]
    elif nombre == "completo":
        comp = dict(per)
        if per["vista"] != "comparar":
            comp = C.leer_periodo(dict(args, vista="comparar"))
        res, marg = C.informe_resultados(c, comp, ocultar)
        bal = C.informe_balance(c, comp, ocultar)[0]
        simple = C.leer_periodo(dict(args, vista="simple"))
        gas = C.informe_por_tipo(c, simple, "gasto")
        ing = C.informe_por_tipo(c, simple, "ingreso")
        tablas = [res, marg, bal, C.informe_flujo(c, simple), C.informe_patrimonio(c, simple), gas[0], gas[1],
                  ing[0], ing[1], C.informe_terceros(c, "pagar", per["hasta"])[0],
                  C.informe_terceros(c, "cobrar", per["hasta"])[0], C.indicadores(c, per)]
        extra["comentario"] = comentario(c, comp, res)
    if request.args.get("formato") == "xlsx":
        nombre_archivo = f"{nombre}_{per['desde']}_{per['hasta']}.xlsx"
        return send_file(a_excel(tablas, C.nombre_empresa(c)), as_attachment=True, download_name=nombre_archivo,
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    return render_template("informe.html", nombre=nombre, titulo=INFORMES[nombre], tablas=tablas, per=per,
                           args=args, extra=extra, tipos_t=C.TIPOS_TERCERO,
                           solo_corte=nombre in ("pagar", "cobrar"))


# ---------------------------------------------------------------- tasas y ajuste

# ---------------------------------------------------------------- cierre de mes

def revision_mes(c, anio, mes):
    """Lo que conviene revisar antes de cerrar un mes."""
    desde, hasta, etq = C.rango_mes(anio, mes)
    items = []
    tasa = C.tasa_del_dia(c, hasta)
    pend = C.calcular_revaluacion(c, hasta, tasa) if tasa else []
    items.append((not pend, "Ajuste por tasa de cambio del último día",
                  "Hecho" if not pend else f"Falta: hay saldos en CUP sin ajustar a la tasa {tasa:g}. Ve a Tasa de cambio → Calcular ajuste.",
                  "/tasas"))
    negativas = [n for n, v, m in C.cajas_negativas(c)]
    items.append((not negativas, "Ninguna caja en negativo", "Bien" if not negativas else "Revisa: " + ", ".join(negativas), "/caja"))
    hay = c.execute("SELECT COUNT(*) FROM asientos WHERE anulado = 0 AND fecha BETWEEN ? AND ?", (desde, hasta)).fetchone()[0]
    items.append((hay > 0, "Movimientos del mes anotados", f"{hay} movimientos", f"/diario?desde={desde}&hasta={hasta}"))
    arq = c.execute("SELECT COUNT(*) FROM asientos WHERE anulado = 0 AND origen = 'arqueo' AND fecha BETWEEN ? AND ?", (desde, hasta)).fetchone()[0]
    items.append((True, "Caja contada (arqueo)", f"{arq} ajuste(s) por arqueo este mes. Recomendado: contar el dinero el último día.", "/caja"))
    return etq, items


@app.route("/cierre", methods=["GET", "POST"])
@errores
def cierre():
    """Cerrar un mes: desde ese momento nadie puede anotar, cambiar ni borrar nada con esa fecha."""
    c = conn()
    u = usuario_actual()
    ch = C.cerrado_hasta(c)
    if request.method == "POST":
        if not u["es_admin"]:
            raise C.ErrorContable("Solo un administrador puede cerrar o reabrir meses.")
        if request.form.get("accion") == "reabrir":
            nuevo = (request.form.get("hasta") or "").strip() or None
            if nuevo and (not ch or nuevo >= ch):
                raise C.ErrorContable("Para reabrir elige una fecha anterior a la del cierre actual.")
            db.set_config(c, "cerrado_hasta", nuevo)
            c.commit()
            evento("Reabrió meses cerrados", f"antes cerrado hasta {ch}; ahora {nuevo or 'nada cerrado'}")
            flash(f"Reabierto ✓ Ahora {'está cerrado hasta el ' + fmt_fecha(nuevo) if nuevo else 'no hay ningún mes cerrado'}.", "ok")
        else:
            anio, mes = entero(request.form.get("anio")), entero(request.form.get("mes"))
            if not anio or not mes or not 1 <= mes <= 12:
                raise C.ErrorContable("Elige el mes que quieres cerrar.")
            hasta = C.ultimo_dia(anio, mes)
            if hasta >= C.hoy():
                raise C.ErrorContable("Solo se puede cerrar un mes que ya terminó.")
            if ch and hasta <= ch:
                raise C.ErrorContable("Ese mes ya está cerrado.")
            db.set_config(c, "cerrado_hasta", hasta)
            c.commit()
            evento("Cerró el mes", f"cerrado hasta {hasta}")
            flash(f"Mes cerrado ✓ Nadie puede cambiar nada hasta el {fmt_fecha(hasta)}.", "ok")
        return redirect(url_for("cierre"))
    hoy_ = date.today()
    anio = entero(request.args.get("anio")) or (hoy_.year if hoy_.month > 1 else hoy_.year - 1)
    mes = entero(request.args.get("mes")) or (hoy_.month - 1 or 12)
    if ch and not request.args.get("mes"):  # sugerir el mes siguiente al último cerrado
        d = datetime.strptime(ch, "%Y-%m-%d").date() + timedelta(days=1)
        if d.replace(day=1) < hoy_.replace(day=1):
            anio, mes = d.year, d.month
    etq, items = revision_mes(c, anio, mes)
    return render_template("cierre.html", ch=ch, anio=anio, mes=mes, etq=etq, items=items, es_admin=u["es_admin"])


@app.route("/tasas", methods=["GET", "POST"])
@errores
def tasas():
    c = conn()
    if request.method == "POST" and not repitiendo():
        if request.form.get("borrar"):
            c.execute("DELETE FROM tasas WHERE fecha = ?", (request.form.get("borrar"),))
            flash("Tasa borrada.", "ok")
        else:
            fecha = fecha_form()
            t = numero(request.form.get("tasa"))
            if not t or t <= 0:
                raise C.ErrorContable("Escribe la tasa (cuántos CUP vale 1 USD).")
            c.execute("INSERT INTO tasas (fecha, cup_por_usd) VALUES (?, ?) ON CONFLICT(fecha) DO UPDATE"
                      " SET cup_por_usd = excluded.cup_por_usd", (fecha, t))
            flash("Tasa guardada ✓", "ok")
        c.commit()
        return redirect(url_for("tasas"))
    lista = c.execute("SELECT * FROM tasas ORDER BY fecha DESC LIMIT 120").fetchall()
    return render_template("tasas.html", lista=lista, tasa=C.tasa_del_dia(c))


@app.route("/ajuste-cambio", methods=["GET", "POST"])
@errores
def ajuste_cambio():
    c = conn()
    fecha = request.values.get("fecha") or C.hoy()
    try:
        datetime.strptime(fecha, "%Y-%m-%d")
    except ValueError:
        fecha = C.hoy()
    try:
        tasa = numero(request.values.get("tasa"))
    except C.ErrorContable:
        tasa = None
    if tasa is not None and tasa <= 0:
        tasa = None
    tasa = tasa or C.tasa_del_dia(c, fecha)
    if request.method == "POST" and not repitiendo():
        if not tasa or tasa <= 0:
            raise C.ErrorContable("Falta la tasa.")
        C.guardar_tasa_si_falta(c, fecha, tasa)
        aid = C.registrar_revaluacion(c, fecha, tasa)
        c.commit()
        flash("Ajuste por tasa de cambio registrado ✓", "ok")
        return redirect(url_for("asiento", aid=aid))
    filas = C.calcular_revaluacion(c, fecha, tasa) if tasa else []
    return render_template("ajuste_cambio.html", filas=filas, fecha=fecha, tasa=tasa,
                           total=C.r2(sum(f["dif"] for f in filas)))


# ---------------------------------------------------------------- configuración y copias

@app.route("/configuracion", methods=["GET", "POST"])
def configuracion():
    c = conn()
    hay_asientos = c.execute("SELECT COUNT(*) FROM asientos").fetchone()[0] > 0
    if request.method == "POST":
        for k in ("empresa", "nit", "direccion", "responsable", "telefono"):
            db.set_config(c, k, (request.form.get(k) or "").strip())
        if not db.get_config(c, "empresa"):
            db.set_config(c, "empresa", "Mi Negocio")
        if not hay_asientos and request.form.get("moneda_base") in C.MONEDAS:
            db.set_config(c, "moneda_base", request.form.get("moneda_base"))
        c.commit()
        flash("Configuración guardada ✓", "ok")
        return redirect(url_for("configuracion"))
    datos = {k: db.get_config(c, k, "") for k in ("empresa", "nit", "direccion", "responsable", "telefono")}
    return render_template("configuracion.html", d=datos, hay_asientos=hay_asientos, ruta=db.ruta_db(),
                           copias_dir=db.carpeta_copias())


def _zip_programa(destino):
    """Copia del programa (sin los datos) para poder reinstalarlo en otra computadora."""
    import zipfile
    base = Path(__file__).resolve().parent
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for p in list(base.glob("*.py")) + list(base.glob("*.md")) + list(base.glob("requirements.txt")) + \
                list(base.glob("templates/*")) + list(base.glob("static/*")) + list(base.glob("icono/*.svg")) + \
                list(base.glob("icono/*.icns")):
            z.write(p, "mi-contabilidad/" + p.relative_to(base).as_posix())


LEEME_USB = """MI CONTABILIDAD - COPIAS DE SEGURIDAD
=====================================

- Los archivos contabilidad_....db.cifrado son tus datos, CIFRADOS con AES-256.
  Sin tu contraseña o tu código de recuperación nadie los puede leer.
- Para recuperar todo en otra computadora:
  1. Instala el programa (programa_mi_contabilidad.zip tiene el programa completo).
  2. Al abrirlo, elige "¿Ya usabas Mi Contabilidad? Restaurar mi copia".
  3. Elige el archivo .db.cifrado MÁS RECIENTE y entra con tu usuario y la contraseña
     (o el código de recuperación) que tenías cuando se hizo esa copia.
- Guarda esta memoria en un lugar seguro, lejos de la computadora.
"""


@app.route("/copias", methods=["GET", "POST"])
@errores
def copias():
    if request.method == "POST" and not repitiendo():
        accion = request.form.get("accion") or ("restaurar" if request.form.get("restaurar") else "copia")
        if accion == "cargar":
            if not usuario_actual()["es_admin"]:
                raise C.ErrorContable("Solo un administrador puede cargar una copia de otro equipo.")
            archivo = request.files.get("archivo")
            blob = archivo.read() if archivo else b""
            if not blob:
                raise C.ErrorContable("Elige el archivo de la copia (termina en .db.cifrado).")
            usuario = (request.form.get("usuario") or "").strip().lower()[:30]
            espera = bloqueado("copia:" + usuario)
            if espera:
                raise C.ErrorContable(f"Demasiados intentos. Espera {espera} segundos.")
            try:
                boveda.abrir_copia_portatil(blob, usuario, request.form.get("clave") or "")  # comprobar antes de tocar nada
            except boveda.ErrorBoveda as e:
                fallo("copia:" + usuario)
                raise C.ErrorContable(str(e))
            antes = db.hacer_copia("antes_de_cargar")
            evento("Cargó una copia de otro equipo (reemplaza los datos)", f"{archivo.filename} · antes: {antes.name}")
            c = g.pop("conn", None)
            if c:
                c.commit()
                c.close()
            boveda.reemplazar_con_copia(blob, usuario, request.form.get("clave") or "")
            ACTIVAS.clear()
            session.clear()
            flash("Copia cargada ✓ Ahora están aquí los datos de la copia. Entra con tu usuario y contraseña de esa copia. "
                  f"(Lo que había antes se guardó en la copia {antes.name}.)", "ok")
            return redirect(url_for("entrar"))
        if accion == "restaurar":
            nombre = Path(request.form.get("restaurar")).name
            ruta = db.carpeta_copias() / nombre
            if not ruta.is_file() or not (nombre.endswith(".db") or nombre.endswith(".db.cifrado")):
                flash("No se encontró esa copia.", "error")
            else:
                c = g.pop("conn", None)
                if c:
                    c.close()
                try:
                    db.restaurar(ruta)
                except Exception:
                    flash("No se pudo abrir esa copia (está dañada o cifrada con otra llave).", "error")
                    return redirect(url_for("copias"))
                db.iniciar()
                if not conn().execute("SELECT 1 FROM usuarios WHERE usuario = ?", (usuario_actual()["usuario"],)).fetchone():
                    u = usuario_actual()
                    conn().execute("INSERT INTO usuarios (usuario, nombre, clave, recuperacion, es_admin, activo, creado)"
                                   " VALUES (?,?,?,?,1,1,?)", (u["usuario"], u["nombre"], u["clave"], u["recuperacion"],
                                                                u["creado"]))
                    conn().commit()
                evento("Restauró una copia de seguridad", nombre)
                flash(f"Se restauró la copia {nombre}. (Antes se guardó una copia de cómo estaba.)", "ok")
        elif accion == "usb":
            vols = {v.name: v for v in boveda.volumenes_externos()}
            vol = vols.get(request.form.get("volumen") or "")
            if not vol:
                raise C.ErrorContable("No encuentro esa memoria. Conéctala y vuelve a abrir esta pantalla.")
            import shutil as _sh
            origen = db.hacer_copia("usb")
            carpeta = vol / "Mi Contabilidad - Copias"
            try:
                carpeta.mkdir(exist_ok=True)
                destino = carpeta / origen.name
                _sh.copyfile(origen, destino)
                _zip_programa(carpeta / "programa_mi_contabilidad.zip")
                (carpeta / "LEEME.txt").write_text(LEEME_USB)
            except OSError as e:
                raise C.ErrorContable(f"No se pudo escribir en la memoria ({e.strerror}). ¿Está llena o protegida?")
            # comprobar que la copia de la memoria se puede abrir
            if destino.read_bytes() != origen.read_bytes():
                raise C.ErrorContable("La copia en la memoria salió distinta. Prueba con otra memoria.")
            boveda.desempaquetar(destino.read_bytes())
            db.set_config(conn(), "ultima_copia_externa", datetime.now().isoformat(timespec="seconds"))
            conn().commit()
            evento("Copia de seguridad a memoria externa", f"{vol.name}: {destino.name}")
            flash(f"Copia guardada en la memoria «{vol.name}» ✓ (carpeta «Mi Contabilidad - Copias», con el programa y "
                  "las instrucciones). Ya puedes expulsar la memoria.", "ok")
        else:
            destino = db.hacer_copia("manual")
            flash(f"Copia hecha ✓: {destino.name}" + (" (cifrada)" if destino.name.endswith(".cifrado") else ""), "ok")
        return redirect(url_for("copias"))
    carpeta = db.carpeta_copias()
    lista = list(reversed(db.lista_copias()))
    ultima = db.get_config(conn(), "ultima_copia_externa")
    return render_template("copias.html", lista=[(p.name, p.stat().st_size, datetime.fromtimestamp(p.stat().st_mtime))
                                                 for p in lista], carpeta=carpeta,
                           volumenes=[] if db.IPAD else [v.name for v in boveda.volumenes_externos()],
                           ultima_externa=datetime.fromisoformat(ultima) if ultima else None)


@app.route("/copias/descargar")
def descargar_copia():
    destino = db.hacer_copia("descargada")
    db.set_config(conn(), "ultima_copia_externa", datetime.now().isoformat(timespec="seconds"))
    conn().commit()
    evento("Descargó una copia de seguridad", destino.name)
    return send_file(destino, as_attachment=True, download_name=destino.name, mimetype="application/octet-stream")


@app.route("/restaurar-copia", methods=["GET", "POST"])
def restaurar_copia():
    """Computadora nueva (sin datos todavía): instalar una copia portátil con usuario y contraseña o código."""
    if boveda.activa():
        flash("Esta computadora ya tiene datos. Para volver a una copia usa Más → Copias de seguridad.", "error")
        return redirect(url_for("entrar"))
    if request.method == "POST":
        usuario = (request.form.get("usuario") or "").strip().lower()[:30]
        espera = bloqueado("copia:" + usuario)
        if espera:
            flash(f"Demasiados intentos. Espera {espera} segundos.", "error")
            return render_template("seguridad.html", modo="restaurar", f={"usuario": usuario})
        archivo = request.files.get("archivo")
        blob = archivo.read() if archivo else b""
        if not blob:
            flash("Elige el archivo de la copia (termina en .db.cifrado).", "error")
            return render_template("seguridad.html", modo="restaurar", f={"usuario": usuario})
        try:
            boveda.instalar_desde_copia(blob, usuario, request.form.get("clave") or "")
        except boveda.ErrorBoveda as e:
            fallo("copia:" + usuario)
            flash(str(e), "error")
            return render_template("seguridad.html", modo="restaurar", f={"usuario": usuario})
        g.pop("conn", None)
        db.iniciar()
        u = conn().execute("SELECT * FROM usuarios WHERE usuario = ?", (usuario,)).fetchone()
        if not u or not u["activo"]:
            boveda.cerrar()
            flash("Datos restaurados, pero ese usuario está desactivado. Entra con otro administrador.", "error")
            return redirect(url_for("entrar"))
        iniciar_sesion(u)
        evento("Restauró sus datos en esta computadora desde una copia portátil", archivo.filename)
        flash("¡Datos recuperados! ✓ Todo está como en la copia. Te recomendamos cambiar la contraseña y sacar un "
              "código de recuperación nuevo en Mi cuenta.", "ok")
        return redirect(url_for("panel"))
    return render_template("seguridad.html", modo="restaurar", f={})


AYUDA_PDF = {"Tutorial_Mi_Contabilidad.pdf", "Guia_Operaciones_Paso_a_Paso.pdf"}


@app.route("/ayuda")
def ayuda():
    """Tutoriales y guías, dentro del programa (se leen sin internet)."""
    return render_template("ayuda.html")


@app.route("/ayuda/pdf/<nombre>")
def ayuda_pdf(nombre):
    if nombre not in AYUDA_PDF:
        abort(404)
    return send_file(Path(app.static_folder) / "ayuda" / nombre, as_attachment=True, download_name=nombre,
                     mimetype="application/pdf")


@app.route("/movil", methods=["GET", "POST"])
@errores
def movil():
    """Exportar una foto cifrada de los datos para la app visor del iPhone."""
    if request.method == "POST" and not repitiendo() and request.form.get("accion") == "url":
        url = (request.form.get("url_visor") or "").strip()
        if url and not re.fullmatch(r"https://[A-Za-z0-9.-]+\.github\.io/[A-Za-z0-9._/-]*", url):
            raise C.ErrorContable("Escribe la dirección completa del visor, por ejemplo https://tu-usuario.github.io/mi-contabilidad-visor/")
        db.set_config(conn(), "url_visor", url)
        conn().commit()
        flash("Dirección del visor guardada ✓", "ok")
        return redirect(url_for("movil"))
    if request.method == "POST" and not repitiendo():
        clave = request.form.get("clave") or ""
        if clave != (request.form.get("repetir") or ""):
            raise C.ErrorContable("Las dos contraseñas no son iguales.")
        if len(clave) < 8 or not (re.search(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]", clave) and re.search(r"\d", clave)):
            raise C.ErrorContable("La contraseña del móvil tiene que tener al menos 8 caracteres, con letras y números.")
        import io
        import movil as M
        datos = M.foto(conn(), usuario_actual()["nombre"])
        blob = M.cifrar_foto(datos, clave)
        evento("Exportó los datos para el móvil")
        nombre = f"Mi Contabilidad {datetime.now():%Y-%m-%d %H%M}.mcvisor"
        return send_file(io.BytesIO(blob), as_attachment=True, download_name=nombre, mimetype="application/octet-stream")
    return render_template("movil.html", url_visor=db.get_config(conn(), "url_visor", ""))


# ---------------------------------------------------------------- caja

import inventario as INV


@app.route("/caja")
def caja():
    c = conn()
    cajas_ = INV.resumen_cajas(c)
    totales = {m: C.r2(sum(x["saldo"] for x in cajas_ if x["moneda"] == m)) for m in C.MONEDAS}
    grupo = c.execute("SELECT id FROM cuentas WHERE codigo = '1.1' AND es_grupo = 1").fetchone()
    return render_template("caja.html", cajas=cajas_, totales=totales, grupo_caja=grupo["id"] if grupo else "",
                           total_base=C.r2(sum(x["base"] for x in cajas_)), tasa=C.tasa_del_dia(c))


@app.route("/caja/<int:cid>", methods=["GET", "POST"])
@errores
def caja_detalle(cid):
    c = conn()
    if request.method == "POST" and not repitiendo():
        fecha = fecha_form()
        tasa = tasa_form(fecha)
        contado = numero(request.form.get("contado"))
        aid, dif = INV.registrar_arqueo(c, fecha, cid, contado, tasa, request.form.get("nota"))
        c.commit()
        if aid:
            flash(f"Arqueo guardado: {'sobrante' if dif > 0 else 'faltante'} de {abs(dif):,.2f}. Ya quedó anotado.", "ok")
        else:
            flash("Arqueo perfecto ✓: el dinero contado coincide con el programa.", "ok")
        return redirect(url_for("caja_detalle", cid=cid))
    hoy_ = date.today()
    mes = request.args.get("mes") or f"{hoy_.year}-{hoy_.month:02d}"
    try:
        y, m = int(mes[:4]), int(mes[5:7])
        desde, hasta, etq = C.rango_mes(y, m)
    except (ValueError, IndexError):
        y, m = hoy_.year, hoy_.month
        desde, hasta, etq = C.rango_mes(y, m)
    cuenta_, inicial, filas, final = INV.libro_caja(c, cid, desde, hasta)
    ant = f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"
    sig = f"{y + 1}-01" if m == 12 else f"{y}-{m + 1:02d}"
    puntos = [inicial] + [f["saldo"] for f in filas]
    entra = C.r2(sum(f["entra"] or 0 for f in filas))
    sale = C.r2(sum(f["sale"] or 0 for f in filas))
    return render_template("caja_detalle.html", cu=cuenta_, inicial=inicial, filas=filas, final=final, etq=etq,
                           ant=ant, sig=sig, curva=INV._curva(puntos, 640, 120), entra=entra, sale=sale,
                           saldo_hoy=INV.saldo_caja(c, cid), moneda=cuenta_["moneda"] or C.moneda_base(c),
                           f=request.form if repitiendo() else {}, mes=mes)


# ---------------------------------------------------------------- inventario

@app.route("/inventario")
def inventario_():
    c = conn()
    prods = INV.productos(c)
    anio = date.today().year
    return render_template("inventario.html", prods=prods, total=C.r2(sum(p["valor"] for p in prods)),
                           bajos=[p for p in prods if p["bajo"]],
                           ganancias=INV.ganancia_por_producto(c, f"{anio}-01-01", C.hoy()), anio=anio,
                           contable=INV.valor_contable(c))


@app.route("/inventario/producto/nuevo", methods=["GET", "POST"])
@app.route("/inventario/producto/<int:pid>/editar", methods=["GET", "POST"])
@errores
def producto_editar(pid=None):
    c = conn()
    actual = INV.producto(c, pid) if pid else {}
    if request.method == "POST" and not repitiendo():
        f = request.form
        nombre = " ".join((f.get("nombre") or "").split())
        if not nombre:
            raise C.ErrorContable("Escribe el nombre del producto.")
        if c.execute("SELECT 1 FROM productos WHERE lower(nombre) = lower(?) AND id != ?", (nombre, pid or 0)).fetchone():
            raise C.ErrorContable("Ya hay un producto con ese nombre.")
        unidad = (f.get("unidad") or "unidad").strip().lower()[:20] or "unidad"
        minimo = numero(f.get("minimo"), 0) or 0
        vals = (nombre, unidad, (f.get("categoria") or "").strip() or None, max(minimo, 0),
                (f.get("notas") or "").strip() or None, 1 if f.get("activo", "1") == "1" else 0)
        if pid:
            c.execute("UPDATE productos SET nombre=?, unidad=?, categoria=?, minimo=?, notas=?, activo=? WHERE id=?",
                      vals + (pid,))
        else:
            pid = c.execute("INSERT INTO productos (nombre, unidad, categoria, minimo, notas, activo) VALUES (?,?,?,?,?,?)",
                            vals).lastrowid
        c.commit()
        flash("Producto guardado ✓", "ok")
        destino = request.form.get("volver") or ""
        if destino.startswith("/inventario/"):
            return redirect(f"{destino}{'&' if '?' in destino else '?'}producto={pid}")
        return redirect(url_for("producto_kardex", pid=pid))
    return render_template("producto_form.html", p=actual, d=request.form if repitiendo() else actual,
                           unidades=INV.UNIDADES, volver=request.args.get("volver", ""))


@app.route("/inventario/<int:pid>")
def producto_kardex(pid):
    c = conn()
    try:
        p = [x for x in INV.productos(c) if x["id"] == pid][0]
    except IndexError:
        abort(404)
    filas = INV.kardex(c, pid)
    filas.reverse()
    gan = [x for x in INV.ganancia_por_producto(c) if x["id"] == pid]
    return render_template("producto.html", p=p, filas=filas, gan=gan[0] if gan else None)


ACCIONES_INV = {
    "compra": ("Compra de mercancía", "Entró mercancía: un contenedor, un lote, cajas… Sube la existencia."),
    "costo": ("Costo extra de una mercancía", "Flete, nacionalización, transporte, descarga… Sube lo que te costó cada unidad."),
    "venta": ("Venta de mercancía", "Vendiste mercancía. El programa anota la venta y, solo, lo que te costó."),
    "ajuste": ("Merma o sobrante", "Se rompió, se perdió o se echó a perder (merma), o apareció más de lo anotado (sobrante)."),
}


@app.route("/inventario/<accion>", methods=["GET", "POST"])
@errores
def inv_accion(accion):
    if accion not in ACCIONES_INV:
        abort(404)
    c = conn()
    if request.method == "POST" and not repitiendo():
        f = request.form
        fecha = fecha_form()
        tasa = tasa_form(fecha)
        pid = entero(f.get("producto"))
        if not pid:
            raise C.ErrorContable("Elige el producto.")
        venc = fecha_form("vencimiento") if (f.get("vencimiento") or "").strip() else None
        if accion in ("compra", "costo"):
            pago = f.get("pago") if f.get("pago") in ("caja", "credito", "apertura") else "caja"
            tercero = C.tercero_por_nombre(c, f.get("tercero"), "Proveedor")
            INV.registrar_entrada(c, "costo_extra" if accion == "costo" else "compra", fecha, pid,
                                  f.get("cantidad"), numero(f.get("importe")), f.get("moneda"), tasa, pago,
                                  entero(f.get("caja")), tercero, (f.get("numero") or "").strip() or None, venc,
                                  f.get("lote"), f.get("nota"))
        elif accion == "venta":
            cobro = "credito" if f.get("cobro") == "credito" else "caja"
            tercero = C.tercero_por_nombre(c, f.get("tercero"), "Cliente")
            cat = entero(f.get("categoria"))
            if cat not in {x["id"] for x in categorias("ingreso")}:
                cat = None
            INV.registrar_venta(c, fecha, pid, f.get("cantidad"), numero(f.get("importe")), f.get("moneda"), tasa,
                                cobro, entero(f.get("caja")), tercero, (f.get("numero") or "").strip() or None, venc,
                                cat, f.get("nota"))
        else:
            if not (f.get("nota") or "").strip():
                raise C.ErrorContable("Escribe qué pasó (por ejemplo: sacos rotos en el traslado).")
            INV.registrar_ajuste(c, fecha, pid, f.get("cantidad"), "sobrante" if f.get("tipo") == "sobrante" else "merma",
                                 f.get("nota"), tasa, numero(f.get("valor_unit")))
        c.commit()
        aviso_anticipo()
        ultimo = c.execute("SELECT id FROM asientos WHERE origen != 'costo_venta' ORDER BY id DESC LIMIT 1").fetchone()
        if ultimo:
            aviso_duplicado(ultimo["id"])
        flash("Guardado ✓ (inventario y contabilidad al día).", "ok")
        return redirect(url_for("producto_kardex", pid=pid))
    titulo, ayuda = ACCIONES_INV[accion]
    datos = request.form if repitiendo() else request.args
    return render_template("inv_form.html", accion=accion, titulo=titulo, ayuda=ayuda,
                           prods=INV.productos(c, solo_activos=True), cajas=cajas(), terceros=nombres_terceros(),
                           cats=categorias("ingreso"), f=datos)


@app.route("/api/deuda")
def api_deuda():
    """Cuánto debe (o se le debe a) una persona, por moneda. Para avisar en los formularios de Ingreso y Gasto."""
    tid = C.tercero_por_nombre(conn(), request.args.get("tercero"), crear=False)
    lado = "pagar" if request.args.get("lado") == "pagar" else "cobrar"
    if not tid:
        return jsonify({})
    tot = C.estado_cuenta(conn(), tid, lado)["tot"]
    return jsonify({m: tot[m]["pendiente"] for m in C.MONEDAS if tot[m]["pendiente"] > 0.004})


@app.route("/api/latido", methods=["POST"])
def api_latido():
    ULTIMO_LATIDO[0] = time.monotonic()
    return jsonify({"ok": True})


@app.route("/api/estado")
def api_estado():
    ultimo = ULTIMO_LATIDO[0]
    return jsonify({"version": VERSION, "boveda": boveda.estado(),
                    "ventana_abierta": ultimo is not None and time.monotonic() - ultimo < 20})


@app.route("/api/apagar", methods=["POST"])
def api_apagar():
    APAGAR.set()
    # si nadie lo apaga ordenadamente en unos segundos, se cierra igual
    threading.Timer(15, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


@app.route("/favicon.ico")
def favicon():
    return redirect(url_for("static", filename="icono.png"))


# ---------------------------------------------------------------- API para los formularios

@app.route("/api/tasa")
def api_tasa():
    return jsonify({"tasa": C.tasa_del_dia(conn(), request.args.get("fecha") or C.hoy())})


@app.route("/api/pendientes")
def api_pendientes():
    tid = C.tercero_por_nombre(conn(), request.args.get("tercero"), crear=False)
    tipo = "pagar" if request.args.get("tipo") == "pago" else "cobrar"
    if not tid:
        return jsonify([])
    out = [{"id": d["id"], "texto": f"Factura {d['numero'] or d['id']} · {fmt_fecha(d['fecha'])} · "
                                   f"{d['concepto'][:40]} · falta {d['pendiente']:,.2f} {d['moneda']}",
            "pendiente": d["pendiente"], "moneda": d["moneda"]}
           for d in C.documentos(conn(), tipo, tid, solo_pendientes=True)]
    # deudas sin factura (préstamos, anticipos...) para poder pagarlas en su cuenta
    for t in C.saldos_terceros(conn(), tipo, C.hoy()):
        if t["id"] != tid:
            continue
        roles = conn().execute("SELECT id, rol FROM cuentas").fetchall()
        rol_de = {r["id"]: r["rol"] for r in roles}
        for cu in conn().execute("SELECT * FROM cuentas WHERE por_tercero = 1 AND es_grupo = 0 AND tipo = ?",
                                 ("activo" if tipo == "cobrar" else "pasivo",)):
            if (rol_de.get(cu["id"]) or "").startswith(("cxc_", "cxp_")):
                continue
            saldo = next((x for x in t["cuentas"] if x["nombre"] == cu["nombre"]), None)
            if saldo and abs(saldo["saldo"]) >= 0.005:
                mon = cu["moneda"] or C.moneda_base(conn())
                cantidad = saldo["orig"] if cu["moneda"] else saldo["saldo"]
                out.append({"id": f"c:{cu['id']}", "texto": f"{cu['nombre']} · saldo {cantidad:,.2f} {mon}",
                            "pendiente": cantidad, "moneda": mon})
    return jsonify(out)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("MC_PUERTO", "5077")), debug=True)
