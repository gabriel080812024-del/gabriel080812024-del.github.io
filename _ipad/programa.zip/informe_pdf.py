"""Informe financiero completo en PDF, con el mismo formato TIKR de la pantalla Estados.

Trae el Estado de resultados, el Balance general, el Flujo de efectivo y los Indicadores, con los
períodos en columnas. Cada partida (grupo o cuenta) lleva un número, y al final un ANEXO desglosa cada
partida con ese mismo número: sus cuentas, período por período, y cada movimiento del último período
(fecha, número de asiento, concepto, persona e importe). Funciona igual en la Mac y en el iPad, sin
internet (fpdf2)."""
import re
from datetime import datetime

from fpdf import FPDF

import contab as C
import db
from documentos_pdf import t, fecha

NEGRO = (31, 35, 40)
NARANJA = (232, 137, 12)
NARANJA_OSC = (180, 100, 5)
GRIS = (107, 114, 128)
ROJO = (198, 40, 40)
LINEA = (209, 213, 219)
LINEA_SUAVE = (236, 238, 241)
FONDO_RES = (249, 250, 251)
FONDO_TOT = (243, 244, 246)
FONDO_ANEXO = (255, 247, 235)

ANCHO = 277          # A4 apaisado menos márgenes de 10 mm
MAX_COLS = 8         # más columnas no caben legibles: la tabla sigue en un segundo bloque
ALTO = 5.0


class ErrorInforme(Exception):
    pass


def _num(v, dec=2):
    if v is None or isinstance(v, str):
        return v or ""
    if abs(v) < 0.005:
        return "-"
    return f"({-v:,.{dec}f})" if v < 0 else f"{v:,.{dec}f}"


def _valor(v, fmt="n"):
    """Texto de una celda y si va en rojo."""
    if isinstance(v, tuple):
        fmt, v = v
    if v is None or isinstance(v, str):
        return (v or ""), False
    neg = v < -0.004
    if fmt == "p":
        return f"{v * 100:,.1f}%", neg
    if fmt == "r":
        return f"{v:,.2f}", neg
    if fmt == "d":
        return f"{v:,.0f} días", neg
    return _num(v), neg


class Pdf(FPDF):
    def __init__(self, empresa, subtitulo):
        super().__init__(orientation="L", format="A4", unit="mm")
        self.empresa, self.subtitulo = empresa, subtitulo
        self.set_margins(10, 10, 10)
        self.set_auto_page_break(True, margin=14)
        self.alias_nb_pages()
        self.set_title(t(f"Estados financieros - {empresa}"))
        self.set_author(t(empresa))
        self.generado = datetime.now().strftime("%d/%m/%Y %H:%M")

    def header(self):
        if self.page_no() == 1:
            return
        self.set_fill_color(*NARANJA)
        self.rect(10, 7, 5, 5, style="F", round_corners=True, corner_radius=1.2)
        self.set_xy(17, 6.5)
        self.set_font("helvetica", "B", 9)
        self.set_text_color(*NEGRO)
        self.cell(120, 6, t(self.empresa))
        self.set_xy(140, 6.5)
        self.set_font("helvetica", "", 8)
        self.set_text_color(*GRIS)
        self.cell(147, 6, t(self.subtitulo), align="R")
        self.set_draw_color(*LINEA)
        self.line(10, 13, 287, 13)
        self.set_y(16)

    def footer(self):
        self.set_y(-10)
        self.set_font("helvetica", "", 7)
        self.set_text_color(*GRIS)
        self.cell(140, 4, t(f"Generado el {self.generado} con Mi Contabilidad"))
        self.cell(137, 4, f"Página {self.page_no()} de {{nb}}", align="R")

    # ---------------------------------------------------------------- ayudas
    def ajustar(self, texto, ancho):
        """Recorta un texto para que quepa en el ancho (con «...»)."""
        texto = t(texto)
        if self.get_string_width(texto) <= ancho - 1.5:
            return texto
        while texto and self.get_string_width(texto + "...") > ancho - 1.5:
            texto = texto[:-1]
        return texto + "..."

    def titulo_seccion(self, texto, sub=""):
        if self.get_y() > 165:
            self.add_page()
        self.set_font("helvetica", "B", 13)
        self.set_text_color(*NEGRO)
        self.cell(0, 8, t(texto), new_x="LMARGIN", new_y="NEXT")
        if sub:
            self.set_font("helvetica", "", 8)
            self.set_text_color(*GRIS)
            self.multi_cell(0, 4, t(sub), new_x="LMARGIN", new_y="NEXT")
        self.set_fill_color(*NARANJA)
        self.rect(10, self.get_y() + 0.6, 22, 0.9, style="F")
        self.ln(3)


# ---------------------------------------------------------------- tablas TIKR

def _anchos(ncols, con_numero=True):
    col = min(26.0, (ANCHO - (12 if con_numero else 0) - 78) / max(ncols, 1))
    num = 12 if con_numero else 0
    return num, ANCHO - num - col * ncols, col


def tabla_tikr(pdf, inf, numeros=None, con_numero=True):
    """Dibuja un informe con los períodos en columnas. numeros: {índice de fila: "12" o "12.3"}."""
    numeros = numeros or {}
    total_cols = len(inf.columnas)
    bloques = [(i, min(i + MAX_COLS, total_cols)) for i in range(0, max(total_cols, 1), MAX_COLS)]
    for b, (c0, c1) in enumerate(bloques):
        ncols = c1 - c0
        wn, we, wc = _anchos(ncols, con_numero)

        def cabecera():
            pdf.set_fill_color(*NEGRO)
            pdf.set_text_color(255, 255, 255)
            pdf.set_font("helvetica", "B", 7.5)
            if con_numero:
                pdf.cell(wn, 6, "N.º", fill=True, align="C")
            titulo = inf.titulo + (f" (sigue, columnas {c0 + 1}-{c1})" if b else "")
            pdf.cell(we, 6, pdf.ajustar(f"{titulo}  |  {pdf.empresa}", we), fill=True)
            for col in inf.columnas[c0:c1]:
                pdf.cell(wc, 6, pdf.ajustar(col, wc), fill=True, align="R")
            pdf.ln(6)

        if pdf.get_y() > 180:
            pdf.add_page()
        cabecera()
        for i, f in enumerate(inf.filas):
            est = f["estilo"]
            alto = 4.2 if est == "pct" else (6.2 if est == "seccion" else ALTO)
            if pdf.will_page_break(alto):
                pdf.add_page()
                cabecera()
            negrita = est in ("seccion", "subseccion", "grupo", "total", "resultado", "gran_total")
            relleno = {"resultado": FONDO_RES, "gran_total": FONDO_TOT}.get(est)
            y = pdf.get_y()
            if est in ("total", "resultado"):
                pdf.set_draw_color(*LINEA)
                pdf.set_line_width(0.25)
                pdf.line(10, y, 10 + wn + we + wc * ncols, y)
            elif est == "gran_total":
                pdf.set_draw_color(*NEGRO)
                pdf.set_line_width(0.5)
                pdf.line(10, y, 10 + wn + we + wc * ncols, y)
            pdf.set_line_width(0.2)
            if relleno:
                pdf.set_fill_color(*relleno)
            estilo_letra = "B" if negrita else ("I" if est == "pct" else "")
            tam = 6.8 if est == "pct" else 7.5
            pdf.set_font("helvetica", estilo_letra, tam)
            color = ROJO if est == "alerta" else (GRIS if est == "pct" else NEGRO)
            if con_numero:
                pdf.set_text_color(*NARANJA_OSC)
                pdf.set_font("helvetica", "B", 7)
                pdf.cell(wn, alto, numeros.get(i, ""), fill=bool(relleno), align="C")
                pdf.set_font("helvetica", estilo_letra, tam)
            pdf.set_text_color(*color)
            sangria = 3.5 * (f["nivel"] or 0)
            pdf.cell(we, alto, " " * 0 + pdf.ajustar(f["etiqueta"], we - sangria) if not sangria else "",
                     fill=bool(relleno))
            if sangria:
                x = pdf.get_x()
                pdf.set_x(x - we + sangria)
                pdf.cell(we - sangria, alto, pdf.ajustar(f["etiqueta"], we - sangria))
            vals = f["valores"] or []
            for j in range(c0, c1):
                v = vals[j] if j < len(vals) else None
                fmt = f.get("fmt") or (inf.formatos[j] if j < len(inf.formatos) else "n")
                if est == "pct":
                    fmt = "p"
                texto, neg = _valor(v, fmt)
                if est == "pct" and not texto:
                    texto = ""
                elif not vals:
                    texto = ""
                pdf.set_text_color(*(ROJO if neg else color))
                pdf.cell(wc, alto, texto, fill=bool(relleno), align="R")
            pdf.ln(alto)
            if est == "seccion":
                pdf.set_draw_color(*LINEA)
                pdf.line(10, pdf.get_y(), 10 + wn + we + wc * ncols, pdf.get_y())
            elif est in ("normal", "grupo"):
                pdf.set_draw_color(*LINEA_SUAVE)
                pdf.line(10, pdf.get_y(), 10 + wn + we + wc * ncols, pdf.get_y())
        pdf.ln(4)
        if inf.nota:
            pdf.set_font("helvetica", "I", 7)
            pdf.set_text_color(*GRIS)
            pdf.multi_cell(0, 3.6, t(inf.nota), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)


# ---------------------------------------------------------------- numeración de partidas

_CUENTA = re.compile(r"^/cuentas/(\d+)")


def numerar(inf, estado, inicio, partidas):
    """Da número a cada partida de un informe de resultados o balance. Devuelve {fila: número} y el
    último número usado. Un grupo es «N»; cada cuenta dentro de él, «N.1», «N.2»..."""
    numeros, n, grupo = {}, inicio, None
    for i, f in enumerate(inf.filas):
        est, link = f["estilo"], f.get("link") or ""
        m = _CUENTA.match(link)
        if est == "grupo":
            n += 1
            grupo = {"num": str(n), "etiqueta": f["etiqueta"], "estado": estado, "valores": f["valores"],
                     "codigo": f.get("codigo") or "", "cuentas": [], "nivel": f["nivel"], "tipo": "grupo"}
            partidas.append(grupo)
            numeros[i] = grupo["num"]
        elif est == "normal" and m:
            cuenta = {"id": int(m.group(1)), "etiqueta": f["etiqueta"], "codigo": f.get("codigo") or "",
                      "valores": f["valores"]}
            if grupo and f["nivel"] > grupo["nivel"]:
                cuenta["num"] = f"{grupo['num']}.{len(grupo['cuentas']) + 1}"
                grupo["cuentas"].append(cuenta)
            else:
                n += 1
                cuenta["num"] = str(n)
                partidas.append({"num": str(n), "etiqueta": f["etiqueta"], "estado": estado, "valores": f["valores"],
                                 "codigo": cuenta["codigo"], "cuentas": [dict(cuenta, num=f"{n}.1")], "tipo": "cuenta"})
                grupo = None
            numeros[i] = cuenta["num"]
        elif est == "normal" and f["valores"]:
            n += 1
            partidas.append({"num": str(n), "etiqueta": f["etiqueta"], "estado": estado, "valores": f["valores"],
                             "cuentas": [], "tipo": "nota"})
            numeros[i] = str(n)
            grupo = None
        else:
            grupo = None
    return numeros, n


def numerar_flujo(conn, inf, cols, inicio, partidas):
    """Igual que numerar(), para el flujo de efectivo: sus grupos no traen el enlace a la cuenta, así
    que las cuentas se sacan del mismo cálculo del flujo (método directo)."""
    todas = C.cuentas(conn)
    por_id = {c["id"]: c for c in todas}
    efectivo = {c["id"] for c in todas if c["es_efectivo"] and not c["es_grupo"]}
    dif_id = C.cuenta_por_rol(conn, "dif_cambio")["id"]
    aportes = [C._flujo_columna(conn, d, h, por_id, efectivo, dif_id) for d, h, _ in cols]
    detalle = {}
    C._flujo_columna(conn, cols[-1][0], cols[-1][1], por_id, efectivo, dif_id, detalle=detalle)
    grupos = {}
    for i, ap in enumerate(aportes):
        for cid, v in ap.items():
            c = por_id[cid]
            if cid == dif_id:
                continue
            padre = por_id.get(c["padre_id"]) if c["padre_id"] else None
            clave = (c["flujo"], padre["nombre"] if padre else c["nombre"])
            grupos.setdefault(clave, {}).setdefault(cid, [0.0] * len(cols))[i] += v
    seccion = {"Actividades de operación": "operacion", "Actividades de inversión": "inversion",
               "Actividades de financiación": "financiacion"}
    numeros, n, actual, grupo = {}, inicio, None, None
    for i, f in enumerate(inf.filas):
        est = f["estilo"]
        if est == "seccion":
            actual, grupo = seccion.get(f["etiqueta"]), None
        elif est == "grupo" and actual:
            n += 1
            nombre = f["etiqueta"].rsplit(" (", 1)[0]
            cuentas_g = grupos.get((actual, nombre), {})
            lista = []
            for cid, vals in sorted(cuentas_g.items(), key=lambda x: por_id[x[0]]["nombre"]):
                if any(abs(x) >= 0.005 for x in vals):
                    c = por_id[cid]
                    lista.append({"id": cid, "etiqueta": c["nombre"], "codigo": c["codigo"],
                                  "valores": [C.r2(x) for x in vals], "num": f"{n}.{len(lista) + 1}",
                                  "flujo": detalle.get(cid, [])})
            grupo = {"num": str(n), "etiqueta": f["etiqueta"], "estado": "Flujo de efectivo", "valores": f["valores"],
                     "cuentas": lista, "tipo": "flujo", "nivel": f["nivel"]}
            partidas.append(grupo)
            numeros[i] = str(n)
        elif est == "normal" and grupo and f["nivel"] > grupo["nivel"]:
            c = next((x for x in grupo["cuentas"] if x["etiqueta"] == f["etiqueta"]), None)
            if c:
                numeros[i] = c["num"]
        elif est == "normal" and f["valores"]:
            n += 1
            partidas.append({"num": str(n), "etiqueta": f["etiqueta"], "estado": "Flujo de efectivo",
                             "valores": f["valores"], "cuentas": [], "tipo": "nota"})
            numeros[i] = str(n)
            grupo = None
        else:
            grupo = None if est != "normal" else grupo
    return numeros, n


# ---------------------------------------------------------------- anexo: desglose de cada partida

def movimientos_cuenta(conn, cuenta_id, desde, hasta):
    return conn.execute(
        "SELECT a.id aid, a.numero, a.fecha, a.concepto, l.descripcion, te.nombre tercero, l.debe, l.haber,"
        " l.moneda, l.importe_orig FROM lineas l JOIN asientos a ON a.id = l.asiento_id"
        " LEFT JOIN terceros te ON te.id = l.tercero_id WHERE a.anulado = 0 AND l.cuenta_id = ?"
        " AND a.fecha >= ? AND a.fecha <= ? ORDER BY a.fecha, a.numero, l.id", (cuenta_id, desde, hasta)).fetchall()


def _tabla_movimientos(pdf, filas, base, inicial=None, final=None, etiqueta_total="Total del período"):
    """filas: [(fecha, numero, concepto, persona, original, importe)]."""
    w = [20, 16, 120, 50, 36, 35]
    cab = ["Fecha", "Asiento", "Concepto", "Persona", "Original", f"Importe {base}"]

    def cabecera():
        pdf.set_fill_color(*NEGRO)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("helvetica", "B", 7)
        for x, h in zip(w, cab):
            pdf.cell(x, 5, t(h), fill=True, align="R" if h.startswith(("Original", "Importe")) else "L")
        pdf.ln(5)

    def linea(celdas, negrita=False, relleno=None):
        if pdf.will_page_break(4.6):
            pdf.add_page()
            cabecera()
        pdf.set_font("helvetica", "B" if negrita else "", 7)
        if relleno:
            pdf.set_fill_color(*relleno)
        for k, (x, v) in enumerate(zip(w, celdas)):
            neg = isinstance(v, (int, float)) and v < -0.004
            pdf.set_text_color(*(ROJO if neg else NEGRO))
            texto = _num(v) if isinstance(v, (int, float)) else pdf.ajustar(v or "", x)
            pdf.cell(x, 4.6, texto, fill=bool(relleno), align="R" if k >= 4 else "L")
        pdf.ln(4.6)
        pdf.set_draw_color(*LINEA_SUAVE)
        pdf.line(10, pdf.get_y(), 10 + sum(w), pdf.get_y())

    cabecera()
    if inicial is not None:
        linea([inicial[0], "", "Saldo anterior", "", "", inicial[1]], True, FONDO_RES)
    total = 0.0
    for fila in filas:
        linea(list(fila))
        total += fila[5]
    if not filas:
        linea(["", "", "Sin movimientos en este período.", "", "", 0.0])
    if final is not None:
        linea([final[0], "", "Saldo al cierre", "", "", final[1]], True, FONDO_TOT)
    else:
        linea(["", "", etiqueta_total, "", "", C.r2(total)], True, FONDO_TOT)
    pdf.ln(3)
    return C.r2(total)


def anexo(pdf, conn, partidas, cols, base, con_movimientos=True):
    desde, hasta, etq = cols[-1]
    por_id = {c["id"]: c for c in C.cuentas(conn)}
    pdf.add_page()
    pdf.titulo_seccion("Anexo · Desglose de cada partida",
                       f"Cada número es el mismo de los estados. Para cada partida: sus cuentas en todos los períodos"
                       + (f" y cada movimiento de {etq} (del {fecha(desde)} al {fecha(hasta)})" if con_movimientos else "")
                       + f". Cifras en {base}.")
    cuadres = []
    saldos_previos = {}
    personas = {}  # primera persona de cada asiento, para el desglose del flujo (una sola consulta)
    for r in conn.execute("SELECT l.asiento_id, te.nombre FROM lineas l JOIN terceros te ON te.id = l.tercero_id"
                          " JOIN asientos a ON a.id = l.asiento_id WHERE a.fecha >= ? AND a.fecha <= ? ORDER BY l.id",
                          (desde, hasta)):
        personas.setdefault(r[0], r[1])
    for p in partidas:
        if pdf.get_y() > 170:
            pdf.add_page()
        # barra de la partida
        pdf.set_fill_color(*FONDO_ANEXO)
        pdf.set_draw_color(*NARANJA)
        pdf.set_text_color(*NARANJA_OSC)
        pdf.set_font("helvetica", "B", 10)
        pdf.cell(16, 7, p["num"], fill=True, border="L")
        pdf.set_text_color(*NEGRO)
        pdf.cell(180, 7, pdf.ajustar(p["etiqueta"], 180), fill=True)
        pdf.set_font("helvetica", "", 8)
        pdf.set_text_color(*GRIS)
        pdf.cell(81, 7, t(p["estado"]), fill=True, align="R")
        pdf.ln(9)
        if p["tipo"] == "nota":
            pdf.set_font("helvetica", "", 8)
            pdf.set_text_color(*NEGRO)
            pdf.multi_cell(0, 4.2, t(_explicacion(p["etiqueta"])), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(3)
            continue
        # resumen de sus cuentas, período por período
        res = C.Informe(f"{p['num']}  {p['etiqueta']}", "", [c[2] for c in cols], ["n"] * len(cols))
        for c in p["cuentas"]:
            res.fila(f"{c['codigo']}  {c['etiqueta']}".strip(), c["valores"], "normal")
        res.fila(f"Total partida {p['num']}", p["valores"], "total")
        tabla_tikr(pdf, res, {i: c["num"] for i, c in enumerate(p["cuentas"])})
        # cada movimiento del último período
        for c in (p["cuentas"] if con_movimientos else []):
            cu = por_id.get(c["id"])
            if not cu:
                continue
            if pdf.get_y() > 175:
                pdf.add_page()
            pdf.set_font("helvetica", "B", 8.5)
            pdf.set_text_color(*NARANJA_OSC)
            pdf.cell(16, 5, c["num"])
            pdf.set_text_color(*NEGRO)
            pdf.cell(0, 5, pdf.ajustar(f"{c['codigo']}  {c['etiqueta']}  ·  movimientos de {etq}", 250),
                     new_x="LMARGIN", new_y="NEXT")
            valor_col = (c["valores"] or [0])[-1] or 0
            if p["tipo"] == "flujo":
                info = {}
                for aid, v in c["flujo"]:
                    info[aid] = info.get(aid, 0) + v
                filas = []
                if info:
                    marcas = ",".join("?" * len(info))
                    for a in conn.execute(f"SELECT id, numero, fecha, concepto FROM asientos WHERE id IN ({marcas})"
                                          " ORDER BY fecha, numero", list(info)):
                        filas.append((fecha(a["fecha"]), str(a["numero"]), a["concepto"],
                                      personas.get(a["id"], ""), "", C.r2(info[a["id"]])))
                total = _tabla_movimientos(pdf, filas, base)
                cuadres.append((c["num"], total, valor_col))
                continue
            movs = movimientos_cuenta(conn, c["id"], desde, hasta)
            filas = []
            balance = cu["tipo"] in ("activo", "pasivo", "patrimonio")
            for m in movs:
                v = C.natural(cu["tipo"], m["debe"], m["haber"]) if balance else (m["haber"] - m["debe"])
                orig = f"{abs(m['importe_orig']):,.2f} {m['moneda']}" if m["moneda"] != base else ""
                concepto = m["concepto"] + (f" - {m['descripcion']}" if m["descripcion"] and m["descripcion"] != m["concepto"] else "")
                filas.append((fecha(m["fecha"]), str(m["numero"]), concepto, m["tercero"] or "", orig, C.r2(v)))
            if balance:
                antes = C.dia_antes(desde)
                if antes not in saldos_previos:
                    saldos_previos[antes] = C.movimientos(conn, None, antes)
                prev = saldos_previos[antes].get(c["id"], (0, 0, 0))
                ini = C.natural(cu["tipo"], prev[0], prev[1])
                if cu["rol"] == "resultados_acum":
                    # el balance suma aquí las ganancias de los años ya cerrados (no son movimientos anotados)
                    previos_ini = C.resultado(conn, None, C.dia_antes(C.inicio_anio(antes)))
                    previos_fin = C.resultado(conn, None, C.dia_antes(C.inicio_anio(hasta)))
                    ini += previos_ini
                    if abs(previos_fin - previos_ini) > 0.004:
                        filas.append((fecha(C.inicio_anio(hasta)), "", "Pasa el resultado del año anterior", "", "",
                                      C.r2(previos_fin - previos_ini)))
                        filas.sort(key=lambda x: datetime.strptime(x[0], "%d/%m/%Y"))
                ini = C.r2(ini)
                fin = C.r2(ini + sum(x[5] for x in filas))
                _tabla_movimientos(pdf, filas, base, (fecha(C.dia_antes(desde)), ini), (fecha(hasta), fin))
                cuadres.append((c["num"], fin, valor_col))
            else:
                total = _tabla_movimientos(pdf, filas, base)
                cuadres.append((c["num"], total, valor_col))
        pdf.ln(2)
    return cuadres


def _explicacion(etiqueta):
    e = etiqueta.lower()
    if "resultado del ejercicio" in e:
        return ("Es la ganancia (o pérdida) acumulada del año en curso hasta la fecha de cada columna. "
                "Sale del Estado de resultados: ingresos menos costos y gastos del año.")
    if "capex" in e:
        return ("Todo lo pagado en el período por activos fijos (equipos, vehículos, mobiliario, locales), "
                "al contado o pagando facturas de compras a crédito. Su detalle está en las partidas de "
                "Actividades de inversión.")
    return "Partida calculada a partir de las demás partidas del informe."


# ---------------------------------------------------------------- el informe completo

def informe(conn, periodo, n, hasta, nombre_periodo, con_movimientos=True):
    base = C.moneda_base(conn)
    empresa = C.nombre_empresa(conn) or "Mi negocio"
    cols = C.columnas_terminal(conn, periodo, n, hasta)
    if not cols:
        raise ErrorInforme("No hay períodos para el informe.")
    per = C.per_terminal(cols)
    res, _ = C.informe_resultados_terminal(conn, cols, True)
    bal = C.informe_balance(conn, per)[0]
    bal.columnas = [x[2] for x in cols]
    bal.titulo = "Balance general"
    flu = C.informe_flujo(conn, per)
    ind = C.indicadores_terminal(conn, cols)

    rango = f"del {fecha(cols[0][0])} al {fecha(cols[-1][1])}"
    pdf = Pdf(empresa, f"Estados financieros · {nombre_periodo} · {rango} · cifras en {base}")
    partidas = []
    num_res, k = numerar(res, "Estado de resultados", 0, partidas)
    num_bal, k = numerar(bal, "Balance general", k, partidas)
    num_flu, k = numerar_flujo(conn, flu, cols, k, partidas)

    # portada
    pdf.add_page()
    pdf.set_fill_color(*NARANJA)
    pdf.rect(10, 18, 14, 14, style="F", round_corners=True, corner_radius=3)
    pdf.set_xy(28, 17)
    pdf.set_font("helvetica", "B", 22)
    pdf.set_text_color(*NEGRO)
    pdf.cell(0, 10, t(empresa), new_x="LMARGIN", new_y="NEXT")
    pdf.set_x(28)
    pdf.set_font("helvetica", "", 12)
    pdf.set_text_color(*GRIS)
    pdf.cell(0, 6, t(f"Estados financieros · {nombre_periodo} · {rango}"), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(10)
    tasa = C.tasa_del_dia(conn, cols[-1][1])
    datos = [("Períodos", f"{len(cols)} ({cols[0][2]} a {cols[-1][2]})"), ("Moneda del informe", base),
             ("Tasa de cambio al cierre", f"{tasa:,.2f} CUP por USD" if tasa else "-"),
             ("Partidas numeradas", str(k)), ("Generado", pdf.generado)]
    for a, b in datos:
        pdf.set_font("helvetica", "", 10)
        pdf.set_text_color(*GRIS)
        pdf.cell(60, 7, t(a))
        pdf.set_font("helvetica", "B", 10)
        pdf.set_text_color(*NEGRO)
        pdf.cell(0, 7, t(b), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(8)
    pdf.set_font("helvetica", "B", 11)
    pdf.cell(0, 7, t("Contenido"), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("helvetica", "", 10)
    contenido = ["1. Estado de resultados (pérdidas y ganancias)", "2. Balance general (activos, pasivos y patrimonio)",
                 "3. Estado de flujos de efectivo (incluye CAPEX y flujo de caja libre)", "4. Indicadores financieros",
                 "Anexo. Desglose de cada partida" + (", con todos sus movimientos" if con_movimientos else " por cuenta")]
    for x in contenido:
        pdf.cell(0, 6.5, t(x), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(6)
    pdf.set_font("helvetica", "I", 9)
    pdf.set_text_color(*GRIS)
    pdf.multi_cell(0, 5, t("Cómo leerlo: cada partida de los estados tiene un número en naranja (por ejemplo 7 para un "
                           "grupo y 7.2 para una de sus cuentas). Busca ese mismo número en el Anexo para ver qué la "
                           "forma y cada movimiento que la compone. Los números en rojo son negativos (gastos, "
                           "salidas de dinero o pérdidas)."), new_x="LMARGIN", new_y="NEXT")

    for titulo, inf, nums, sub in (
            ("1. Estado de resultados", res, num_res, "Ingresos, costos y gastos de cada período."),
            ("2. Balance general", bal, num_bal, "Lo que el negocio tiene y lo que debe, al cierre de cada período."),
            ("3. Estado de flujos de efectivo", flu, num_flu, "Por dónde entró y salió el dinero (método directo)."),
            ("4. Indicadores financieros", ind, {}, "Calculados al cierre de cada período.")):
        pdf.add_page()
        pdf.titulo_seccion(titulo, sub)
        tabla_tikr(pdf, inf, nums, con_numero=bool(nums))
    cuadres = anexo(pdf, conn, partidas, cols, base, con_movimientos)
    nombre = f"Estados_financieros_{periodo}_{cols[0][0]}_{cols[-1][1]}{'' if con_movimientos else '_resumido'}.pdf"
    return bytes(pdf.output()), nombre, cuadres, partidas
